import React, { useState, useEffect, useCallback } from 'react';
import type { LKPDConfig, StudentSubmission, ReminderLog, RealtimeMessage } from './types.js';
import { Navbar } from './components/Navbar.js';
import { StudentView } from './components/student/StudentView.js';
import { TeacherDashboard } from './components/teacher/TeacherDashboard.js';
import { ShareModal } from './components/ShareModal.js';
import { NotificationToast, ToastMessage } from './components/NotificationToast.js';
import { exportGradingToExcel } from './utils/excelExport.js';

export default function App() {
  // Determine initial view based on URL params
  const [currentView, setCurrentView] = useState<'student' | 'teacher'>('student');
  const [lkpdConfig, setLkpdConfig] = useState<LKPDConfig | null>(null);
  const [submissions, setSubmissions] = useState<StudentSubmission[]>([]);
  const [currentSubmission, setCurrentSubmission] = useState<StudentSubmission | null>(null);
  const [reminderLogs, setReminderLogs] = useState<ReminderLog[]>([]);
  const [isRealtimeConnected, setIsRealtimeConnected] = useState<boolean>(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [isShareModalOpen, setIsShareModalOpen] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Check URL query parameters
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const mode = params.get('mode');
    if (mode === 'teacher') {
      setCurrentView('teacher');
    } else {
      setCurrentView('student');
    }
  }, []);

  const addToast = useCallback(
    (type: 'info' | 'success' | 'warning' | 'reminder', title: string, message: string) => {
      const id = 'toast_' + Date.now() + Math.random().toString(36).slice(2, 6);
      setToasts((prev) => [...prev, { id, type, title, message }]);
      setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, 7000);
    },
    []
  );

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Fetch initial data from server
  const loadInitialData = useCallback(async () => {
    try {
      const [lkpdRes, subRes, remRes] = await Promise.all([
        fetch('/api/lkpd').then((r) => r.json()),
        fetch('/api/submissions').then((r) => r.json()),
        fetch('/api/reminders').then((r) => r.json()),
      ]);

      if (lkpdRes.success && lkpdRes.data) {
        setLkpdConfig(lkpdRes.data);
      }
      if (subRes.success && subRes.data) {
        setSubmissions(subRes.data);

        // Check if student has a saved submission in localStorage
        const savedSubId = localStorage.getItem('lkpd_active_sub_id');
        if (savedSubId) {
          const found = subRes.data.find((s: StudentSubmission) => s.id === savedSubId);
          if (found) setCurrentSubmission(found);
        }
      }
      if (remRes.success && remRes.data) {
        setReminderLogs(remRes.data);
      }
    } catch (err) {
      console.error('Failed to load initial data from server:', err);
    }
  }, []);

  useEffect(() => {
    loadInitialData();
  }, [loadInitialData]);

  // Connect to SSE Real-time stream
  useEffect(() => {
    let eventSource: EventSource | null = null;
    let reconnectTimeout: any = null;

    const connectSSE = () => {
      try {
        eventSource = new EventSource('/api/events');

        eventSource.onopen = () => {
          setIsRealtimeConnected(true);
        };

        eventSource.onmessage = (event) => {
          if (!event.data || event.data.startsWith(':')) return;

          try {
            const data: RealtimeMessage = JSON.parse(event.data);

            if (data.type === 'connected') {
              setIsRealtimeConnected(true);
            } else if (data.type === 'lkpd_updated') {
              setLkpdConfig(data.payload);
              addToast(
                'info',
                'LKPD Diperbarui oleh Guru',
                'Soal, petunjuk, atau tenggat waktu LKPD telah diperbarui secara real-time.'
              );
            } else if (data.type === 'submission_saved') {
              const saved: StudentSubmission = data.payload;
              setSubmissions((prev) => {
                const idx = prev.findIndex((s) => s.id === saved.id);
                if (idx >= 0) {
                  const updated = [...prev];
                  updated[idx] = saved;
                  return updated;
                }
                return [saved, ...prev];
              });

              // If this is the current active student's submission
              setCurrentSubmission((prev) => {
                if (prev && prev.id === saved.id) return saved;
                return prev;
              });
            } else if (data.type === 'submission_graded') {
              const graded: StudentSubmission = data.payload;
              setSubmissions((prev) =>
                prev.map((s) => (s.id === graded.id ? graded : s))
              );

              setCurrentSubmission((prev) => {
                if (prev && prev.id === graded.id) {
                  addToast(
                    'success',
                    'Nilai LKPD Telah Diberikan!',
                    `Guru telah memeriksa LKPD ${graded.groupName} dengan Total Nilai: ${graded.totalScore}/100.`
                  );
                  return graded;
                }
                return prev;
              });
            } else if (data.type === 'submission_deleted') {
              const { id } = data.payload;
              setSubmissions((prev) => prev.filter((s) => s.id !== id));
            } else if (data.type === 'reminder_sent') {
              const log: ReminderLog = data.payload;
              setReminderLogs((prev) => [log, ...prev]);
              addToast(
                'reminder',
                '🚨 Pengingat Tugas LKPD dari Guru',
                log.message || 'Tenggat waktu pengumpulan LKPD segera berakhir. Mohon segera selesaikan dan kirimkan tugas kelompok Anda!'
              );
            } else if (data.type === 'deadline_check') {
              // Reload submissions to reflect late status
              fetch('/api/submissions')
                .then((r) => r.json())
                .then((res) => {
                  if (res.success) setSubmissions(res.data);
                })
                .catch(() => {});
            }
          } catch (e) {
            // Ignore parse errors on ping
          }
        };

        eventSource.onerror = () => {
          setIsRealtimeConnected(false);
          eventSource?.close();
          // Auto reconnect after 3 seconds
          reconnectTimeout = setTimeout(connectSSE, 3000);
        };
      } catch (e) {
        setIsRealtimeConnected(false);
        reconnectTimeout = setTimeout(connectSSE, 3000);
      }
    };

    connectSSE();

    return () => {
      if (eventSource) eventSource.close();
      if (reconnectTimeout) clearTimeout(reconnectTimeout);
    };
  }, [addToast]);

  // Handle Save Draft (Student)
  const handleSaveDraft = async (data: Partial<StudentSubmission>) => {
    setIsSubmitting(true);
    try {
      const payload = {
        ...data,
        id: currentSubmission?.id || `sub-${Date.now()}`,
        isDraft: true,
      };

      const res = await fetch('/api/submissions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      }).then((r) => r.json());

      if (res.success && res.data) {
        setCurrentSubmission(res.data);
        localStorage.setItem('lkpd_active_sub_id', res.data.id);
      }
    } catch (err) {
      console.error('Error saving draft:', err);
      alert('Gagal menyimpan draf ke server.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Submit Answers (Student)
  const handleSubmitAnswers = async (data: Partial<StudentSubmission>) => {
    setIsSubmitting(true);
    try {
      const payload = {
        ...data,
        id: currentSubmission?.id || `sub-${Date.now()}`,
        isDraft: false,
      };

      const res = await fetch('/api/submissions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      }).then((r) => r.json());

      if (res.success && res.data) {
        setCurrentSubmission(res.data);
        localStorage.setItem('lkpd_active_sub_id', res.data.id);
        addToast(
          'success',
          'Jawaban Berhasil Dikirimkan',
          res.message || 'Jawaban LKPD kelompok Anda telah berhasil dikirimkan kepada guru.'
        );
      }
    } catch (err) {
      console.error('Error submitting answers:', err);
      alert('Gagal mengirimkan jawaban ke server.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Update LKPD (Teacher)
  const handleUpdateLKPD = async (updated: LKPDConfig) => {
    try {
      const res = await fetch('/api/lkpd', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updated),
      }).then((r) => r.json());

      if (res.success && res.data) {
        setLkpdConfig(res.data);
      }
    } catch (err) {
      console.error('Failed to update LKPD:', err);
      throw err;
    }
  };

  // Handle Grade Submission (Teacher)
  const handleGradeSubmission = async (
    id: string,
    scoreBreakdown: { fase2: number; fase3: number; fase4: number; fase5: number },
    teacherFeedback: string
  ) => {
    try {
      const res = await fetch(`/api/submissions/${id}/grade`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scoreBreakdown, teacherFeedback }),
      }).then((r) => r.json());

      if (res.success && res.data) {
        setSubmissions((prev) =>
          prev.map((s) => (s.id === id ? res.data : s))
        );
      }
    } catch (err) {
      console.error('Failed to save grade:', err);
      throw err;
    }
  };

  // Handle Delete Submission (Teacher)
  const handleDeleteSubmission = async (id: string) => {
    try {
      const res = await fetch(`/api/submissions/${id}`, {
        method: 'DELETE',
      }).then((r) => r.json());

      if (res.success) {
        setSubmissions((prev) => prev.filter((s) => s.id !== id));
      }
    } catch (err) {
      console.error('Failed to delete submission:', err);
    }
  };

  // Handle Trigger Reminder Broadcast
  const handleTriggerReminder = async (customMessage?: string) => {
    try {
      const res = await fetch('/api/reminders/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ customMessage }),
      }).then((r) => r.json());

      if (res.success && res.data) {
        setReminderLogs((prev) => [res.data, ...prev]);
        addToast(
          'info',
          'Notifikasi Pengingat Terkirim',
          res.message || 'Notifikasi pengingat keterlambatan berhasil disiarkan.'
        );
      }
    } catch (err) {
      console.error('Failed to send reminders:', err);
    }
  };

  const handleExportExcel = () => {
    if (!lkpdConfig) return;
    exportGradingToExcel(submissions, lkpdConfig);
  };

  if (!lkpdConfig) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="text-center space-y-3">
          <div className="w-10 h-10 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-xs font-semibold text-slate-600">
            Memuat LKPD Interaktif &amp; Sinkronisasi Data Real-Time...
          </p>
        </div>
      </div>
    );
  }

  const lateCount = submissions.filter((s) => s.isOverdue || s.status === 'late').length;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans antialiased selection:bg-indigo-500 selection:text-white">
      {/* Toast Notification Container */}
      <NotificationToast toasts={toasts} onDismiss={dismissToast} />

      {/* Share Modal */}
      <ShareModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        lkpdConfig={lkpdConfig}
      />

      {/* Main Top Navigation */}
      <Navbar
        currentView={currentView}
        onSwitchView={setCurrentView}
        lkpdConfig={lkpdConfig}
        isRealtimeConnected={isRealtimeConnected}
        submissionCount={submissions.length}
        overdueCount={lateCount}
        onExportExcel={handleExportExcel}
        onOpenShareModal={() => setIsShareModalOpen(true)}
        onTriggerReminder={() => handleTriggerReminder()}
      />

      {/* Main Application Content Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 flex-grow w-full">
        {currentView === 'student' ? (
          <StudentView
            lkpdConfig={lkpdConfig}
            currentSubmission={currentSubmission}
            onSaveDraft={handleSaveDraft}
            onSubmitAnswers={handleSubmitAnswers}
            isSubmitting={isSubmitting}
          />
        ) : (
          <TeacherDashboard
            lkpdConfig={lkpdConfig}
            submissions={submissions}
            reminderLogs={reminderLogs}
            onUpdateLKPD={handleUpdateLKPD}
            onGradeSubmission={handleGradeSubmission}
            onDeleteSubmission={handleDeleteSubmission}
            onTriggerReminder={handleTriggerReminder}
            onSwitchToStudentView={() => setCurrentView('student')}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 text-xs py-6 border-t border-slate-800 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-wrap items-center justify-between gap-3 text-center sm:text-left">
          <div>
            <p className="font-semibold text-slate-200">
              Media Pembelajaran LKPD Kimia Berbasis Problem Based Learning (PBL) &amp; Dashboard Guru.
            </p>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Dilengkapi sinkronisasi real-time antar perangkat, sistem notifikasi otomatis keterlambatan, dan ekspor penilaian Excel (.xlsx).
            </p>
          </div>
          <div className="flex items-center gap-3 text-[11px] text-slate-400">
            <span>Materi: Sel Volta SMA/SMK Kelas XII</span>
            <span>•</span>
            <button
              onClick={() => setCurrentView(currentView === 'student' ? 'teacher' : 'student')}
              className="text-indigo-400 hover:text-indigo-300 font-semibold underline"
            >
              Beralih ke {currentView === 'student' ? 'Dashboard Guru' : 'Mode Siswa'}
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
