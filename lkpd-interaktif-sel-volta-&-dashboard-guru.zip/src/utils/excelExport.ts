import * as XLSX from 'xlsx';
import type { StudentSubmission, LKPDConfig } from '../types.js';

export function exportGradingToExcel(
  submissions: StudentSubmission[],
  lkpdConfig: LKPDConfig
) {
  const wb = XLSX.utils.book_new();

  // 1. Sheet 1: Rekapitulasi Nilai Siswa
  const sheet1Data: (string | number)[][] = [
    ['LEMBAR REKAPITULASI PENILAIAN HASIL BELAJAR SISWA'],
    ['MATA PELAJARAN:', lkpdConfig.subject],
    ['JUDUL LKPD:', lkpdConfig.title],
    ['TENGGAT WAKTU (DEADLINE):', new Date(lkpdConfig.deadline).toLocaleString('id-ID')],
    ['TANGGAL UNDUH LAPORAN:', new Date().toLocaleString('id-ID')],
    [],
    [
      'No',
      'Nama Kelompok',
      'Kelas',
      'Daftar Anggota',
      'Waktu Pengumpulan',
      'Status Ketepatan Waktu',
      'Fase 2: Masalah & Hipotesis (20)',
      'Fase 3: Penyelidikan & Konsep (30)',
      'Fase 4: Solusi & Argumen (30)',
      'Fase 5: HOTS & Refleksi (20)',
      'Total Nilai (100)',
      'Kategori Capaian',
      'Catatan / Umpan Balik Guru',
      'Waktu Dinilai',
    ],
  ];

  submissions.forEach((sub, idx) => {
    const isLate = sub.isOverdue || sub.status === 'late';
    const statusKetepatan = sub.submittedAt
      ? isLate
        ? 'Terlambat'
        : 'Tepat Waktu'
      : 'Belum Selesai';

    let kategori = '-';
    if (sub.totalScore !== null) {
      if (sub.totalScore >= 90) kategori = 'Sangat Baik (A)';
      else if (sub.totalScore >= 80) kategori = 'Baik (B)';
      else if (sub.totalScore >= 70) kategori = 'Cukup / KKM (C)';
      else kategori = 'Perlu Bimbingan / Remedial';
    }

    sheet1Data.push([
      idx + 1,
      sub.groupName,
      sub.classGrade,
      (sub.members || []).join(', '),
      sub.submittedAt ? new Date(sub.submittedAt).toLocaleString('id-ID') : 'Belum Submit',
      statusKetepatan,
      sub.scoreBreakdown?.fase2 ?? 0,
      sub.scoreBreakdown?.fase3 ?? 0,
      sub.scoreBreakdown?.fase4 ?? 0,
      sub.scoreBreakdown?.fase5 ?? 0,
      sub.totalScore !== null ? sub.totalScore : 'Belum Dinilai',
      kategori,
      sub.teacherFeedback || '-',
      sub.gradedAt ? new Date(sub.gradedAt).toLocaleString('id-ID') : '-',
    ]);
  });

  const ws1 = XLSX.utils.aoa_to_sheet(sheet1Data);
  // Auto column widths
  ws1['!cols'] = [
    { wch: 5 },  // No
    { wch: 25 }, // Kelompok
    { wch: 12 }, // Kelas
    { wch: 35 }, // Anggota
    { wch: 22 }, // Waktu Submit
    { wch: 18 }, // Status
    { wch: 15 }, // F2
    { wch: 15 }, // F3
    { wch: 15 }, // F4
    { wch: 15 }, // F5
    { wch: 14 }, // Total
    { wch: 24 }, // Kategori
    { wch: 40 }, // Umpan Balik
    { wch: 20 }, // Waktu Dinilai
  ];
  XLSX.utils.book_append_sheet(wb, ws1, 'Rekapitulasi Nilai');

  // 2. Sheet 2: Detail Jawaban Per Fase
  const sheet2Data = [
    ['DETAIL ANALISIS JAWABAN SISWA PER FASE LKPD (PBL SEL VOLTA)'],
    [],
    [
      'Nama Kelompok',
      'Kelas',
      'Fase 1 & 2: Rumusan Masalah Galvani-Volta',
      'Fase 2: Hipotesis Galvani-Volta',
      'Fase 2 TCK: Pemahaman Transfer Ion Jembatan Garam',
      'Fase 3: Pembuatan Jembatan Garam Agar KCl',
      'Fase 3: Tegangan Eksperimen Zn-Cu (V)',
      'Fase 4: Perhitungan Galat Persen (% Error)',
      'Fase 4: Analisis Faktor Galat Eksperimen',
      'Fase 4: Notasi Sel Zn-Cu',
      'Fase 4: Notasi Sel Mg-Cu',
      'Fase 4: Notasi Sel Al-Cu',
      'Fase 4: Notasi Sel Fe-Cu',
      'Fase 4: Notasi Sel Zn-Fe',
      'Fase 4: Urutan Deret Volta (Daya Desak)',
      'Fase 4: Solusi Kasus 1 (Baterai Lemon)',
      'Fase 4: Rekomendasi Kasus 2 (Tangki ZnSO4)',
      'Fase 5: HOTS Part A (Urutan Reduktor)',
      'Fase 5: HOTS Part B (E°sel C-D)',
      'Fase 5: HOTS Part C (Proteksi Katodik)',
      'Fase 5: Refleksi Metakognisi Belajar',
    ],
  ];

  submissions.forEach((sub) => {
    const a = sub.answers || {};
    sheet2Data.push([
      sub.groupName,
      sub.classGrade,
      a.prob_galvani_volta || a.prob1 || '-',
      a.hypo_galvani_volta || a.hypo1 || '-',
      a.tck_salt_bridge_role || a.scaff1_3 || '-',
      a.salt_bridge_understanding || '-',
      a.exp_zn_cu_volt || '1.08',
      a.percent_error_zn_cu || '-',
      a.error_analysis || '-',
      a.notation_zn_cu || 'Zn | Zn²⁺ || Cu²⁺ | Cu',
      a.notation_mg_cu || '-',
      a.notation_al_cu || '-',
      a.notation_fe_cu || '-',
      a.notation_zn_fe || '-',
      a.volta_series_order || '-',
      a.solCase1 || '-',
      a.case2_recommendation || '-',
      a.hots_a || '-',
      a.hots_b || '-',
      a.hots_3_corrosion || '-',
      a.reflection || '-',
    ]);
  });

  const ws2 = XLSX.utils.aoa_to_sheet(sheet2Data);
  ws2['!cols'] = [
    { wch: 22 }, // Kelompok
    { wch: 12 }, // Kelas
    { wch: 35 }, // Masalah Galvani-Volta
    { wch: 35 }, // Hipotesis
    { wch: 35 }, // TCK Jembatan Garam
    { wch: 30 }, // Agar KCl
    { wch: 18 }, // Tegangan Exp
    { wch: 18 }, // % Galat
    { wch: 35 }, // Analisis Galat
    { wch: 25 }, // Notasi Zn-Cu
    { wch: 25 }, // Notasi Mg-Cu
    { wch: 25 }, // Notasi Al-Cu
    { wch: 25 }, // Notasi Fe-Cu
    { wch: 25 }, // Notasi Zn-Fe
    { wch: 28 }, // Deret Volta
    { wch: 35 }, // Kasus 1
    { wch: 35 }, // Kasus 2
    { wch: 25 }, // HOTS A
    { wch: 22 }, // HOTS B
    { wch: 35 }, // HOTS C
    { wch: 35 }, // Refleksi
  ];
  XLSX.utils.book_append_sheet(wb, ws2, 'Detail Jawaban Siswa');

  // 3. Sheet 3: Monitoring Keterlambatan Seluruh Kelompok Target
  const sheet3Data: (string | number)[][] = [
    ['LAPORAN KONTROL PENYELESAIAN & KETERLAMBATAN KELOMPOK TARGET'],
    ['BATAS TENGGAT WAKTU (DEADLINE):', new Date(lkpdConfig.deadline).toLocaleString('id-ID')],
    [],
    [
      'No',
      'Nama Kelompok Terdaftar',
      'Kelas',
      'Ketua Kelompok',
      'Status Pengerjaan',
      'Keterangan Waktu',
      'Perlu Notifikasi Pengingat?',
    ],
  ];

  const now = new Date().toISOString();
  const isPastDeadline = Boolean(lkpdConfig.deadline && now > lkpdConfig.deadline);

  lkpdConfig.targetGroups.forEach((tg, idx) => {
    const foundSub = submissions.find(
      (s) => s.groupName.toLowerCase() === tg.name.toLowerCase()
    );

    let statusStr = 'Belum Mengumpulkan';
    let ketWaktu = isPastDeadline ? 'Melewati Batas Waktu (Terlambat)' : 'Masih dalam tenggat';
    let perluReminder = 'YA';

    if (foundSub) {
      if (foundSub.status === 'graded') {
        statusStr = `Selesai Dinilai (${foundSub.totalScore}/100)`;
        ketWaktu = foundSub.isOverdue ? 'Terkirim Terlambat' : 'Terkirim Tepat Waktu';
        perluReminder = 'TIDAK';
      } else if (foundSub.status === 'submitted') {
        statusStr = 'Sudah Kirim (Menunggu Penilaian Guru)';
        ketWaktu = foundSub.isOverdue ? 'Terkirim Terlambat' : 'Terkirim Tepat Waktu';
        perluReminder = 'TIDAK';
      } else if (foundSub.status === 'draft') {
        statusStr = 'Sedang Mengerjakan (Draf Tersimpan)';
        ketWaktu = isPastDeadline ? 'Terlambat Belum Submit' : 'Masih Proses';
        perluReminder = 'YA';
      }
    }

    sheet3Data.push([
      idx + 1,
      tg.name,
      tg.classGrade,
      tg.leader,
      statusStr,
      ketWaktu,
      perluReminder,
    ]);
  });

  const ws3 = XLSX.utils.aoa_to_sheet(sheet3Data);
  ws3['!cols'] = [
    { wch: 5 },
    { wch: 25 },
    { wch: 12 },
    { wch: 22 },
    { wch: 30 },
    { wch: 28 },
    { wch: 25 },
  ];
  XLSX.utils.book_append_sheet(wb, ws3, 'Monitoring Keterlambatan');

  // Trigger file download
  const cleanTitle = lkpdConfig.title.replace(/[^a-zA-Z0-9]/g, '_').slice(0, 30);
  const dateStamp = new Date().toISOString().slice(0, 10);
  const fileName = `Rekap_Penilaian_${cleanTitle}_${dateStamp}.xlsx`;

  XLSX.writeFile(wb, fileName);
}
