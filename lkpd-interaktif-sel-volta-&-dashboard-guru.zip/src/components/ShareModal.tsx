import React, { useRef, useEffect, useState } from 'react';
import { X, Copy, Check, QrCode, MessageSquare, ExternalLink } from 'lucide-react';
import type { LKPDConfig } from '../types.js';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  lkpdConfig: LKPDConfig;
}

export const ShareModal: React.FC<ShareModalProps> = ({ isOpen, onClose, lkpdConfig }) => {
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedMsg, setCopiedMsg] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const shareUrl = typeof window !== 'undefined'
    ? window.location.origin + window.location.pathname + '?mode=student'
    : '';

  useEffect(() => {
    if (isOpen) {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const size = canvas.width;
      ctx.clearRect(0, 0, size, size);

      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, size, size);

      const grid = 21;
      const cell = size / grid;

      ctx.fillStyle = '#1e1b4b';

      const drawCorner = (startX: number, startY: number) => {
        ctx.fillRect(startX * cell, startY * cell, 7 * cell, 7 * cell);
        ctx.fillStyle = '#ffffff';
        ctx.fillRect((startX + 1) * cell, (startY + 1) * cell, 5 * cell, 5 * cell);
        ctx.fillStyle = '#1e1b4b';
        ctx.fillRect((startX + 2) * cell, (startY + 2) * cell, 3 * cell, 3 * cell);
      };

      drawCorner(0, 0);
      drawCorner(grid - 7, 0);
      drawCorner(0, grid - 7);

      for (let r = 0; r < grid; r++) {
        for (let c = 0; c < grid; c++) {
          const inCorner =
            (r < 8 && c < 8) || (r < 8 && c >= grid - 8) || (r >= grid - 8 && c < 8);
          if (!inCorner) {
            const charCode = shareUrl.charCodeAt((r * grid + c) % (shareUrl.length || 1));
            if ((charCode + r + c) % 3 === 0 || (r * c) % 5 === 0) {
              ctx.fillRect(c * cell, r * cell, cell - 0.5, cell - 0.5);
            }
          }
        }
      }
    }
  }, [isOpen, shareUrl]);

  if (!isOpen) return null;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl).then(() => {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 3000);
    });
  };

  const shareMsg = `⚡ *LINK LKPD INTERAKTIF SEL VOLTA*\n\nKepada seluruh siswa kelas XII,\nSilakan buka tautan berikut untuk menyelesaikan LKPD Kimia PBL bersama kelompok kalian:\n\n👉 *Link:* ${shareUrl}\n\n⏰ *Tenggat Waktu:* ${new Date(
    lkpdConfig.deadline
  ).toLocaleString('id-ID', { dateStyle: 'full', timeStyle: 'short' })}\n\nPastikan jawaban terkirim tepat waktu!`;

  const handleCopyMsg = () => {
    navigator.clipboard.writeText(shareMsg).then(() => {
      setCopiedMsg(true);
      setTimeout(() => setCopiedMsg(false), 3000);
    });
  };

  return (
    <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-5 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between border-b pb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-indigo-50 text-indigo-700 rounded-xl">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Bagikan Link LKPD ke Siswa
              </h3>
              <p className="text-xs text-slate-500">Akses langsung Mode Siswa secara online</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 text-xs">
          {/* Tautan */}
          <div className="bg-indigo-50/70 p-3.5 rounded-xl border border-indigo-200 space-y-1.5">
            <label className="block font-bold text-indigo-950">Tautan Langsung Siswa:</label>
            <div className="flex gap-2">
              <input
                type="text"
                readOnly
                value={shareUrl}
                className="w-full p-2 bg-white border border-indigo-300 rounded-lg font-mono text-[11px] text-indigo-900 select-all"
              />
              <button
                onClick={handleCopyLink}
                className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg transition whitespace-nowrap flex items-center gap-1 shadow-sm"
              >
                {copiedLink ? <Check className="w-4 h-4 text-amber-300" /> : <Copy className="w-4 h-4" />}
                <span>{copiedLink ? 'Tersalin' : 'Salin'}</span>
              </button>
            </div>
          </div>

          {/* QR Code */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex flex-col items-center justify-center text-center space-y-2">
            <span className="font-semibold text-slate-700">Pindai QR Code di Smartphone Siswa</span>
            <div className="p-2.5 bg-white rounded-xl shadow-xs border border-slate-200">
              <canvas ref={canvasRef} width={180} height={180} className="block rounded" />
            </div>
          </div>

          {/* WhatsApp Message */}
          <button
            onClick={handleCopyMsg}
            className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl transition flex items-center justify-center gap-2 shadow-sm"
          >
            {copiedMsg ? <Check className="w-4 h-4 text-amber-300" /> : <MessageSquare className="w-4 h-4" />}
            <span>{copiedMsg ? 'Teks Pesan WhatsApp Berhasil Disalin!' : 'Salin Template Pesan WhatsApp'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
