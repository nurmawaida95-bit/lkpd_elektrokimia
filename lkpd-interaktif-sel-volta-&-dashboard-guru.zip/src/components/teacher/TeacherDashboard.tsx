import React, { useState, useRef, useEffect } from 'react';
import {
  Users,
  Award,
  CheckCircle2,
  Clock,
  AlertTriangle,
  FileSpreadsheet,
  Edit3,
  Share2,
  Bell,
  Search,
  Trash2,
  Send,
  Sparkles,
  Layers,
  BarChart3,
  Copy,
  ExternalLink,
  MessageSquare,
  QrCode,
  Check,
  RefreshCw,
} from 'lucide-react';
import type { StudentSubmission, LKPDConfig, ReminderLog } from '../../types.js';
import { GradingModal } from './GradingModal.js';
import { exportGradingToExcel } from '../../utils/excelExport.js';

interface TeacherDashboardProps {
  lkpdConfig: LKPDConfig;
  submissions: StudentSubmission[];
  reminderLogs: ReminderLog[];
  onUpdateLKPD: (updated: LKPDConfig) => Promise<void>;
  onGradeSubmission: (
    id: string,
    scoreBreakdown: { fase2: number; fase3: number; fase4: number; fase5: number },
    teacherFeedback: string
  ) => Promise<void>;
  onDeleteSubmission: (id: string) => Promise<void>;
  onTriggerReminder: (customMsg?: string) => Promise<void>;
  onSwitchToStudentView: () => void;
}

export const TeacherDashboard: React.FC<TeacherDashboardProps> = ({
  lkpdConfig,
  submissions,
  reminderLogs,
  onUpdateLKPD,
  onGradeSubmission,
  onDeleteSubmission,
  onTriggerReminder,
  onSwitchToStudentView,
}) => {
  const [activeTab, setActiveTab] = useState<'recap' | 'editor' | 'share' | 'monitoring'>('recap');
  const [selectedSubForGrading, setSelectedSubForGrading] = useState<StudentSubmission | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'graded' | 'pending' | 'late'>('all');
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [copiedMsg, setCopiedMsg] = useState<boolean>(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Editor Form State (Local copy for editing)
  const [editLKPD, setEditLKPD] = useState<LKPDConfig>(JSON.parse(JSON.stringify(lkpdConfig)));
  const [isSavingEditor, setIsSavingEditor] = useState<boolean>(false);

  // QR Canvas Ref
  const qrCanvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    setEditLKPD(JSON.parse(JSON.stringify(lkpdConfig)));
  }, [lkpdConfig]);

  // Generate QR Code Pattern onto Canvas
  useEffect(() => {
    if (activeTab === 'share') {
      const canvas = qrCanvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const size = canvas.width;
      ctx.clearRect(0, 0, size, size);

      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, size, size);

      const shareUrl = window.location.origin + window.location.pathname + '?mode=student';
      const grid = 21;
      const cell = size / grid;

      ctx.fillStyle = '#1e1b4b';

      // Corner markers
      const drawCorner = (startX: number, startY: number) => {
        ctx.fillRect(startX * cell, startY * cell, 7 * cell, 7 * cell);
        ctx.fillStyle = '#ffffff';
        ctx.fillRect((startX + 1) * cell, (startY + 1) * cell, 5 * cell, 5 * cell);
        ctx.fillStyle = '#1e1b4b';
        ctx.fillRect((startX + 2) * cell, (startY + 2) * cell, 3 * cell, 3 * cell);
      };

      drawCorner(0, 0);
      drawCorner(grid - 7, 0);
      drawCorner(0, grid - 7);

      // Deterministic inner grid pattern
      for (let r = 0; r < grid; r++) {
        for (let c = 0; c < grid; c++) {
          const inCorner =
            (r < 8 && c < 8) || (r < 8 && c >= grid - 8) || (r >= grid - 8 && c < 8);
          if (!inCorner) {
            const charCode = shareUrl.charCodeAt((r * grid + c) % shareUrl.length);
            if ((charCode + r + c) % 3 === 0 || (r * c) % 5 === 0) {
              ctx.fillRect(c * cell, r * cell, cell - 0.5, cell - 0.5);
            }
          }
        }
      }
    }
  }, [activeTab]);

  // Statistics Calculations
  const totalSubmissions = submissions.length;
  const gradedList = submissions.filter((s) => s.totalScore !== null);
  const pendingList = submissions.filter((s) => s.totalScore === null);
  const lateList = submissions.filter((s) => s.isOverdue || s.status === 'late');

  const avgScore =
    gradedList.length > 0
      ? (
          gradedList.reduce((acc, curr) => acc + (curr.totalScore || 0), 0) /
          gradedList.length
        ).toFixed(1)
      : '0.0';

  // Average per phase
  const avgFase2 =
    gradedList.length > 0
      ? (
          gradedList.reduce((acc, curr) => acc + (curr.scoreBreakdown?.fase2 || 0), 0) /
          gradedList.length
        ).toFixed(1)
      : '0.0';

  const avgFase3 =
    gradedList.length > 0
      ? (
          gradedList.reduce((acc, curr) => acc + (curr.scoreBreakdown?.fase3 || 0), 0) /
          gradedList.length
        ).toFixed(1)
      : '0.0';

  const avgFase4 =
    gradedList.length > 0
      ? (
          gradedList.reduce((acc, curr) => acc + (curr.scoreBreakdown?.fase4 || 0), 0) /
          gradedList.length
        ).toFixed(1)
      : '0.0';

  const avgFase5 =
    gradedList.length > 0
      ? (
          gradedList.reduce((acc, curr) => acc + (curr.scoreBreakdown?.fase5 || 0), 0) /
          gradedList.length
        ).toFixed(1)
      : '0.0';

  // Target groups monitoring
  const submittedGroupNames = submissions.map((s) => s.groupName.toLowerCase());
  const unsubmittedTargetGroups = lkpdConfig.targetGroups.filter(
    (tg) => !submittedGroupNames.includes(tg.name.toLowerCase())
  );
  const isPastDeadline = Boolean(
    lkpdConfig.deadline && new Date().toISOString() > lkpdConfig.deadline
  );

  // Filter submissions
  const filteredSubmissions = submissions.filter((s) => {
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      s.groupName.toLowerCase().includes(q) ||
      s.classGrade.toLowerCase().includes(q) ||
      (s.members || []).some((m) => m.toLowerCase().includes(q));

    if (!matchesSearch) return false;

    if (statusFilter === 'graded') return s.totalScore !== null;
    if (statusFilter === 'pending') return s.totalScore === null;
    if (statusFilter === 'late') return s.isOverdue || s.status === 'late';
    return true;
  });

  const handleSaveEditor = async () => {
    setIsSavingEditor(true);
    try {
      await onUpdateLKPD(editLKPD);
      setToastMsg('Pembaruan LKPD berhasil disimpan dan disinkronkan ke seluruh siswa!');
      setTimeout(() => setToastMsg(null), 4000);
    } catch (e) {
      alert('Gagal menyimpan pembaruan LKPD.');
    } finally {
      setIsSavingEditor(false);
    }
  };

  const handleCopyShareLink = () => {
    const shareUrl = window.location.origin + window.location.pathname + '?mode=student';
    navigator.clipboard.writeText(shareUrl).then(() => {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 3000);
    });
  };

  const getShareMessageTemplate = () => {
    const shareUrl = window.location.origin + window.location.pathname + '?mode=student';
    return `⚡ *TUGAS LKPD INTERAKTIF KIMIA - SEL VOLTA*\n\nKepada seluruh siswa kelas XII,\nSilakan buka tautan berikut untuk menyelesaikan LKPD berbasis Masalah (PBL) bersama kelompok kalian:\n\n👉 *Link LKPD:* ${shareUrl}\n\n⏰ *Tenggat Waktu:* ${new Date(
      lkpdConfig.deadline
    ).toLocaleString('id-ID', {
      dateStyle: 'full',
      timeStyle: 'short',
    })}\n\nPastikan data kelompok terisi lengkap dan kirimkan sebelum batas waktu. Selamat berdiskusi!`;
  };

  const handleCopyShareMsg = () => {
    const msg = getShareMessageTemplate();
    navigator.clipboard.writeText(msg).then(() => {
      setCopiedMsg(true);
      setTimeout(() => setCopiedMsg(false), 3000);
    });
  };

  return (
    <div className="space-y-6 pb-16">
      {/* Toast Alert */}
      {toastMsg && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-2xl border border-emerald-500/50 flex items-center gap-3 animate-in fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          <span className="text-xs font-semibold">{toastMsg}</span>
        </div>
      )}

      {/* Teacher Tabs Header */}
      <div className="bg-white rounded-2xl p-2 shadow-xs border border-slate-200 flex flex-wrap gap-2 items-center justify-between">
        <div className="flex flex-wrap gap-1.5">
          <button
            onClick={() => setActiveTab('recap')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
              activeTab === 'recap'
                ? 'bg-indigo-900 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>Rekap &amp; Penilaian Responden</span>
            <span className="px-1.5 py-0.5 rounded-full bg-indigo-800 text-[10px] text-white">
              {totalSubmissions}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('editor')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
              activeTab === 'editor'
                ? 'bg-indigo-900 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Edit3 className="w-4 h-4" />
            <span>Editor LKPD &amp; Wacana</span>
          </button>

          <button
            onClick={() => setActiveTab('monitoring')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 relative ${
              activeTab === 'monitoring'
                ? 'bg-indigo-900 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>Monitoring Keterlambatan</span>
            {unsubmittedTargetGroups.length > 0 && isPastDeadline && (
              <span className="px-1.5 py-0.5 bg-rose-500 text-white rounded-full text-[10px] font-bold">
                {unsubmittedTargetGroups.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('share')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
              activeTab === 'share'
                ? 'bg-indigo-900 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Share2 className="w-4 h-4" />
            <span>Bagikan Link &amp; QR Code</span>
          </button>
        </div>

        <div className="flex items-center gap-2 pr-2">
          <button
            onClick={() => exportGradingToExcel(submissions, lkpdConfig)}
            className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 shadow-sm"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Unduh Format Excel (.xlsx)</span>
          </button>
        </div>
      </div>

      {/* ================= TAB 1: REKAP RESPONDEN & PENILAIAN ================= */}
      {activeTab === 'recap' && (
        <div className="space-y-6">
          {/* Executive KPI Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-1">
              <span className="text-[11px] font-bold uppercase text-slate-500">
                Total Submisi Kelompok
              </span>
              <p className="text-2xl font-extrabold text-slate-900">{totalSubmissions}</p>
              <span className="text-[11px] text-slate-400">Dari {lkpdConfig.targetGroups.length} kelompok terdaftar</span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-1">
              <span className="text-[11px] font-bold uppercase text-slate-500">
                Rata-Rata Nilai Kelas
              </span>
              <p className="text-2xl font-extrabold text-emerald-600 font-mono">{avgScore}</p>
              <span className="text-[11px] text-slate-400">Skala 0 - 100</span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-1">
              <span className="text-[11px] font-bold uppercase text-slate-500">
                Sudah Dinilai Guru
              </span>
              <p className="text-2xl font-extrabold text-indigo-700">{gradedList.length}</p>
              <span className="text-[11px] text-slate-400">Memiliki skor evaluasi</span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-1">
              <span className="text-[11px] font-bold uppercase text-slate-500">
                Menunggu Penilaian
              </span>
              <p className="text-2xl font-extrabold text-amber-600">{pendingList.length}</p>
              <span className="text-[11px] text-slate-400">Perlu pemeriksaan</span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-1">
              <span className="text-[11px] font-bold uppercase text-slate-500">
                Terkirim Terlambat
              </span>
              <p className="text-2xl font-extrabold text-rose-600">{lateList.length}</p>
              <span className="text-[11px] text-slate-400">Melewati batas tenggat</span>
            </div>
          </div>

          {/* Quick Alert Bar for Overdue Groups */}
          {(unsubmittedTargetGroups.length > 0 || lateList.length > 0) && (
            <div className="bg-rose-50 border border-rose-200 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 text-xs text-rose-900 shadow-xs">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-rose-200 text-rose-800 rounded-xl">
                  <AlertTriangle className="w-5 h-5 text-rose-700" />
                </div>
                <div>
                  <h4 className="font-bold text-sm">
                    Peringatan Keterlambatan Pengumpulan Tugas:
                  </h4>
                  <p className="text-rose-700">
                    Terdapat{' '}
                    <strong>{unsubmittedTargetGroups.length} kelompok belum mengumpulkan</strong>{' '}
                    dan <strong>{lateList.length} kelompok terkirim melewati batas waktu</strong>.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => onTriggerReminder()}
                  className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl transition flex items-center gap-1.5 shadow-sm"
                >
                  <Bell className="w-3.5 h-3.5" />
                  <span>Siarkan Notifikasi Pengingat Otomatis</span>
                </button>
              </div>
            </div>
          )}

          {/* Analytics Overview Card */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
            <h4 className="font-bold text-slate-800 text-sm flex items-center gap-2 border-b pb-2">
              <BarChart3 className="w-4 h-4 text-indigo-600" />
              <span>Sistem Pelaporan Perkembangan Belajar Siswa Per Fase PBL</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1.5">
                <div className="flex justify-between font-semibold text-slate-700">
                  <span>Fase 2 (Masalah &amp; Hipotesis)</span>
                  <span className="font-mono font-bold text-indigo-900">{avgFase2} / 20</span>
                </div>
                <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-indigo-600 h-full rounded-full transition-all duration-500"
                    style={{ width: `${(parseFloat(avgFase2) / 20) * 100}%` }}
                  ></div>
                </div>
              </div>

              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1.5">
                <div className="flex justify-between font-semibold text-slate-700">
                  <span>Fase 3 (Penyelidikan &amp; Konsep)</span>
                  <span className="font-mono font-bold text-indigo-900">{avgFase3} / 30</span>
                </div>
                <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-indigo-600 h-full rounded-full transition-all duration-500"
                    style={{ width: `${(parseFloat(avgFase3) / 30) * 100}%` }}
                  ></div>
                </div>
              </div>

              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1.5">
                <div className="flex justify-between font-semibold text-slate-700">
                  <span>Fase 4 (Solusi &amp; E°sel)</span>
                  <span className="font-mono font-bold text-indigo-900">{avgFase4} / 30</span>
                </div>
                <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-indigo-600 h-full rounded-full transition-all duration-500"
                    style={{ width: `${(parseFloat(avgFase4) / 30) * 100}%` }}
                  ></div>
                </div>
              </div>

              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1.5">
                <div className="flex justify-between font-semibold text-slate-700">
                  <span>Fase 5 (HOTS &amp; Refleksi)</span>
                  <span className="font-mono font-bold text-indigo-900">{avgFase5} / 20</span>
                </div>
                <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-indigo-600 h-full rounded-full transition-all duration-500"
                    style={{ width: `${(parseFloat(avgFase5) / 20) * 100}%` }}
                  ></div>
                </div>
              </div>
            </div>
          </div>

          {/* Submissions Table Card */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden space-y-4 p-5">
            {/* Table Filters Header */}
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-bold text-slate-800 text-sm">
                  Daftar Pengumpulan LKPD Siswa
                </h3>
                <p className="text-xs text-slate-500">
                  Klik tombol <strong>"Periksa &amp; Nilai"</strong> untuk meninjau detail jawaban
                  dan menginput rubrik.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {/* Search Input */}
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    placeholder="Cari kelompok / siswa..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-8 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 w-48"
                  />
                </div>

                {/* Filter Pills */}
                <div className="flex items-center bg-slate-100 p-0.5 rounded-lg text-xs">
                  <button
                    onClick={() => setStatusFilter('all')}
                    className={`px-2.5 py-1 rounded-md font-medium transition ${
                      statusFilter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                    }`}
                  >
                    Semua ({submissions.length})
                  </button>
                  <button
                    onClick={() => setStatusFilter('graded')}
                    className={`px-2.5 py-1 rounded-md font-medium transition ${
                      statusFilter === 'graded' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                    }`}
                  >
                    Dinilai ({gradedList.length})
                  </button>
                  <button
                    onClick={() => setStatusFilter('pending')}
                    className={`px-2.5 py-1 rounded-md font-medium transition ${
                      statusFilter === 'pending' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                    }`}
                  >
                    Pending ({pendingList.length})
                  </button>
                  <button
                    onClick={() => setStatusFilter('late')}
                    className={`px-2.5 py-1 rounded-md font-medium transition ${
                      statusFilter === 'late' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                    }`}
                  >
                    Terlambat ({lateList.length})
                  </button>
                </div>
              </div>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 text-slate-700 border-b border-slate-200">
                    <th className="p-3 font-bold">Nama Kelompok</th>
                    <th className="p-3 font-bold">Kelas</th>
                    <th className="p-3 font-bold">Anggota Kelompok</th>
                    <th className="p-3 font-bold">Waktu Submit</th>
                    <th className="p-3 font-bold text-center">Ketepatan</th>
                    <th className="p-3 font-bold text-center">Nilai Akhir</th>
                    <th className="p-3 font-bold text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredSubmissions.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="p-6 text-center text-slate-400">
                        Tidak ada submisi kelompok yang cocok dengan filter.
                      </td>
                    </tr>
                  ) : (
                    filteredSubmissions.map((sub) => {
                      const isLate = sub.isOverdue || sub.status === 'late';
                      return (
                        <tr key={sub.id} className="hover:bg-slate-50/80 transition">
                          <td className="p-3 font-bold text-slate-900">{sub.groupName}</td>
                          <td className="p-3 text-slate-600">{sub.classGrade}</td>
                          <td className="p-3 text-slate-600 max-w-xs truncate">
                            {(sub.members || []).join(', ') || '-'}
                          </td>
                          <td className="p-3 text-slate-500 font-mono text-[11px]">
                            {sub.submittedAt
                              ? new Date(sub.submittedAt).toLocaleString('id-ID', {
                                  dateStyle: 'short',
                                  timeStyle: 'short',
                                })
                              : 'Draf'}
                          </td>
                          <td className="p-3 text-center">
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                isLate
                                  ? 'bg-rose-100 text-rose-800'
                                  : 'bg-emerald-100 text-emerald-800'
                              }`}
                            >
                              {isLate ? 'Terlambat' : 'Tepat Waktu'}
                            </span>
                          </td>
                          <td className="p-3 text-center">
                            {sub.totalScore !== null ? (
                              <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-lg font-bold font-mono">
                                {sub.totalScore} / 100
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 bg-amber-100 text-amber-800 rounded-lg text-[11px] font-semibold">
                                Belum Dinilai
                              </span>
                            )}
                          </td>
                          <td className="p-3 text-right space-x-1.5 whitespace-nowrap">
                            <button
                              onClick={() => setSelectedSubForGrading(sub)}
                              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg transition shadow-xs"
                            >
                              Periksa &amp; Nilai
                            </button>
                            <button
                              onClick={() => {
                                if (confirm(`Hapus data pengumpulan ${sub.groupName}?`)) {
                                  onDeleteSubmission(sub.id);
                                }
                              }}
                              className="p-1.5 bg-slate-100 hover:bg-rose-100 text-slate-500 hover:text-rose-600 rounded-lg transition"
                              title="Hapus Submisi"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 2: EDITOR LKPD & WACANA ================= */}
      {activeTab === 'editor' && (
        <div className="bg-white rounded-2xl p-6 shadow-xs border border-slate-200 space-y-6">
          <div className="flex flex-wrap items-center justify-between border-b pb-3 gap-2">
            <div>
              <h3 className="text-base font-bold text-slate-800">
                Editor LKPD: Kustomisasi Wacana, Soal &amp; Tenggat Waktu
              </h3>
              <p className="text-xs text-slate-500">
                Setiap perubahan yang Anda simpan akan tersinkronisasi secara real-time ke layar
                seluruh siswa.
              </p>
            </div>

            <button
              onClick={handleSaveEditor}
              disabled={isSavingEditor}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition flex items-center gap-1.5 shadow-md active:scale-98"
            >
              <Check className="w-4 h-4" />
              <span>{isSavingEditor ? 'Menyimpan...' : 'Simpan & Sinkronkan LKPD'}</span>
            </button>
          </div>

          <div className="space-y-5 text-xs">
            {/* General Info & Deadline */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
              <h4 className="font-bold text-indigo-950 text-sm border-b pb-1">
                1. Informasi Pokok LKPD &amp; Batas Tenggat Waktu
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Judul Utama LKPD:
                  </label>
                  <input
                    type="text"
                    value={editLKPD.title}
                    onChange={(e) => setEditLKPD({ ...editLKPD, title: e.target.value })}
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg font-medium"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Mata Pelajaran &amp; Jenjang:
                  </label>
                  <input
                    type="text"
                    value={editLKPD.subject}
                    onChange={(e) => setEditLKPD({ ...editLKPD, subject: e.target.value })}
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Topik Materi:
                  </label>
                  <input
                    type="text"
                    value={editLKPD.topic}
                    onChange={(e) => setEditLKPD({ ...editLKPD, topic: e.target.value })}
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-rose-700 mb-1 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    <span>Tenggat Waktu Pengumpulan (Deadline):</span>
                  </label>
                  <input
                    type="datetime-local"
                    value={editLKPD.deadline || ''}
                    onChange={(e) => setEditLKPD({ ...editLKPD, deadline: e.target.value })}
                    className="w-full p-2 bg-white border border-rose-300 rounded-lg font-bold text-slate-800"
                  />
                  <span className="text-[10px] text-slate-500 mt-0.5 block">
                    Notifikasi otomatis akan terpicu jika siswa belum mengirim sebelum batas ini.
                  </span>
                </div>
              </div>
            </div>

            {/* Cases Editor */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Case 1 */}
              <div className="bg-amber-50/70 p-4 rounded-xl border border-amber-200 space-y-2">
                <h4 className="font-bold text-amber-950 text-sm">
                  2. Wacana Kasus 1 (Baterai Buah Lemon)
                </h4>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Judul Kasus 1:</label>
                  <input
                    type="text"
                    value={editLKPD.case1.title}
                    onChange={(e) =>
                      setEditLKPD({
                        ...editLKPD,
                        case1: { ...editLKPD.case1, title: e.target.value },
                      })
                    }
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg font-medium"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Deskripsi Masalah Kasus 1:
                  </label>
                  <textarea
                    rows={4}
                    value={editLKPD.case1.description}
                    onChange={(e) =>
                      setEditLKPD({
                        ...editLKPD,
                        case1: { ...editLKPD.case1, description: e.target.value },
                      })
                    }
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Petunjuk Guru:</label>
                  <input
                    type="text"
                    value={editLKPD.case1.hint}
                    onChange={(e) =>
                      setEditLKPD({
                        ...editLKPD,
                        case1: { ...editLKPD.case1, hint: e.target.value },
                      })
                    }
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              {/* Case 2 */}
              <div className="bg-indigo-50/70 p-4 rounded-xl border border-indigo-200 space-y-2">
                <h4 className="font-bold text-indigo-950 text-sm">
                  3. Wacana Kasus 2 (Bahan Tangki Logam ZnSO₄)
                </h4>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Judul Kasus 2:</label>
                  <input
                    type="text"
                    value={editLKPD.case2.title}
                    onChange={(e) =>
                      setEditLKPD({
                        ...editLKPD,
                        case2: { ...editLKPD.case2, title: e.target.value },
                      })
                    }
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg font-medium"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Deskripsi Masalah Kasus 2:
                  </label>
                  <textarea
                    rows={4}
                    value={editLKPD.case2.description}
                    onChange={(e) =>
                      setEditLKPD({
                        ...editLKPD,
                        case2: { ...editLKPD.case2, description: e.target.value },
                      })
                    }
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Petunjuk Guru:</label>
                  <input
                    type="text"
                    value={editLKPD.case2.hint}
                    onChange={(e) =>
                      setEditLKPD({
                        ...editLKPD,
                        case2: { ...editLKPD.case2, hint: e.target.value },
                      })
                    }
                    className="w-full p-2 bg-white border border-slate-300 rounded-lg"
                  />
                </div>
              </div>
            </div>

            {/* HOTS Context */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
              <h4 className="font-bold text-indigo-950 text-sm">
                4. Soal Evaluasi HOTS (Fase 5)
              </h4>
              <label className="block font-semibold text-slate-700">
                Konteks Data Potensial Sel Sel Volta:
              </label>
              <textarea
                rows={3}
                value={editLKPD.hotsQuestion.context}
                onChange={(e) =>
                  setEditLKPD({
                    ...editLKPD,
                    hotsQuestion: { ...editLKPD.hotsQuestion, context: e.target.value },
                  })
                }
                className="w-full p-2 bg-white border border-slate-300 rounded-lg font-mono text-[11px]"
              />
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 3: BAGIKAN LINK & DISTRIBUSI SISWA ================= */}
      {activeTab === 'share' && (
        <div className="bg-white rounded-2xl p-6 shadow-xs border border-slate-200 space-y-6">
          <div className="border-b pb-3">
            <span className="px-2.5 py-1 bg-indigo-100 text-indigo-800 rounded-full text-xs font-bold uppercase mb-2 inline-block">
              Akses &amp; Distribusi LKPD
            </span>
            <h3 className="text-lg font-bold text-slate-800">
              Bagikan Tautan Website LKPD Interaktif kepada Siswa
            </h3>
            <p className="text-xs text-slate-500">
              Salin tautan langsung atau tampilkan QR Code visual pada layar proyektor kelas.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 text-xs items-start">
            {/* Left: URLs & Template */}
            <div className="md:col-span-7 space-y-4">
              <div className="bg-indigo-50/70 p-4 rounded-xl border border-indigo-200 space-y-2">
                <label className="block font-bold text-indigo-950">
                  1. Tautan Langsung Mode Siswa (URL):
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    readOnly
                    value={window.location.origin + window.location.pathname + '?mode=student'}
                    className="w-full p-2.5 bg-white border border-indigo-300 rounded-lg font-mono text-[11px] text-indigo-900 select-all"
                  />
                  <button
                    onClick={handleCopyShareLink}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg transition whitespace-nowrap flex items-center gap-1.5 shadow-sm"
                  >
                    {copiedLink ? <Check className="w-4 h-4 text-amber-300" /> : <Copy className="w-4 h-4" />}
                    <span>{copiedLink ? 'Tersalin!' : 'Salin'}</span>
                  </button>
                </div>
                <p className="text-[11px] text-indigo-700">
                  Siswa yang membuka tautan ini akan langsung diarahkan ke lembar kerja interaktif
                  PBL.
                </p>
              </div>

              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                <label className="block font-bold text-slate-800">
                  2. Template Pesan Pengumuman (WhatsApp / LMS Google Classroom):
                </label>
                <textarea
                  rows={6}
                  readOnly
                  value={getShareMessageTemplate()}
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-lg font-sans text-xs select-all leading-relaxed"
                />
                <button
                  onClick={handleCopyShareMsg}
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl transition flex items-center justify-center gap-2 shadow-sm"
                >
                  {copiedMsg ? <Check className="w-4 h-4 text-amber-300" /> : <MessageSquare className="w-4 h-4" />}
                  <span>{copiedMsg ? 'Teks Pesan Berhasil Disalin!' : 'Salin Pesan WhatsApp'}</span>
                </button>
              </div>

              <div className="pt-2">
                <button
                  onClick={onSwitchToStudentView}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white font-semibold rounded-xl text-xs transition flex items-center gap-2"
                >
                  <ExternalLink className="w-4 h-4 text-amber-400" />
                  <span>Buka Tampilan Mode Siswa di Tab Ini</span>
                </button>
              </div>
            </div>

            {/* Right: QR Code Visualizer */}
            <div className="md:col-span-5 bg-slate-50 p-6 rounded-xl border border-slate-200 flex flex-col items-center justify-center text-center space-y-3">
              <h4 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
                <QrCode className="w-4 h-4 text-indigo-600" />
                <span>QR Code Akses Cepat Kelas</span>
              </h4>
              <p className="text-slate-500 text-[11px] max-w-xs">
                Siswa dapat langsung memindai QR Code ini menggunakan kamera smartphone untuk
                membuka lembar kerja.
              </p>

              <div className="p-3 bg-white rounded-2xl shadow-md border border-slate-200">
                <canvas
                  ref={qrCanvasRef}
                  width={210}
                  height={210}
                  className="rounded-lg block"
                />
              </div>

              <span className="text-[10px] text-slate-400 font-mono">
                LKPD PBL Sel Volta Interactive System
              </span>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 4: MONITORING KETERLAMBATAN & NOTIFIKASI ================= */}
      {activeTab === 'monitoring' && (
        <div className="space-y-6">
          {/* Header Action Banner */}
          <div className="bg-white rounded-2xl p-6 shadow-xs border border-slate-200 flex flex-wrap items-center justify-between gap-4">
            <div>
              <span className="px-2.5 py-1 bg-amber-100 text-amber-900 rounded-full text-xs font-bold uppercase mb-2 inline-block">
                Sistem Notifikasi &amp; Kontrol Progres
              </span>
              <h3 className="text-lg font-bold text-slate-800">
                Monitoring Progres Belajar &amp; Pengingat Keterlambatan Otomatis
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Pantau kelompok yang belum mengumpulkan tugas dan kirimkan notifikasi pengingat
                secara otomatis.
              </p>
            </div>

            <button
              onClick={() => onTriggerReminder()}
              className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl transition flex items-center gap-2 shadow-md active:scale-98"
            >
              <Bell className="w-4 h-4 text-amber-300" />
              <span>Kirim Pengingat Otomatis ke Seluruh Siswa Terlambat</span>
            </button>
          </div>

          {/* Monitoring Table */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden p-5 space-y-4">
            <h4 className="font-bold text-slate-800 text-sm">
              Status Pengerjaan Seluruh Kelompok Terdaftar ({lkpdConfig.targetGroups.length} Kelompok)
            </h4>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 text-slate-700 border-b border-slate-200">
                    <th className="p-3 font-bold">No</th>
                    <th className="p-3 font-bold">Nama Kelompok</th>
                    <th className="p-3 font-bold">Kelas</th>
                    <th className="p-3 font-bold">Ketua Kelompok</th>
                    <th className="p-3 font-bold text-center">Status Pengerjaan</th>
                    <th className="p-3 font-bold text-center">Keterangan Tenggat</th>
                    <th className="p-3 font-bold text-right">Aksi Cepat</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {lkpdConfig.targetGroups.map((tg, idx) => {
                    const foundSub = submissions.find(
                      (s) => s.groupName.toLowerCase() === tg.name.toLowerCase()
                    );
                    const isSubmitted = foundSub && foundSub.status !== 'draft';
                    const isGraded = foundSub && foundSub.status === 'graded';
                    const isLate = foundSub ? foundSub.isOverdue : isPastDeadline;

                    return (
                      <tr key={tg.id} className="hover:bg-slate-50/80 transition">
                        <td className="p-3 text-slate-500">{idx + 1}</td>
                        <td className="p-3 font-bold text-slate-900">{tg.name}</td>
                        <td className="p-3 text-slate-600">{tg.classGrade}</td>
                        <td className="p-3 text-slate-700">{tg.leader}</td>
                        <td className="p-3 text-center">
                          {isGraded ? (
                            <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-lg font-bold">
                              Selesai Dinilai ({foundSub.totalScore}/100)
                            </span>
                          ) : isSubmitted ? (
                            <span className="px-2.5 py-1 bg-blue-100 text-blue-800 rounded-lg font-bold">
                              Sudah Mengumpulkan
                            </span>
                          ) : foundSub ? (
                            <span className="px-2.5 py-1 bg-amber-100 text-amber-800 rounded-lg font-bold">
                              Sedang Mengerjakan (Draf)
                            </span>
                          ) : (
                            <span className="px-2.5 py-1 bg-slate-100 text-slate-600 rounded-lg font-semibold">
                              Belum Mulai
                            </span>
                          )}
                        </td>
                        <td className="p-3 text-center">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              isLate
                                ? 'bg-rose-100 text-rose-800'
                                : 'bg-emerald-100 text-emerald-800'
                            }`}
                          >
                            {isLate ? 'Melewati Batas Waktu' : 'Tepat Waktu'}
                          </span>
                        </td>
                        <td className="p-3 text-right">
                          {!isSubmitted ? (
                            <button
                              onClick={() => {
                                const waMsg = encodeURIComponent(
                                  `Halo ${tg.leader} dari ${tg.name}, mengingatkan tugas LKPD Sel Volta belum diselesaikan. Mohon segera dikerjakan dan dikirimkan!`
                                );
                                window.open(`https://wa.me/?text=${waMsg}`, '_blank');
                              }}
                              className="px-3 py-1 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-lg text-[11px] transition shadow-xs"
                            >
                              Ingatkan via WA
                            </button>
                          ) : (
                            <span className="text-slate-400 text-[11px]">Tuntas</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Reminder History Log */}
          {reminderLogs.length > 0 && (
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
              <h4 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                <Clock className="w-4 h-4 text-indigo-600" />
                <span>Riwayat Log Notifikasi Pengingat yang Terkirim</span>
              </h4>

              <div className="divide-y divide-slate-100 text-xs">
                {reminderLogs.map((log) => (
                  <div key={log.id} className="py-2.5 flex flex-wrap justify-between items-center gap-2">
                    <div>
                      <span className="font-bold text-slate-800">
                        Pengingat Terkirim ke {log.targetCount} Kelompok:
                      </span>{' '}
                      <span className="text-slate-600">{log.targetGroupNames.join(', ')}</span>
                      <p className="text-[11px] text-slate-500 italic mt-0.5">"{log.message}"</p>
                    </div>
                    <span className="text-slate-400 font-mono text-[11px]">
                      {new Date(log.sentAt).toLocaleString('id-ID')}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Grading Modal */}
      {selectedSubForGrading && (
        <GradingModal
          submission={selectedSubForGrading}
          lkpdConfig={lkpdConfig}
          isOpen={Boolean(selectedSubForGrading)}
          onClose={() => setSelectedSubForGrading(null)}
          onSaveGrade={onGradeSubmission}
        />
      )}
    </div>
  );
};
