import React, { useState, useEffect } from 'react';
import { X, Check, Award, MessageSquare, AlertCircle, BookOpen } from 'lucide-react';
import type { StudentSubmission, LKPDConfig } from '../../types.js';

interface GradingModalProps {
  submission: StudentSubmission | null;
  lkpdConfig: LKPDConfig;
  isOpen: boolean;
  onClose: () => void;
  onSaveGrade: (
    submissionId: string,
    scoreBreakdown: { fase2: number; fase3: number; fase4: number; fase5: number },
    teacherFeedback: string
  ) => Promise<void>;
}

export const GradingModal: React.FC<GradingModalProps> = ({
  submission,
  lkpdConfig,
  isOpen,
  onClose,
  onSaveGrade,
}) => {
  const [fase2, setFase2] = useState<number>(18);
  const [fase3, setFase3] = useState<number>(27);
  const [fase4, setFase4] = useState<number>(28);
  const [fase5, setFase5] = useState<number>(18);
  const [feedback, setFeedback] = useState<string>('');
  const [isSaving, setIsSaving] = useState<boolean>(false);

  useEffect(() => {
    if (submission) {
      if (submission.scoreBreakdown) {
        setFase2(submission.scoreBreakdown.fase2 ?? 18);
        setFase3(submission.scoreBreakdown.fase3 ?? 27);
        setFase4(submission.scoreBreakdown.fase4 ?? 28);
        setFase5(submission.scoreBreakdown.fase5 ?? 18);
      } else {
        setFase2(18);
        setFase3(27);
        setFase4(28);
        setFase5(18);
      }
      setFeedback(submission.teacherFeedback || '');
    }
  }, [submission]);

  if (!isOpen || !submission) return null;

  const total = Math.min(100, Math.max(0, fase2 + fase3 + fase4 + fase5));

  let predicate = 'Perlu Bimbingan / Remedial';
  let badgeColor = 'bg-rose-100 text-rose-800 border-rose-200';
  if (total >= 90) {
    predicate = 'Sangat Baik (A)';
    badgeColor = 'bg-emerald-100 text-emerald-800 border-emerald-200';
  } else if (total >= 80) {
    predicate = 'Baik (B)';
    badgeColor = 'bg-blue-100 text-blue-800 border-blue-200';
  } else if (total >= 70) {
    predicate = 'Cukup / KKM (C)';
    badgeColor = 'bg-amber-100 text-amber-800 border-amber-200';
  }

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await onSaveGrade(
        submission.id,
        { fase2, fase3, fase4, fase5 },
        feedback
      );
      onClose();
    } catch (e) {
      alert('Gagal menyimpan nilai');
    } finally {
      setIsSaving(false);
    }
  };

  const ans = submission.answers || {};

  return (
    <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-5xl w-full shadow-2xl border border-slate-200 my-auto flex flex-col max-h-[92vh] overflow-hidden animate-in fade-in zoom-in-95">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-600 text-white rounded-xl shadow-xs">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold text-slate-900">
                  {submission.groupName}
                </h3>
                <span className="text-xs px-2 py-0.5 bg-indigo-100 text-indigo-800 rounded font-semibold">
                  {submission.classGrade}
                </span>
                {submission.isOverdue && (
                  <span className="text-[10px] px-2 py-0.5 bg-rose-100 text-rose-800 rounded font-bold">
                    Terlambat
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500">
                Anggota: {(submission.members || []).join(', ') || '-'} • Waktu kirim:{' '}
                {submission.submittedAt
                  ? new Date(submission.submittedAt).toLocaleString('id-ID')
                  : 'Draf'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto grid grid-cols-1 lg:grid-cols-12 gap-6 text-xs">
          {/* Left: Student Answers with Expected Keys */}
          <div className="lg:col-span-7 space-y-4 pr-1">
            <h4 className="font-bold text-slate-800 text-sm flex items-center gap-2 border-b pb-2">
              <BookOpen className="w-4 h-4 text-indigo-600" />
              <span>Pemeriksaan Jawaban Siswa &amp; Kunci Referensi</span>
            </h4>

            {/* Fase 1 & 2 */}
            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
              <div className="font-bold text-indigo-900 flex justify-between items-center">
                <span>Fase 1 &amp; 2: Orientasi Kontroversi Galvani-Volta &amp; Masalah</span>
                <span className="text-slate-400 font-normal">Maks 20 Poin</span>
              </div>
              <div>
                <span className="font-semibold text-slate-700 block">Rumusan Masalah (Kontroversi Listrik Katak vs Logam):</span>
                <p className="p-2 bg-white rounded border border-slate-200 text-slate-800 mt-0.5">
                  {ans.prob1 || <span className="italic text-slate-400">Tidak diisi</span>}
                </p>
              </div>
              <div>
                <span className="font-semibold text-slate-700 block">Hipotesis Kelompok:</span>
                <p className="p-2 bg-white rounded border border-slate-200 text-slate-800 mt-0.5">
                  {ans.hypo1 || <span className="italic text-slate-400">Tidak diisi</span>}
                </p>
              </div>
              <div>
                <span className="font-semibold text-slate-700 block">Pemahaman TCK (Aliran Elektron &amp; Transfer Ion Garam):</span>
                <p className="p-2 bg-white rounded border border-slate-200 text-slate-800 mt-0.5">
                  {ans.tck_explanation || <span className="italic text-slate-400">Tidak diisi</span>}
                </p>
              </div>
            </div>

            {/* Fase 3 */}
            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
              <div className="font-bold text-indigo-900 flex justify-between items-center">
                <span>Fase 3: Perakitan Sel Daniell &amp; Jembatan Garam KCl</span>
                <span className="text-slate-400 font-normal">Maks 30 Poin</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="font-semibold text-slate-700 block">Eksperimen Tegangan Zn-Cu:</span>
                  <p className="p-2 bg-white rounded border border-slate-200 text-slate-800 font-bold mt-0.5">
                    {ans.lab_exp_zn_cu ? `${ans.lab_exp_zn_cu} V` : '-'}
                  </p>
                  <span className="text-[10px] text-emerald-700 block mt-0.5">🔑 Teoritis: 1,10 V</span>
                </div>
                <div>
                  <span className="font-semibold text-slate-700 block">Kualitas Agar-agar KCl:</span>
                  <p className="p-2 bg-white rounded border border-slate-200 text-slate-800 mt-0.5">
                    {ans.agar_quality_obs || '-'}
                  </p>
                </div>
              </div>
              <div>
                <span className="font-semibold text-slate-700 block">
                  Scaffolding 1.1 (Anoda Oksidasi Zn-Cu):
                </span>
                <p className="p-2 bg-white rounded border border-slate-200 text-slate-800 mt-0.5">
                  {ans.scaff1_1 || <span className="italic text-slate-400">Tidak diisi</span>}
                </p>
                <span className="text-[10px] text-emerald-700 font-medium block mt-0.5">
                  🔑 Kunci: Logam Zn (Seng) karena E° lebih negatif (-0,76 V vs +0,34 V).
                </span>
              </div>
              <div>
                <span className="font-semibold text-slate-700 block">
                  Scaffolding 1.3 (Fungsi Jembatan Garam &amp; Notasi Sel):
                </span>
                <p className="p-2 bg-white rounded border border-slate-200 text-slate-800 mt-0.5">
                  {ans.scaff1_3 || <span className="italic text-slate-400">Tidak diisi</span>}
                </p>
                <span className="text-[10px] text-emerald-700 font-medium block mt-0.5">
                  🔑 Kunci: Menetralkan muatan ion (Cl⁻ ke anoda, K⁺ ke katoda); Notasi: Zn | Zn²⁺ || Cu²⁺ | Cu.
                </span>
              </div>
            </div>

            {/* Fase 4 */}
            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
              <div className="font-bold text-indigo-900 flex justify-between items-center">
                <span>Fase 4: Hasil Karya, Galat Persen &amp; Deret Volta</span>
                <span className="text-slate-400 font-normal">Maks 30 Poin</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="font-semibold text-slate-700 block">Perhitungan Galat Persen (%):</span>
                  <p className="p-2 bg-white rounded border border-slate-200 text-indigo-950 font-bold mt-0.5">
                    {ans.calc_error_zn_cu ? `${ans.calc_error_zn_cu}%` : '-'}
                  </p>
                  <span className="text-[10px] text-emerald-700 block mt-0.5">
                    Rumus: |(E°teoritis - E_eksperimen) / E°teoritis| × 100%
                  </span>
                </div>
                <div>
                  <span className="font-semibold text-slate-700 block">Urutan Logam Deret Volta:</span>
                  <p className="p-2 bg-white rounded border border-slate-200 text-indigo-950 font-bold mt-0.5">
                    {ans.volta_order_ranked || '-'}
                  </p>
                  <span className="text-[10px] text-emerald-700 block mt-0.5">
                    🔑 Kunci: Mg &gt; Al &gt; Zn &gt; Fe &gt; Cu
                  </span>
                </div>
              </div>
              <div>
                <span className="font-semibold text-slate-700 block">Analisis Faktor Penyebab Galat:</span>
                <p className="p-2 bg-white rounded border border-slate-200 text-slate-800 mt-0.5">
                  {ans.error_analysis_factors || <span className="italic text-slate-400">Tidak diisi</span>}
                </p>
              </div>
              <div>
                <span className="font-semibold text-slate-700 block">
                  Notasi Sel Lengkap Variasi Logam:
                </span>
                <p className="p-2 bg-white rounded border border-slate-200 text-slate-800 mt-0.5 font-mono text-[11px]">
                  {ans.all_cell_notations || <span className="italic text-slate-400">Tidak diisi</span>}
                </p>
              </div>
              <div>
                <span className="font-semibold text-slate-700 block">
                  Solusi Kasus 2 (Rekomendasi Bahan Tangki ZnSO₄):
                </span>
                <p className="p-2 bg-white rounded border border-slate-200 text-slate-800 mt-0.5 font-medium">
                  {ans.case2_recommendation || <span className="italic text-slate-400">Tidak diisi</span>}
                </p>
                <span className="text-[10px] text-emerald-700 font-medium block mt-0.5">
                  🔑 Kunci: Logam Tembaga (Cu) karena E°sel bernilai negatif (-1,10 V / tidak bereaksi spontan).
                </span>
              </div>
            </div>

            {/* Fase 5 */}
            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
              <div className="font-bold text-indigo-900 flex justify-between items-center">
                <span>Fase 5: Evaluasi HOTS Komprehensif &amp; Refleksi</span>
                <span className="text-slate-400 font-normal">Maks 20 Poin</span>
              </div>
              <div>
                <span className="font-semibold text-slate-700 block">HOTS 1: Evaluasi Teori Luigi Galvani vs Volta:</span>
                <p className="p-2 bg-white rounded border border-slate-200 text-slate-800 mt-0.5">
                  {ans.hots_galvani_evaluation || <span className="italic text-slate-400">Tidak diisi</span>}
                </p>
                <span className="text-[10px] text-emerald-700 block mt-0.5">
                  🔑 Kunci: Kaki katak bertindak sebagai larutan elektrolit organik penghubung dua logam beda potensial (bimetal), bukan penghasil listrik hewani murni.
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="font-semibold text-slate-700 block">HOTS 2a (Urutan Reduktor A, B, C, D):</span>
                  <p className="p-2 bg-white rounded border border-slate-200 font-bold mt-0.5">
                    {ans.hots_a || '-'}
                  </p>
                  <span className="text-[10px] text-emerald-700 block mt-0.5">🔑 Kunci: D &gt; A &gt; C &gt; B</span>
                </div>
                <div>
                  <span className="font-semibold text-slate-700 block">HOTS 2b (Hitung E°sel C-D):</span>
                  <p className="p-2 bg-white rounded border border-slate-200 font-bold mt-0.5">
                    {ans.hots_b || '-'}
                  </p>
                  <span className="text-[10px] text-emerald-700 block mt-0.5">🔑 Kunci: -1,38 V atau +1,38 V spontan D-C</span>
                </div>
              </div>
              <div>
                <span className="font-semibold text-slate-700 block">HOTS 3: Proteksi Katodik Pipa Baja Bawah Tanah:</span>
                <p className="p-2 bg-white rounded border border-slate-200 text-slate-800 mt-0.5">
                  {ans.hots_3_corrosion || <span className="italic text-slate-400">Tidak diisi</span>}
                </p>
                <span className="text-[10px] text-emerald-700 block mt-0.5">
                  🔑 Kunci: Logam Magnesium (Mg) karena E° Mg (-2,37 V) jauh lebih negatif daripada Fe (-0,44 V), sehingga Mg yang terkorosi mengorbankan diri melindungi Fe.
                </span>
              </div>
              <div>
                <span className="font-semibold text-slate-700 block">Refleksi Belajar Metakognisi:</span>
                <p className="p-2 bg-white rounded border border-slate-200 text-slate-800 mt-0.5 italic">
                  {ans.reflection || '-'}
                </p>
              </div>
            </div>
          </div>

          {/* Right: Rubric Scoring Inputs & Feedback */}
          <div className="lg:col-span-5 bg-indigo-50/50 p-4 rounded-xl border border-indigo-100 space-y-4">
            <h4 className="font-bold text-indigo-950 text-sm border-b border-indigo-200/80 pb-2 flex items-center gap-2">
              <Award className="w-4 h-4 text-indigo-700" />
              <span>Input Rubrik Penilaian Guru</span>
            </h4>

            <div className="space-y-3">
              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="font-semibold text-slate-700">
                    Fase 2: Masalah &amp; Hipotesis (Maks 20):
                  </label>
                  <span className="font-mono font-bold text-indigo-900">{fase2} pt</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="20"
                  value={fase2}
                  onChange={(e) => setFase2(Number(e.target.value))}
                  className="w-full accent-indigo-600 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="font-semibold text-slate-700">
                    Fase 3: Penyelidikan &amp; Konsep (Maks 30):
                  </label>
                  <span className="font-mono font-bold text-indigo-900">{fase3} pt</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="30"
                  value={fase3}
                  onChange={(e) => setFase3(Number(e.target.value))}
                  className="w-full accent-indigo-600 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="font-semibold text-slate-700">
                    Fase 4: Solusi &amp; Perhitungan (Maks 30):
                  </label>
                  <span className="font-mono font-bold text-indigo-900">{fase4} pt</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="30"
                  value={fase4}
                  onChange={(e) => setFase4(Number(e.target.value))}
                  className="w-full accent-indigo-600 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="font-semibold text-slate-700">
                    Fase 5: Soal HOTS &amp; Evaluasi (Maks 20):
                  </label>
                  <span className="font-mono font-bold text-indigo-900">{fase5} pt</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="20"
                  value={fase5}
                  onChange={(e) => setFase5(Number(e.target.value))}
                  className="w-full accent-indigo-600 cursor-pointer"
                />
              </div>
            </div>

            {/* Score Summary Box */}
            <div className="bg-slate-900 text-white p-4 rounded-xl shadow space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-xs text-slate-300">Total Skor Akhir:</span>
                <span className="text-2xl font-extrabold text-amber-400 font-mono">
                  {total} / 100
                </span>
              </div>
              <div className="flex justify-between items-center pt-2 border-t border-slate-800 text-xs">
                <span className="text-slate-400">Predikat / Kategori:</span>
                <span className={`px-2 py-0.5 rounded text-[11px] font-bold border ${badgeColor}`}>
                  {predicate}
                </span>
              </div>
            </div>

            {/* Qualitative Feedback */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5 text-indigo-600" />
                <span>Umpan Balik &amp; Saran Perbaikan Guru:</span>
              </label>
              <textarea
                rows={4}
                placeholder="Tuliskan apresiasi, koreksi miskonsepsi, atau tindak lanjut pembelajaran untuk kelompok siswa ini..."
                value={feedback}
                onChange={(e) => setFeedback(e.target.value)}
                className="w-full p-2.5 bg-white border border-slate-300 rounded-lg text-xs leading-relaxed focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>

            {/* Save Button */}
            <div className="pt-2">
              <button
                onClick={handleSave}
                disabled={isSaving}
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-md transition flex items-center justify-center gap-2 active:scale-98"
              >
                <Check className="w-4 h-4" />
                <span>{isSaving ? 'Menyimpan...' : 'Simpan Penilaian & Kirimkan'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
