import React, { useRef, useEffect, useState } from 'react';
import { Play, Pause, RotateCcw, Zap, Info, ShieldAlert, Sparkles, CheckCircle2 } from 'lucide-react';

interface Phase2TCKSaltBridgeProps {
  onInsight?: (insight: string) => void;
}

export const Phase2TCKSaltBridge: React.FC<Phase2TCKSaltBridgeProps> = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isRunning, setIsRunning] = useState<boolean>(true);
  const [hasSaltBridge, setHasSaltBridge] = useState<boolean>(true);
  const [animStep, setAnimStep] = useState<number>(0);
  const [activeTab, setActiveTab] = useState<'macro' | 'micro'>('micro');

  // Animation frame loop
  useEffect(() => {
    let animationId: number;
    const animate = () => {
      if (isRunning && hasSaltBridge) {
        setAnimStep((prev) => (prev + 1.2) % 360);
      }
      animationId = requestAnimationFrame(animate);
    };
    animationId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationId);
  }, [isRunning, hasSaltBridge]);

  // Canvas drawing
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    // Background gradient
    const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
    bgGrad.addColorStop(0, '#0f172a');
    bgGrad.addColorStop(1, '#1e293b');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, w, h);

    // Beaker Left: Anode (ZnSO4)
    const bLeftX = 50;
    const bY = 120;
    const bW = 160;
    const bH = 150;

    // Solution Left (Anode)
    ctx.fillStyle = 'rgba(56, 189, 248, 0.2)';
    ctx.fillRect(bLeftX, bY + 40, bW, bH - 40);
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 2.5;
    ctx.strokeRect(bLeftX, bY, bW, bH);

    // Label Anode Beaker
    ctx.fillStyle = '#7dd3fc';
    ctx.font = 'bold 11px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('Kompartemen Anoda', bLeftX + bW / 2, bY + bH - 24);
    ctx.font = '10px sans-serif';
    ctx.fillStyle = '#bae6fd';
    ctx.fillText('Larutan ZnSO₄ 1 M (Zn²⁺ & SO₄²⁻)', bLeftX + bW / 2, bY + bH - 10);

    // Beaker Right: Cathode (CuSO4)
    const bRightX = 390;
    ctx.fillStyle = 'rgba(59, 130, 246, 0.35)';
    ctx.fillRect(bRightX, bY + 40, bW, bH - 40);
    ctx.strokeStyle = '#60a5fa';
    ctx.lineWidth = 2.5;
    ctx.strokeRect(bRightX, bY, bW, bH);

    // Label Cathode Beaker
    ctx.fillStyle = '#93c5fd';
    ctx.font = 'bold 11px sans-serif';
    ctx.fillText('Kompartemen Katoda', bRightX + bW / 2, bY + bH - 24);
    ctx.font = '10px sans-serif';
    ctx.fillStyle = '#bfdbfe';
    ctx.fillText('Larutan CuSO₄ 1 M (Cu²⁺ & SO₄²⁻)', bRightX + bW / 2, bY + bH - 10);

    // Solid Electrodes
    // Zn Anode
    const znX = bLeftX + 45;
    const znY = 70;
    ctx.fillStyle = '#94a3b8';
    ctx.fillRect(znX, znY, 30, 130);
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 2;
    ctx.strokeRect(znX, znY, 30, 130);

    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 11px sans-serif';
    ctx.fillText('Anoda: Zn(s)', znX + 15, znY - 14);
    ctx.fillStyle = '#f87171';
    ctx.font = 'bold 10px sans-serif';
    ctx.fillText('[-] Oksidasi: Zn → Zn²⁺ + 2e⁻', znX + 15, znY - 3);

    // Cu Cathode
    const cuX = bRightX + 85;
    const cuY = 70;
    ctx.fillStyle = '#d97706';
    ctx.fillRect(cuX, cuY, 30, 130);
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 2;
    ctx.strokeRect(cuX, cuY, 30, 130);

    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 11px sans-serif';
    ctx.fillText('Katoda: Cu(s)', cuX + 15, cuY - 14);
    ctx.fillStyle = '#4ade80';
    ctx.font = 'bold 10px sans-serif';
    ctx.fillText('[+] Reduksi: Cu²⁺ + 2e⁻ → Cu', cuX + 15, cuY - 3);

    // External Circuit Wire
    const wireY = 35;
    const meterX = (znX + cuX + 30) / 2;

    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(znX + 15, znY);
    ctx.lineTo(znX + 15, wireY);
    ctx.lineTo(meterX - 35, wireY);
    ctx.moveTo(meterX + 35, wireY);
    ctx.lineTo(cuX + 15, wireY);
    ctx.lineTo(cuX + 15, cuY);
    ctx.stroke();

    // Voltmeter Indicator Bulb
    const isLampOn = hasSaltBridge && isRunning;
    if (isLampOn) {
      const lampGlow = ctx.createRadialGradient(meterX, wireY, 10, meterX, wireY, 45);
      lampGlow.addColorStop(0, 'rgba(250, 204, 21, 0.9)');
      lampGlow.addColorStop(1, 'rgba(250, 204, 21, 0)');
      ctx.fillStyle = lampGlow;
      ctx.beginPath();
      ctx.arc(meterX, wireY, 45, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.fillStyle = isLampOn ? '#fef08a' : '#475569';
    ctx.beginPath();
    ctx.arc(meterX, wireY, 28, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#020617';
    ctx.lineWidth = 2.5;
    ctx.stroke();

    ctx.fillStyle = '#020617';
    ctx.font = 'bold 10px sans-serif';
    ctx.fillText(isLampOn ? '💡 LISTRIK ON' : '🔴 ARUS 0 V', meterX, wireY - 4);
    ctx.font = 'bold 12px monospace';
    ctx.fillStyle = isLampOn ? '#15803d' : '#991b1b';
    ctx.fillText(isLampOn ? '+1.10 V' : '0.00 V', meterX, wireY + 11);

    // Electron Flow Animation (Red Glowing Particles along wire)
    if (isLampOn) {
      const t = (animStep * 1.8) % 180;
      // Draw 4 traveling electrons
      for (let i = 0; i < 4; i++) {
        const p = (t + i * 45) % 180;
        let eX = 0;
        let eY = wireY;
        if (p < (znY - wireY)) {
          // moving up
          eX = znX + 15;
          eY = znY - p;
        } else if (p < (znY - wireY) + (cuX + 15 - (znX + 15))) {
          // moving horizontally to the right
          const distAlong = p - (znY - wireY);
          eX = znX + 15 + distAlong;
          eY = wireY;
        } else {
          // moving down to cathode
          const distDown = p - ((znY - wireY) + (cuX + 15 - (znX + 15)));
          eX = cuX + 15;
          eY = wireY + distDown;
        }

        if (eY <= znY && eY <= cuY) {
          ctx.fillStyle = '#ef4444';
          ctx.beginPath();
          ctx.arc(eX, eY, 4.5, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 1.2;
          ctx.stroke();

          // e- text
          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 7px sans-serif';
          ctx.fillText('e⁻', eX, eY + 2.5);
        }
      }
    }

    // Salt Bridge U-Tube
    const sbLeftX = bLeftX + bW - 35;
    const sbRightX = bRightX + 35;
    const sbTopY = 85;
    const sbBottomY = 195;
    const sbThick = 26;

    if (hasSaltBridge) {
      // Draw U-tube filled with agar KCl gel
      ctx.fillStyle = 'rgba(254, 240, 138, 0.85)';
      ctx.beginPath();
      ctx.moveTo(sbLeftX, sbBottomY);
      ctx.lineTo(sbLeftX, sbTopY);
      ctx.lineTo(sbRightX, sbTopY);
      ctx.lineTo(sbRightX, sbBottomY);
      ctx.lineTo(sbRightX - sbThick, sbBottomY);
      ctx.lineTo(sbRightX - sbThick, sbTopY + sbThick);
      ctx.lineTo(sbLeftX + sbThick, sbTopY + sbThick);
      ctx.lineTo(sbLeftX + sbThick, sbBottomY);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = '#facc15';
      ctx.lineWidth = 2.5;
      ctx.stroke();

      // Salt bridge label
      ctx.fillStyle = '#854d0e';
      ctx.font = 'bold 9px sans-serif';
      ctx.fillText('Jembatan Garam Agar-Agar KCl', (sbLeftX + sbRightX) / 2, sbTopY + 16);

      // Microscopic Ion Migration inside Salt Bridge & into Beakers
      if (isLampOn) {
        // K+ (Kation Kalium - ungu muda) mengalir ke Katoda
        // Cl- (Anion Klorida - hijau muda) mengalir ke Anoda
        const ionCycle = (animStep * 1.5) % 100;

        // 1. Cl- ion to Anode (Left)
        for (let j = 0; j < 3; j++) {
          const off = (ionCycle + j * 33) % 100;
          const clX = (sbLeftX + sbThick / 2);
          const clY = sbTopY + sbThick + (off / 100) * (sbBottomY - sbTopY - sbThick + 25);

          ctx.fillStyle = '#22c55e';
          ctx.beginPath();
          ctx.arc(clX, clY, 8, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 1;
          ctx.stroke();
          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 8px sans-serif';
          ctx.fillText('Cl⁻', clX, clY + 2.5);
        }

        // 2. K+ ion to Cathode (Right)
        for (let j = 0; j < 3; j++) {
          const off = (ionCycle + j * 33) % 100;
          const kX = (sbRightX - sbThick / 2);
          const kY = sbTopY + sbThick + (off / 100) * (sbBottomY - sbTopY - sbThick + 25);

          ctx.fillStyle = '#a855f7';
          ctx.beginPath();
          ctx.arc(kX, kY, 8, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 1;
          ctx.stroke();
          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 8px sans-serif';
          ctx.fillText('K⁺', kX, kY + 2.5);
        }

        // Ion movement arrows in salt bridge
        ctx.fillStyle = '#15803d';
        ctx.font = 'bold 10px sans-serif';
        ctx.fillText('← Cl⁻ bergerak menetralkan Zn²⁺', sbLeftX - 10, sbBottomY + 15);
        ctx.fillStyle = '#7e22ce';
        ctx.fillText('K⁺ bergerak menetralkan SO₄²⁻ →', sbRightX + 10, sbBottomY + 15);
      }
    } else {
      // Disconnected indicator
      ctx.setLineDash([5, 5]);
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 2;
      ctx.strokeRect(sbLeftX, sbTopY, sbRightX - sbLeftX, sbBottomY - sbTopY);
      ctx.setLineDash([]);

      ctx.fillStyle = '#f87171';
      ctx.font = 'bold 11px sans-serif';
      ctx.fillText('⚠️ JEMBATAN GARAM DILEPAS / TERPUTUS!', (sbLeftX + sbRightX) / 2, (sbTopY + sbBottomY) / 2 - 5);
      ctx.font = '10px sans-serif';
      ctx.fillText('Sirkuit terbuka: muatan menumpuk, tegangan = 0 V', (sbLeftX + sbRightX) / 2, (sbTopY + sbBottomY) / 2 + 12);
    }
  }, [isRunning, hasSaltBridge, animStep, activeTab]);

  return (
    <div className="bg-slate-900 text-white rounded-2xl border border-slate-800 p-5 shadow-lg space-y-4">
      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-indigo-500/20 text-indigo-400 rounded-xl border border-indigo-500/30">
            <Zap className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="font-bold text-white text-sm">
                TCK Interaktif: Aliran Elektron &amp; Transfer Ion di Jembatan Garam
              </h4>
              <span className="px-2 py-0.5 bg-amber-400/20 text-amber-300 border border-amber-400/30 rounded-full text-[10px] font-bold">
                Level Submikroskopik
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Pelajari bagaimana elektron mengalir di sirkuit luar dan bagaimana ion K⁺ &amp; Cl⁻ bermigrasi menjaga netralitas muatan.
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setHasSaltBridge(!hasSaltBridge)}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
              hasSaltBridge
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30 hover:bg-rose-500/30'
                : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/30'
            }`}
          >
            {hasSaltBridge ? (
              <>
                <ShieldAlert className="w-3.5 h-3.5" />
                <span>Lepas Jembatan Garam</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Pasang Jembatan Garam</span>
              </>
            )}
          </button>

          <button
            onClick={() => setIsRunning(!isRunning)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition ${
              isRunning
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 hover:bg-amber-500/40'
                : 'bg-indigo-600 text-white hover:bg-indigo-700'
            }`}
          >
            {isRunning ? (
              <>
                <Pause className="w-3.5 h-3.5" />
                <span>Jeda Animasi</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5" />
                <span>Jalankan</span>
              </>
            )}
          </button>

          <button
            onClick={() => {
              setHasSaltBridge(true);
              setIsRunning(true);
            }}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition"
            title="Reset simulasi"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Visual Canvas Area */}
      <div className="w-full flex justify-center">
        <div className="w-full max-w-[620px] rounded-xl overflow-hidden border border-slate-700 bg-slate-950 shadow-inner">
          <canvas
            ref={canvasRef}
            width={600}
            height={280}
            className="w-full h-auto block"
          />
        </div>
      </div>

      {/* TCK Science Deep-Dive Explanations */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
        <div className="bg-slate-800/80 p-3.5 rounded-xl border border-slate-700/80 space-y-1.5">
          <div className="flex items-center gap-1.5 text-rose-400 font-bold">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
            <span>1. Aliran Elektron (Sirkuit Luar)</span>
          </div>
          <p className="text-slate-300 text-[11px] leading-relaxed">
            Elektron (<strong>e⁻</strong>) bergerak spontan dari <strong>Anoda Seng (Zn)</strong> yang mengalami oksidasi menuju <strong>Katoda Tembaga (Cu)</strong> yang mengalami reduksi melalui kawat konduktor luar.
          </p>
        </div>

        <div className="bg-slate-800/80 p-3.5 rounded-xl border border-slate-700/80 space-y-1.5">
          <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
            <span>2. Migrasi Anion Cl⁻ ke Anoda</span>
          </div>
          <p className="text-slate-300 text-[11px] leading-relaxed">
            Karena Zn melepaskan elektron menjadi ion <strong>Zn²⁺</strong>, terjadi penumpukan muatan positif di anoda. Ion <strong>Cl⁻</strong> dari agar KCl mengalir masuk untuk <strong>menetralkan kelebihan kation Zn²⁺</strong>.
          </p>
        </div>

        <div className="bg-slate-800/80 p-3.5 rounded-xl border border-slate-700/80 space-y-1.5">
          <div className="flex items-center gap-1.5 text-purple-400 font-bold">
            <span className="w-2.5 h-2.5 rounded-full bg-purple-500"></span>
            <span>3. Migrasi Kation K⁺ ke Katoda</span>
          </div>
          <p className="text-slate-300 text-[11px] leading-relaxed">
            Ion <strong>Cu²⁺</strong> menangkap elektron mengendap jadi Cu padat, sehingga tersisa kelebihan anion <strong>SO₄²⁻</strong>. Ion <strong>K⁺</strong> mengalir masuk ke katoda untuk <strong>menjaga netralitas muatan larutan</strong>.
          </p>
        </div>
      </div>

      {/* Critical Discovery Callout */}
      <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl text-xs flex items-start gap-2.5 text-amber-200">
        <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
        <div>
          <strong className="block text-amber-300">
            Konsep Penting Pembelajaran (TCK Inkuiri):
          </strong>
          <span>
            Jika jembatan garam <strong>dilepas atau tidak ada</strong>, muatan positif akan menumpuk di anoda dan muatan negatif menumpuk di katoda dalam hitungan milidetik. Akibatnya timbul medan listrik tandingan yang <strong>menghentikan aliran elektron seketika (Tegangan = 0 V)</strong>. Jembatan garam adalah penentu keberlangsungan sirkuit tertutup!
          </span>
        </div>
      </div>
    </div>
  );
};
