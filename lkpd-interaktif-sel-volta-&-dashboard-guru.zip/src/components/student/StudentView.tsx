import React, { useState, useEffect } from 'react';
import {
  Clock,
  AlertTriangle,
  CheckCircle2,
  Save,
  Send,
  Download,
  Printer,
  Sparkles,
  HelpCircle,
  Award,
  Layers,
  FlaskConical,
  Calculator,
  Flame,
  Check,
  BookOpen,
  History,
  Zap,
} from 'lucide-react';
import type { LKPDConfig, StudentSubmission } from '../../types.js';
import { VoltaSimulationCanvas } from './VoltaSimulationCanvas.js';
import { Phase2TCKSaltBridge } from './Phase2TCKSaltBridge.js';
import { Phase3DaniellLab } from './Phase3DaniellLab.js';
import { Phase4ResultsWorksheet } from './Phase4ResultsWorksheet.js';
import { e0Data, voltaSeries, checkSpontaneity } from '../../data/voltaData.js';

interface StudentViewProps {
  lkpdConfig: LKPDConfig;
  currentSubmission: StudentSubmission | null;
  onSaveDraft: (data: Partial<StudentSubmission>) => Promise<void>;
  onSubmitAnswers: (data: Partial<StudentSubmission>) => Promise<void>;
  isSubmitting: boolean;
}

export const StudentView: React.FC<StudentViewProps> = ({
  lkpdConfig,
  currentSubmission,
  onSaveDraft,
  onSubmitAnswers,
  isSubmitting,
}) => {
  // Student identity state
  const [groupName, setGroupName] = useState<string>(currentSubmission?.groupName || '');
  const [classGrade, setClassGrade] = useState<string>(currentSubmission?.classGrade || 'XII MIPA 1');
  const [member1, setMember1] = useState<string>(currentSubmission?.members?.[0] || '');
  const [member2, setMember2] = useState<string>(currentSubmission?.members?.[1] || '');
  const [member3, setMember3] = useState<string>(currentSubmission?.members?.[2] || '');
  const [member4, setMember4] = useState<string>(currentSubmission?.members?.[3] || '');

  // Answers state
  const [answers, setAnswers] = useState<Record<string, string>>(currentSubmission?.answers || {});

  // Mini calculator state
  const [calcEcat, setCalcEcat] = useState<number>(0.34);
  const [calcEan, setCalcEan] = useState<number>(-0.76);

  // Spontaneity tester state
  const [testSolid, setTestSolid] = useState<string>('Fe');
  const [testIon, setTestIon] = useState<string>('Zn');

  // Deadline countdown state
  const [timeLeftStr, setTimeLeftStr] = useState<string>('');
  const [isOverdue, setIsOverdue] = useState<boolean>(false);
  const [saveToast, setSaveToast] = useState<string | null>(null);

  // Sync with incoming currentSubmission if any
  useEffect(() => {
    if (currentSubmission) {
      if (currentSubmission.groupName) setGroupName(currentSubmission.groupName);
      if (currentSubmission.classGrade) setClassGrade(currentSubmission.classGrade);
      if (currentSubmission.members?.[0]) setMember1(currentSubmission.members[0]);
      if (currentSubmission.members?.[1]) setMember2(currentSubmission.members[1]);
      if (currentSubmission.members?.[2]) setMember3(currentSubmission.members[2]);
      if (currentSubmission.members?.[3]) setMember4(currentSubmission.members[3]);
      if (currentSubmission.answers) setAnswers(currentSubmission.answers);
    }
  }, [currentSubmission]);

  // Calculate remaining time
  useEffect(() => {
    const updateTimer = () => {
      if (!lkpdConfig.deadline) return;
      const diff = new Date(lkpdConfig.deadline).getTime() - Date.now();
      if (diff <= 0) {
        setIsOverdue(true);
        setTimeLeftStr('Batas waktu pengerjaan telah berakhir!');
      } else {
        setIsOverdue(false);
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((diff % (1000 * 60)) / 1000);
        setTimeLeftStr(`${hours} jam ${minutes} menit ${seconds} detik`);
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [lkpdConfig.deadline]);

  const handleAnswerChange = (field: string, value: string) => {
    setAnswers((prev) => ({ ...prev, [field]: value }));
  };

  const getPackageData = (): Partial<StudentSubmission> => {
    const membersList = [member1, member2, member3, member4].map((m) => m.trim()).filter(Boolean);
    return {
      groupName: groupName.trim() || 'Kelompok Siswa',
      classGrade: classGrade.trim() || 'XII',
      members: membersList,
      answers,
    };
  };

  const handleSaveDraft = async () => {
    const data = getPackageData();
    await onSaveDraft(data);
    setSaveToast('Draf pengerjaan berhasil disimpan ke server!');
    setTimeout(() => setSaveToast(null), 3500);
  };

  const handleSubmit = async () => {
    if (!groupName.trim()) {
      alert('Mohon isi Nama Kelompok terlebih dahulu sebelum mengirim.');
      return;
    }
    const data = getPackageData();
    await onSubmitAnswers(data);
    setSaveToast('Jawaban LKPD berhasil dikirimkan ke Guru!');
    setTimeout(() => setSaveToast(null), 4000);
  };

  const handleDownloadJSON = () => {
    const data = {
      ...getPackageData(),
      submittedAt: new Date().toISOString(),
      lkpdTitle: lkpdConfig.title,
    };
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(data, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute(
      'download',
      `LKPD_SelVolta_${(groupName || 'Kelompok').replace(/\s+/g, '_')}.json`
    );
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const spontResult = checkSpontaneity(testSolid, testIon);
  const calcResult = Number((calcEcat - calcEan).toFixed(2));

  return (
    <div className="space-y-8 pb-16">
      {/* Toast Alert */}
      {saveToast && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-2xl border border-indigo-500/50 flex items-center gap-3 animate-in fade-in slide-in-from-bottom-4">
          <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          <span className="text-xs font-semibold">{saveToast}</span>
        </div>
      )}

      {/* Deadline Alert Banner */}
      <div
        className={`p-4 rounded-2xl border flex flex-wrap items-center justify-between gap-3 shadow-sm ${
          isOverdue
            ? 'bg-rose-50 border-rose-200 text-rose-900'
            : 'bg-amber-50/80 border-amber-200 text-amber-950'
        }`}
      >
        <div className="flex items-center gap-3">
          <div
            className={`p-2.5 rounded-xl ${
              isOverdue ? 'bg-rose-200 text-rose-800' : 'bg-amber-200 text-amber-900'
            }`}
          >
            {isOverdue ? (
              <AlertTriangle className="w-5 h-5 text-rose-700" />
            ) : (
              <Clock className="w-5 h-5 text-amber-700" />
            )}
          </div>
          <div>
            <h3 className="text-xs sm:text-sm font-bold">
              {isOverdue
                ? 'Pemberitahuan Otomatis: Batas Waktu Pengumpulan Telah Lewat'
                : 'Pengingat Waktu Pengumpulan LKPD'}
            </h3>
            <p className="text-xs opacity-90">
              {isOverdue
                ? 'Tugas ini melewati tenggat waktu yang ditetapkan oleh Guru. Anda tetap dapat mengirimkan draf jawaban.'
                : `Sisa waktu pengerjaan: ${timeLeftStr}`}
            </p>
          </div>
        </div>

        <div className="text-xs font-mono font-semibold px-3 py-1.5 rounded-lg bg-white/80 border border-slate-200 shadow-xs">
          Tenggat:{' '}
          {new Date(lkpdConfig.deadline).toLocaleString('id-ID', {
            dateStyle: 'medium',
            timeStyle: 'short',
          })}
        </div>
      </div>

      {/* Result Card if Already Graded by Teacher */}
      {currentSubmission?.status === 'graded' && currentSubmission.totalScore !== null && (
        <div className="bg-gradient-to-br from-emerald-500 to-teal-700 text-white rounded-2xl p-6 shadow-lg space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/20 pb-4">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-xs">
                <Award className="w-8 h-8 text-amber-300" />
              </div>
              <div>
                <span className="px-2.5 py-0.5 bg-amber-400 text-slate-950 text-[10px] font-extrabold uppercase rounded-full">
                  Telah Dinilai oleh Guru
                </span>
                <h3 className="text-xl font-bold mt-1">
                  Hasil Penilaian Kelompok: {currentSubmission.groupName}
                </h3>
              </div>
            </div>
            <div className="text-right">
              <span className="text-xs text-emerald-100 block">Total Nilai Akhir:</span>
              <span className="text-3xl font-extrabold text-amber-300 font-mono">
                {currentSubmission.totalScore} / 100
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="bg-white/10 p-2.5 rounded-xl border border-white/15">
              <span className="text-emerald-100 block">Fase 2 (Masalah &amp; Hipotesis):</span>
              <span className="text-base font-bold font-mono">
                {currentSubmission.scoreBreakdown?.fase2 ?? 0} / 20
              </span>
            </div>
            <div className="bg-white/10 p-2.5 rounded-xl border border-white/15">
              <span className="text-emerald-100 block">Fase 3 (Penyelidikan):</span>
              <span className="text-base font-bold font-mono">
                {currentSubmission.scoreBreakdown?.fase3 ?? 0} / 30
              </span>
            </div>
            <div className="bg-white/10 p-2.5 rounded-xl border border-white/15">
              <span className="text-emerald-100 block">Fase 4 (Solusi Kasus):</span>
              <span className="text-base font-bold font-mono">
                {currentSubmission.scoreBreakdown?.fase4 ?? 0} / 30
              </span>
            </div>
            <div className="bg-white/10 p-2.5 rounded-xl border border-white/15">
              <span className="text-emerald-100 block">Fase 5 (Soal HOTS):</span>
              <span className="text-base font-bold font-mono">
                {currentSubmission.scoreBreakdown?.fase5 ?? 0} / 20
              </span>
            </div>
          </div>

          {currentSubmission.teacherFeedback && (
            <div className="bg-white/10 p-3.5 rounded-xl border border-white/15 text-xs space-y-1">
              <span className="font-bold text-amber-200 block">
                💬 Umpan Balik &amp; Evaluasi Guru:
              </span>
              <p className="italic text-emerald-50 leading-relaxed">
                "{currentSubmission.teacherFeedback}"
              </p>
            </div>
          )}
        </div>
      )}

      {/* Header Info & Form Identitas Kelompok */}
      <section className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 border-b lg:border-b-0 lg:border-r border-slate-200 pb-5 lg:pb-0 lg:pr-6 space-y-3">
            <span className="inline-block px-2.5 py-1 bg-indigo-100 text-indigo-800 rounded-full text-xs font-bold uppercase">
              {lkpdConfig.subject}
            </span>
            <h2 className="text-xl font-bold text-slate-800 leading-snug">
              {lkpdConfig.title}
            </h2>
            <p className="text-xs text-slate-600 leading-relaxed">
              Topik: {lkpdConfig.topic} | Alokasi Waktu: {lkpdConfig.timeAllocation}
            </p>

            <div className="bg-indigo-50/70 border border-indigo-200/80 rounded-xl p-3 text-xs text-indigo-900 space-y-1.5">
              <strong className="block font-semibold flex items-center gap-1.5 text-indigo-950">
                <HelpCircle className="w-4 h-4 text-indigo-700" />
                Petunjuk Pengerjaan PBL:
              </strong>
              <ul className="list-disc list-inside space-y-1 text-slate-700 text-[11px] leading-normal">
                {lkpdConfig.instructions.map((inst, idx) => (
                  <li key={idx}>{inst}</li>
                ))}
              </ul>
            </div>
          </div>

          {/* Form Identitas */}
          <div className="lg:col-span-7 space-y-3.5">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-indigo-600"></span>
              Identitas Kelompok &amp; Anggota Siswa
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nama Kelompok:
                </label>
                <input
                  type="text"
                  placeholder="Contoh: Kelompok 1 (Galvani)"
                  value={groupName}
                  onChange={(e) => setGroupName(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-slate-50/50"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Kelas / Jurusan:
                </label>
                <input
                  type="text"
                  placeholder="Contoh: XII MIPA 1"
                  value={classGrade}
                  onChange={(e) => setClassGrade(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-slate-50/50"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Daftar Nama Anggota Kelompok:
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <input
                  type="text"
                  placeholder="1. Ketua Kelompok / Anggota"
                  value={member1}
                  onChange={(e) => setMember1(e.target.value)}
                  className="px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
                <input
                  type="text"
                  placeholder="2. Anggota Kelompok"
                  value={member2}
                  onChange={(e) => setMember2(e.target.value)}
                  className="px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
                <input
                  type="text"
                  placeholder="3. Anggota Kelompok"
                  value={member3}
                  onChange={(e) => setMember3(e.target.value)}
                  className="px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
                <input
                  type="text"
                  placeholder="4. Anggota Kelompok"
                  value={member4}
                  onChange={(e) => setMember4(e.target.value)}
                  className="px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FASE 1: Orientasi Masalah Sejarah Galvani vs Volta */}
      <section className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 space-y-5">
        <div className="border-b border-slate-100 pb-3 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 bg-indigo-600 text-white rounded-full text-xs font-bold uppercase">
              Fase 1
            </span>
            <h3 className="text-base font-bold text-slate-800">
              Orientasi Peserta Didik pada Masalah (Sejarah Kontroversi Galvani vs Volta)
            </h3>
          </div>
          <span className="text-xs text-slate-500 font-medium">Stimulus Sejarah &amp; Kasus Otentik</span>
        </div>

        {/* Historical Narrative: Galvani vs Volta */}
        <div className="bg-gradient-to-r from-amber-500/10 via-indigo-500/10 to-emerald-500/10 rounded-2xl p-5 border border-slate-200 space-y-4">
          <div className="flex items-center gap-2 text-indigo-950 font-bold text-sm">
            <History className="w-5 h-5 text-indigo-600" />
            <span>Kisah Sejarah: Kelahiran Sel Elektrokimia dari Perdebatan Dua Ilmuwan Italia</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            {/* Luigi Galvani */}
            <div className="bg-white p-4 rounded-xl border border-amber-200 shadow-xs space-y-2">
              <div className="flex items-center justify-between border-b border-amber-100 pb-2">
                <span className="font-bold text-amber-900 text-sm flex items-center gap-1.5">
                  <span>🐸</span> Luigi Galvani (1780)
                </span>
                <span className="px-2 py-0.5 bg-amber-100 text-amber-800 rounded text-[10px] font-bold">
                  Listrik Hewani
                </span>
              </div>
              <p className="text-slate-700 leading-relaxed text-justify">
                {lkpdConfig.historicalContext?.galvaniStory ||
                  'Luigi Galvani mengamati otot kaki katak berkedut hebat ketika tersentuh dua logam berbeda (kait tembaga pada pagar besi balkon). Galvani menyimpulkan ada cairan listrik intrinsik yang tersimpan di dalam jaringan otot dan saraf hewan yang ia sebut "Animal Electricity".'}
              </p>
              <div className="p-2 bg-amber-50 rounded-lg text-amber-900 text-[11px] font-medium border border-amber-200">
                <strong>Gagasan Galvani:</strong> Listrik diproduksi oleh tubuh hewan; logam hanya berperan sebagai konduktor penghantar.
              </div>
            </div>

            {/* Alessandro Volta */}
            <div className="bg-white p-4 rounded-xl border border-indigo-200 shadow-xs space-y-2">
              <div className="flex items-center justify-between border-b border-indigo-100 pb-2">
                <span className="font-bold text-indigo-900 text-sm flex items-center gap-1.5">
                  <span>⚡</span> Alessandro Volta (1791 - 1800)
                </span>
                <span className="px-2 py-0.5 bg-indigo-100 text-indigo-800 rounded text-[10px] font-bold">
                  Tumpukan Logam Volta
                </span>
              </div>
              <p className="text-slate-700 leading-relaxed text-justify">
                {lkpdConfig.historicalContext?.voltaStory ||
                  'Alessandro Volta membantah teori Galvani. Volta menyatakan kaki katak yang basah hanya berperan sebagai larutan elektrolit cair, sedangkan sumber listrik sesungguhnya adalah kontak antara dua logam berbeda jenis (bimetal seng-perak/tembaga). Volta membuktikannya dengan menciptakan "Voltaic Pile" tanpa bagian hewan sama sekali!'}
              </p>
              <div className="p-2 bg-indigo-50 rounded-lg text-indigo-900 text-[11px] font-medium border border-indigo-200">
                <strong>Gagasan Volta:</strong> Arus listrik timbul akibat perbedaan sifat kimiawi dua logam berbeda yang terhubung larutan elektrolit.
              </div>
            </div>
          </div>

          {/* Central Controversy Problem Box */}
          <div className="bg-slate-900 text-white p-4 rounded-xl space-y-2 text-xs border border-slate-800">
            <div className="flex items-center gap-2 text-amber-300 font-bold text-xs uppercase tracking-wider">
              <HelpCircle className="w-4 h-4 text-amber-400" />
              <span>Inti Pertanyaan Orientasi Masalah:</span>
            </div>
            <p className="text-slate-200 text-xs sm:text-sm font-semibold leading-relaxed">
              "{lkpdConfig.historicalContext?.controversyProblem ||
                'Mengapa otot kaki katak berkedut saat tersentuh dua logam berbeda (besi & tembaga)? Apakah listrik berasal dari hewan (Galvani) atau dari kontak dua logam berbeda melalui larutan elektrolit (Volta)?'}"
            </p>
            <div className="pt-1 text-[11px] text-slate-400 space-y-0.5">
              <span>Pertanyaan Penuntun Diskusi Kelompok:</span>
              <ul className="list-disc list-inside text-slate-300">
                <li>Mengapa jika kedua logamnya identik (misal tembaga-tembaga), kaki katak tidak bereaksi sama sekali?</li>
                <li>Bagaimana prinsip tumpukan Volta (Voltaic Pile) mengilhami Sel Daniell (Zn-Cu) dan baterai modern?</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Kasus Otentik Tambahan */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Case 1 */}
          <div className="bg-amber-50/60 border border-amber-200 rounded-xl p-4 space-y-2">
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-amber-500 text-white rounded-lg text-xs font-bold">
                🍋
              </span>
              <h4 className="font-bold text-amber-950 text-xs sm:text-sm">
                {lkpdConfig.case1?.title || 'Kasus 1: Replikasi Baterai Volta & Baterai Lemon'}
              </h4>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed text-justify">
              {lkpdConfig.case1?.description}
            </p>
            {lkpdConfig.case1?.hint && (
              <div className="p-2 bg-amber-100/70 rounded-lg text-[11px] text-amber-900 flex items-start gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-700 shrink-0 mt-0.5" />
                <span>
                  <strong>Petunjuk:</strong> {lkpdConfig.case1.hint}
                </span>
              </div>
            )}
          </div>

          {/* Case 2 */}
          <div className="bg-indigo-50/60 border border-indigo-200 rounded-xl p-4 space-y-2">
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-indigo-600 text-white rounded-lg text-xs font-bold">
                🏭
              </span>
              <h4 className="font-bold text-indigo-950 text-xs sm:text-sm">
                {lkpdConfig.case2?.title || 'Kasus 2: Pemilihan Bahan Tangki ZnSO₄'}
              </h4>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed text-justify">
              {lkpdConfig.case2?.description}
            </p>
            {lkpdConfig.case2?.hint && (
              <div className="p-2 bg-indigo-100/70 rounded-lg text-[11px] text-indigo-900 flex items-start gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-indigo-700 shrink-0 mt-0.5" />
                <span>
                  <strong>Petunjuk:</strong> {lkpdConfig.case2.hint}
                </span>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* FASE 2: Organisasi Belajar & TCK Jembatan Garam */}
      <section className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 space-y-6">
        <div className="border-b border-slate-100 pb-3 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 bg-indigo-600 text-white rounded-full text-xs font-bold uppercase">
              Fase 2
            </span>
            <h3 className="text-base font-bold text-slate-800">
              Mengorganisasikan Peserta Didik untuk Belajar &amp; TCK Transfer Ion
            </h3>
          </div>
          <span className="text-xs text-slate-500 font-semibold">Bobot Rubrik: 20 Poin</span>
        </div>

        {/* TCK Interactive Salt Bridge and Electron Flow Component */}
        <Phase2TCKSaltBridge />

        {/* Scaffolding: Rumusan Masalah & Hipotesis Saintifik Kelompok */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs">
          {/* Rumusan Masalah */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
            <h4 className="font-bold text-indigo-950 flex items-center gap-2 text-sm">
              <span>🎯</span> 1. Rumusan Masalah Saintifik Kelompok
            </h4>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Rumusan Masalah Utama (Kontroversi Galvani vs Volta &amp; Aliran Elektron):
              </label>
              <textarea
                rows={3}
                placeholder="Tuliskan rumusan masalah mengenai mengapa otot katak berkedut pada dua logam berbeda, dan apa peran kawat penghantar serta larutan elektrolit..."
                value={answers.prob_galvani_volta || answers.prob1 || ''}
                onChange={(e) => {
                  handleAnswerChange('prob_galvani_volta', e.target.value);
                  handleAnswerChange('prob1', e.target.value);
                }}
                className="w-full p-2.5 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-white text-xs leading-relaxed"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Rumusan Masalah Kasus Otentik (Baterai Lemon &amp; Tangki Logam):
              </label>
              <textarea
                rows={3}
                placeholder="Tuliskan rumusan masalah mengenai kriteria perbedaan E° dan kespontanan reaksi redoks pada pemilihan bahan..."
                value={answers.prob2 || ''}
                onChange={(e) => handleAnswerChange('prob2', e.target.value)}
                className="w-full p-2.5 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-white text-xs leading-relaxed"
              />
            </div>
          </div>

          {/* Hipotesis Sementara */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
            <h4 className="font-bold text-indigo-950 flex items-center gap-2 text-sm">
              <span>💡</span> 2. Hipotesis Saintifik Sementara Kelompok
            </h4>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Hipotesis Kontroversi Galvani vs Volta:
              </label>
              <textarea
                rows={3}
                placeholder="Tuliskan dugaan awal kelompok: Apakah listrik berasal dari jaringan hewan (Galvani) atau dari perbedaan potensial dua logam melalui larutan elektrolit (Volta)? Jelaskan alasan kalian..."
                value={answers.hypo_galvani_volta || answers.hypo1 || ''}
                onChange={(e) => {
                  handleAnswerChange('hypo_galvani_volta', e.target.value);
                  handleAnswerChange('hypo1', e.target.value);
                }}
                className="w-full p-2.5 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-white text-xs leading-relaxed"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Hipotesis Kasus Otentik (Zn-Cu vs Zn-Zn &amp; Reaksi Tangki):
              </label>
              <textarea
                rows={3}
                placeholder="Tuliskan dugaan awal kelompok mengenai penyebab lampu lemon menyala hanya pada Zn-Cu dan prediksi logam tangki yang aman..."
                value={answers.hypo2 || ''}
                onChange={(e) => handleAnswerChange('hypo2', e.target.value)}
                className="w-full p-2.5 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-white text-xs leading-relaxed"
              />
            </div>
          </div>
        </div>
      </section>

      {/* FASE 3: Penyelidikan Terpadu & Perakitan Sel Daniell */}
      <section className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 space-y-6">
        <div className="border-b border-slate-100 pb-3 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 bg-indigo-600 text-white rounded-full text-xs font-bold uppercase">
              Fase 3
            </span>
            <h3 className="text-base font-bold text-slate-800">
              Membimbing Penyelidikan Terpadu: Perakitan Sel Daniell, Variasi Logam &amp; Jembatan Garam
            </h3>
          </div>
          <span className="text-xs text-slate-500 font-semibold">Bobot Rubrik: 30 Poin</span>
        </div>

        {/* Dedicated Phase 3 Laboratory Component: Agar KCl Guide, Daniell Assembly & Digital Voltmeter */}
        <Phase3DaniellLab
          lkpdConfig={lkpdConfig}
          answers={answers}
          onAnswerChange={handleAnswerChange}
        />

        {/* Existing Interactive Volta Simulation Canvas */}
        <div className="space-y-4 pt-2 border-t border-slate-100">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-indigo-600" />
            <h4 className="font-bold text-slate-800 text-sm">
              Laboratorium Dinamis: Animasi Aliran Elektron &amp; Reaksi Antarmuka Elektroda
            </h4>
          </div>

          <VoltaSimulationCanvas />

          {/* Pertanyaan Penuntun 1.1 - 1.3 */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3 text-xs">
            <h4 className="font-bold text-indigo-950 text-sm border-b border-slate-200 pb-2">
              Pertanyaan Penuntun (Scaffolding Penyelidikan Elektroda)
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  1. Pada pasangan elektroda Zn-Cu, logam manakah yang mengalami oksidasi di Anoda?
                </label>
                <input
                  type="text"
                  placeholder="Jawab: Logam Seng (Zn) / Tembaga (Cu) beserta alasan..."
                  value={answers.scaff1_1 || ''}
                  onChange={(e) => handleAnswerChange('scaff1_1', e.target.value)}
                  className="w-full p-2 border rounded-lg bg-white"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  2. Arah aliran elektron melalui kawat sirkuit luar:
                </label>
                <input
                  type="text"
                  placeholder="Mengalir dari elektroda ... menuju elektroda ..."
                  value={answers.scaff1_2 || ''}
                  onChange={(e) => handleAnswerChange('scaff1_2', e.target.value)}
                  className="w-full p-2 border rounded-lg bg-white"
                />
              </div>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                3. Apakah fungsi jembatan garam &amp; bagaimana cara penulisan notasi sel Volta pasangan Zn-Cu?
              </label>
              <textarea
                rows={2}
                placeholder="Jelaskan peran ion dalam jembatan garam dan tuliskan notasi selnya..."
                value={answers.scaff1_3 || ''}
                onChange={(e) => handleAnswerChange('scaff1_3', e.target.value)}
                className="w-full p-2 border rounded-lg bg-white"
              />
            </div>
          </div>
        </div>

        {/* Kegiatan 2: Potensial Reduksi Standar E0 & Kalkulator Cepat */}
        <div className="bg-slate-50 rounded-xl p-5 border border-slate-200 space-y-5">
          <div className="flex items-center gap-2">
            <FlaskConical className="w-5 h-5 text-indigo-600" />
            <h4 className="font-bold text-slate-800 text-sm">
              Tabel Potensial Reduksi Standar ($E^\circ$) &amp; Kalkulator Cepat Potensial Sel
            </h4>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs items-start">
            {/* Table E0 */}
            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
              <div className="bg-indigo-900 text-white px-3 py-2 font-bold flex justify-between text-xs">
                <span>Reaksi Reduksi Standar (25°C, 1 M)</span>
                <span>$E^\circ$ (Volt)</span>
              </div>
              <div className="max-h-48 overflow-y-auto divide-y divide-slate-100 font-mono text-[11px]">
                {e0Data.map((item, i) => (
                  <div key={i} className="flex justify-between items-center px-3 py-1.5 hover:bg-slate-50">
                    <span className="text-slate-700">{item.reaction}</span>
                    <span
                      className={`font-bold ${
                        item.e0 > 0 ? 'text-emerald-600' : item.e0 < 0 ? 'text-rose-600' : 'text-slate-700'
                      }`}
                    >
                      {item.e0 > 0 ? '+' : ''}
                      {item.e0.toFixed(2)} V
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Calculator */}
            <div className="bg-slate-900 text-white p-4 rounded-xl shadow space-y-3">
              <div className="flex items-center gap-2 text-amber-300 font-bold text-xs">
                <Calculator className="w-4 h-4" />
                <span>Kalkulator Cepat: $E^\circ_{'{sel}'} = E^\circ_{'{\\text{katoda}}'} - E^\circ_{'{\\text{anoda}}'}$</span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <label className="block text-[10px] text-slate-300 font-semibold mb-1">
                    $E^\circ$ Katoda (Reduksi):
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={calcEcat}
                    onChange={(e) => setCalcEcat(parseFloat(e.target.value) || 0)}
                    className="w-full p-2 bg-slate-800 text-amber-300 font-mono font-bold rounded border border-slate-700"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-slate-300 font-semibold mb-1">
                    $E^\circ$ Anoda (Oksidasi):
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={calcEan}
                    onChange={(e) => setCalcEan(parseFloat(e.target.value) || 0)}
                    className="w-full p-2 bg-slate-800 text-amber-300 font-mono font-bold rounded border border-slate-700"
                  />
                </div>
              </div>

              <div className="p-3 bg-slate-950 rounded-lg flex justify-between items-center border border-slate-800">
                <span className="text-xs text-slate-400">Hasil Hitung $E^\circ_{'{sel}'}$:</span>
                <span
                  className={`text-base font-bold font-mono ${
                    calcResult > 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {calcResult > 0 ? '+' : ''}
                  {calcResult.toFixed(2)} Volt
                </span>
              </div>
            </div>
          </div>

          {/* Scaffolding 2 */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-3 text-xs">
            <h4 className="font-bold text-indigo-950 text-sm border-b border-slate-200 pb-2">
              Pertanyaan Penuntun (Scaffolding Potensial Reduksi)
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  1. Logam dengan nilai $E^\circ$ semakin POSITIF cenderung mengalami reaksi apa?
                </label>
                <select
                  value={answers.scaff2_1 || ''}
                  onChange={(e) => handleAnswerChange('scaff2_1', e.target.value)}
                  className="w-full p-2 border rounded-lg bg-slate-50 font-medium"
                >
                  <option value="">-- Pilih Jawaban --</option>
                  <option value="reduksi">Reduksi (Menangkap elektron / Katoda)</option>
                  <option value="oksidasi">Oksidasi (Melepas elektron / Anoda)</option>
                </select>
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  2. Logam dengan nilai $E^\circ$ semakin NEGATIF cenderung mengalami reaksi apa?
                </label>
                <select
                  value={answers.scaff2_2 || ''}
                  onChange={(e) => handleAnswerChange('scaff2_2', e.target.value)}
                  className="w-full p-2 border rounded-lg bg-slate-50 font-medium"
                >
                  <option value="">-- Pilih Jawaban --</option>
                  <option value="oksidasi">Oksidasi (Melepas elektron / Anoda)</option>
                  <option value="reduksi">Reduksi (Menangkap elektron / Katoda)</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* Deret Volta & Uji Kespontanan */}
        <div className="bg-amber-50/50 rounded-xl p-5 border border-amber-200/80 space-y-4">
          <div className="flex items-center gap-2">
            <Flame className="w-5 h-5 text-amber-600" />
            <h4 className="font-bold text-amber-950 text-sm">
              Eksplorasi Deret Volta &amp; Uji Kespontanan Reaksi Redoks
            </h4>
          </div>

          {/* Deret Volta Strip */}
          <div className="bg-white p-3 rounded-xl border border-amber-200/80 space-y-2">
            <div className="flex justify-between text-[10px] font-bold text-slate-500 uppercase tracking-wider">
              <span>← Reduktor Semakin Kuat (Mudah Teroksidasi)</span>
              <span>Oksidator Semakin Kuat (Mudah Tereduksi) →</span>
            </div>
            <div className="flex flex-wrap gap-1 justify-center font-mono font-bold text-xs">
              {voltaSeries.map((m, idx) => {
                const isHighlight = m === 'Zn' || m === 'Fe' || m === 'Cu';
                return (
                  <span
                    key={idx}
                    className={`px-2 py-1 rounded text-[11px] ${
                      isHighlight
                        ? 'bg-indigo-600 text-white shadow-xs ring-2 ring-indigo-300'
                        : m === '(H)'
                        ? 'bg-purple-100 text-purple-800'
                        : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    {m}
                  </span>
                );
              })}
            </div>
          </div>

          {/* Spontaneity Tester */}
          <div className="bg-white p-4 rounded-xl border border-amber-200/80 space-y-3 text-xs">
            <h5 className="font-bold text-amber-900 border-b pb-1">
              Laboratorium Virtual: Uji Kespontanan Reaksi Redoks (Logam M + Larutan Kation X²⁺)
            </h5>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 items-center">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Logam Padat (M):
                </label>
                <select
                  value={testSolid}
                  onChange={(e) => setTestSolid(e.target.value)}
                  className="w-full p-2 border rounded-lg bg-slate-50"
                >
                  <option value="Fe">Besi (Fe) [Bahan Opsi 1]</option>
                  <option value="Cu">Tembaga (Cu) [Bahan Opsi 2]</option>
                  <option value="Zn">Seng (Zn)</option>
                  <option value="Mg">Magnesium (Mg)</option>
                  <option value="Ag">Perak (Ag)</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Larutan Kation Ion (X²⁺):
                </label>
                <select
                  value={testIon}
                  onChange={(e) => setTestIon(e.target.value)}
                  className="w-full p-2 border rounded-lg bg-slate-50"
                >
                  <option value="Zn">Larutan Seng Sulfat (Zn²⁺)</option>
                  <option value="Cu">Larutan Tembaga Sulfat (Cu²⁺)</option>
                  <option value="Fe">Larutan Besi(II) Sulfat (Fe²⁺)</option>
                </select>
              </div>

              <div
                className={`p-3 rounded-xl border text-center font-bold ${
                  spontResult.isSpontaneous
                    ? 'bg-rose-50 border-rose-200 text-rose-700'
                    : 'bg-emerald-50 border-emerald-200 text-emerald-700'
                }`}
              >
                <span className="text-[10px] text-slate-500 uppercase block">Hasil Uji:</span>
                <span className="text-xs block mt-0.5">{spontResult.statusText}</span>
                <span className="text-[11px] font-mono block mt-1">
                  $E^\circ_{'{sel}'}$: {spontResult.eCell > 0 ? '+' : ''}
                  {spontResult.eCell.toFixed(2)} V
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FASE 4: Mengembangkan & Menyajikan Hasil Karya */}
      <section className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 space-y-6">
        <div className="border-b border-slate-100 pb-3 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 bg-indigo-600 text-white rounded-full text-xs font-bold uppercase">
              Fase 4
            </span>
            <h3 className="text-base font-bold text-slate-800">
              Mengembangkan &amp; Menyajikan Hasil Karya: Perhitungan Galat, Notasi Sel &amp; Deret Volta
            </h3>
          </div>
          <span className="text-xs text-slate-500 font-semibold">Bobot Rubrik: 30 Poin</span>
        </div>

        {/* Dedicated Phase 4 Analysis & Calculation Component */}
        <Phase4ResultsWorksheet
          lkpdConfig={lkpdConfig}
          answers={answers}
          onAnswerChange={handleAnswerChange}
        />

        {/* Solusi Saintifik Kasus Otentik */}
        <div className="space-y-4 text-xs pt-2 border-t border-slate-100">
          <h4 className="font-bold text-slate-800 text-sm">
            Penyajian Laporan Solusi Kasus Otentik
          </h4>

          {/* Solusi Kasus 1 */}
          <div className="bg-amber-50/50 p-4 rounded-xl border border-amber-200 space-y-2">
            <h5 className="font-bold text-amber-950 text-xs sm:text-sm">
              A. Solusi Saintifik Kasus 1 (Baterai Buah Lemon vs Tumpukan Volta)
            </h5>
            <label className="block font-semibold text-slate-700">
              Jelaskan secara komprehensif mengapa pasangan elektroda Zn-Cu dapat menyalakan lampu LED,
              sedangkan pasangan Zn-Zn tidak dapat menyalakan lampu sama sekali!
            </label>
            <textarea
              rows={3}
              placeholder="Jelaskan berdasarkan beda potensial sel (E°sel = E°katoda - E°anoda), peran asam sitrat sebagai elektrolit, dan aliran elektron dari seng ke tembaga..."
              value={answers.solCase1 || ''}
              onChange={(e) => handleAnswerChange('solCase1', e.target.value)}
              className="w-full p-2.5 border rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none bg-white leading-relaxed"
            />
          </div>

          {/* Solusi Kasus 2 */}
          <div className="bg-indigo-50/50 p-4 rounded-xl border border-indigo-200 space-y-3">
            <h5 className="font-bold text-indigo-950 text-xs sm:text-sm">
              B. Solusi Saintifik Kasus 2 (Pemilihan Tangki Penyimpan Larutan ZnSO₄)
            </h5>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="bg-white p-3 rounded-lg border border-slate-200">
                <span className="font-bold block text-slate-800">
                  Uji Opsi Bahan Besi (Fe) + ZnSO₄:
                </span>
                <p className="text-[11px] text-slate-500 mb-1">
                  Reaksi: Fe(s) + Zn²⁺(aq) → Fe²⁺(aq) + Zn(s)
                </p>
                <input
                  type="text"
                  placeholder="Hitung E°sel dan jelaskan kespontanannya..."
                  value={answers.case2_fe_e0 || ''}
                  onChange={(e) => handleAnswerChange('case2_fe_e0', e.target.value)}
                  className="w-full p-2 border rounded text-xs"
                />
              </div>

              <div className="bg-white p-3 rounded-lg border border-slate-200">
                <span className="font-bold block text-slate-800">
                  Uji Opsi Bahan Tembaga (Cu) + ZnSO₄:
                </span>
                <p className="text-[11px] text-slate-500 mb-1">
                  Reaksi: Cu(s) + Zn²⁺(aq) → Cu²⁺(aq) + Zn(s)
                </p>
                <input
                  type="text"
                  placeholder="Hitung E°sel dan jelaskan kespontanannya..."
                  value={answers.case2_cu_e0 || ''}
                  onChange={(e) => handleAnswerChange('case2_cu_e0', e.target.value)}
                  className="w-full p-2 border rounded text-xs"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-indigo-950 mb-1">
                Rekomendasi Akhir Bahan Tangki untuk Pabrik Kimia &amp; Alasan Ilmiahnya:
              </label>
              <textarea
                rows={3}
                placeholder="Tuliskan rekomendasi bahan logam terbaik yang aman dan tidak akan berlubang/bocor..."
                value={answers.case2_recommendation || ''}
                onChange={(e) => handleAnswerChange('case2_recommendation', e.target.value)}
                className="w-full p-2.5 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-white leading-relaxed"
              />
            </div>
          </div>
        </div>
      </section>

      {/* FASE 5: Evaluasi HOTS & Refleksi */}
      <section className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 space-y-5">
        <div className="border-b border-slate-100 pb-3 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 bg-indigo-600 text-white rounded-full text-xs font-bold uppercase">
              Fase 5
            </span>
            <h3 className="text-base font-bold text-slate-800">
              Menganalisis &amp; Mengevaluasi Proses Pemecahan Masalah (Evaluasi HOTS)
            </h3>
          </div>
          <span className="text-xs text-slate-500 font-semibold">Bobot Rubrik: 20 Poin</span>
        </div>

        <div className="space-y-4 text-xs">
          {/* Soal HOTS 1: Kontroversi Galvani vs Volta */}
          <div className="bg-amber-50/50 p-4 rounded-xl border border-amber-200 space-y-3">
            <h4 className="font-bold text-amber-950 text-sm flex items-center gap-2">
              <History className="w-4 h-4 text-amber-600" />
              <span>Soal HOTS 1: Analisis Kontroversi Galvani vs Volta Ditinjau dari Sel Elektrokimia Modern</span>
            </h4>
            <p className="text-slate-700 leading-relaxed text-justify">
              Berdasarkan seluruh hasil eksperimen Sel Daniell dan pemahaman Anda tentang jembatan garam serta aliran elektron:
              Mengapa teori "Animal Electricity" Luigi Galvani terbukti keliru ketika ditinjau dari prinsip elektrokimia modern,
              dan bagaimana peran spesifik cairan biologis kaki katak dalam peristiwa tersebut?
            </p>
            <textarea
              rows={3}
              placeholder="Analisis argumentasi saintifik Anda: Hubungkan peran katak sebagai konduktor elektrolit, dua logam kait balkon sebagai elektroda redoks (bimetal), dan mengapa Volta berhasil membuktikannya tanpa hewan..."
              value={answers.hots_galvani_evaluation || ''}
              onChange={(e) => handleAnswerChange('hots_galvani_evaluation', e.target.value)}
              className="w-full p-2.5 border rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none bg-white text-xs leading-relaxed"
            />
          </div>

          {/* Soal HOTS 2: Sel Elektrokimia Tak Dikenal */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
            <h4 className="font-bold text-indigo-950 text-sm flex items-center gap-2">
              <Zap className="w-4 h-4 text-indigo-600" />
              <span>Soal HOTS 2: Analisis Sel Elektrokimia Empat Logam Tak Dikenal (A, B, C, D)</span>
            </h4>
            <div className="p-3 bg-white rounded-lg border font-mono text-[11px] text-slate-700 whitespace-pre-line leading-relaxed">
              {lkpdConfig.hotsQuestion?.context ||
                `Diberikan data potensial sel elektrokimia dari empat logam A, B, C, dan D:
1. A | A²⁺ || B²⁺ | B      E°sel = +1,10 V (Elektron mengalir dari A ke B)
2. C | C²⁺ || B²⁺ | B      E°sel = +0,46 V (Massa elektroda B bertambah)
3. D | D²⁺ || A²⁺ | A      E°sel = +0,74 V (Logam D larut menjadi ion D²⁺)`}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {lkpdConfig.hotsQuestion?.partA?.label || 'a. Urutkan keempat logam dari reduktor terkuat ke terlemah'}:
                </label>
                <input
                  type="text"
                  placeholder="Contoh: D > A > C > B (atau sebaliknya)"
                  value={answers.hots_a || ''}
                  onChange={(e) => handleAnswerChange('hots_a', e.target.value)}
                  className="w-full p-2 border rounded-lg bg-white"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {lkpdConfig.hotsQuestion?.partB?.label || 'b. Hitung potensial sel untuk notasi: C | C²⁺ || D²⁺ | D'}:
                </label>
                <input
                  type="text"
                  placeholder="Tuliskan nilai E°sel (Volt) dan apakah reaksi spontan..."
                  value={answers.hots_b || ''}
                  onChange={(e) => handleAnswerChange('hots_b', e.target.value)}
                  className="w-full p-2 border rounded-lg bg-white"
                />
              </div>
            </div>
          </div>

          {/* Soal HOTS 3: Proteksi Katodik */}
          <div className="bg-indigo-50/50 p-4 rounded-xl border border-indigo-200 space-y-3">
            <h4 className="font-bold text-indigo-950 text-sm flex items-center gap-2">
              <FlaskConical className="w-4 h-4 text-indigo-600" />
              <span>Soal HOTS 3: Aplikasi Nyata Proteksi Katodik (Anoda Korban) untuk Pipa Baja</span>
            </h4>
            <p className="text-slate-700 leading-relaxed text-justify">
              Pipa baja bawah tanah (terutama terdiri dari logam Besi, Fe, E° = -0,44 V) sangat rentan mengalami korosi.
              Untuk melindunginya, pipa tersebut dihubungkan dengan batang logam kurban yang ditanam di tanah basah (elektrolit).
              Manakah di antara logam Magnesium (Mg, E° = -2,37 V) atau Tembaga (Cu, E° = +0,34 V) yang paling tepat dijadikan anoda korban?
              Jelaskan mekanisme perlindungannya ditinjau dari arah transfer elektron dan deret Volta!
            </p>
            <textarea
              rows={3}
              placeholder="Jelaskan alasan ilmiah pemilihan logam anoda korban, mengapa logam tersebut harus teroksidasi lebih dulu, dan apa yang terjadi jika salah memilih logam..."
              value={answers.hots_3_corrosion || ''}
              onChange={(e) => handleAnswerChange('hots_3_corrosion', e.target.value)}
              className="w-full p-2.5 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-white text-xs leading-relaxed"
            />
          </div>

          {/* Refleksi Belajar Metakognisi */}
          <div className="bg-emerald-50/40 p-4 rounded-xl border border-emerald-200 space-y-2">
            <h4 className="font-bold text-emerald-950 text-sm">
              Refleksi Belajar Kelompok (Metakognisi &amp; Evaluasi Diri)
            </h4>
            <textarea
              rows={2}
              placeholder="Tuliskan refleksi kelompok: konsep apa yang paling menantang (apakah fungsi jembatan garam, penentuan katoda/anoda, atau notasi sel), dan bagaimana simulasi virtual membantu pemahaman kalian..."
              value={answers.reflection || ''}
              onChange={(e) => handleAnswerChange('reflection', e.target.value)}
              className="w-full p-2.5 border rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white text-xs leading-relaxed"
            />
          </div>
        </div>

        {/* Footer Actions */}
        <div className="pt-4 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="text-slate-500 flex items-center gap-1.5">
            <Check className="w-4 h-4 text-emerald-600" />
            <span>
              Status Submisi:{' '}
              <strong className="text-slate-700">
                {currentSubmission?.status === 'graded'
                  ? 'Sudah Dinilai'
                  : currentSubmission?.status === 'submitted'
                  ? 'Terkirim (Menunggu Nilai)'
                  : 'Draf Lokal'}
              </strong>
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => window.print()}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold transition flex items-center gap-1.5"
            >
              <Printer className="w-4 h-4" />
              <span>Cetak / PDF</span>
            </button>

            <button
              onClick={handleDownloadJSON}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold transition flex items-center gap-1.5"
            >
              <Download className="w-4 h-4" />
              <span>Unduh JSON</span>
            </button>

            <button
              onClick={handleSaveDraft}
              disabled={isSubmitting}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl font-semibold transition flex items-center gap-1.5 shadow-sm"
            >
              <Save className="w-4 h-4" />
              <span>Simpan Draf</span>
            </button>

            <button
              onClick={handleSubmit}
              disabled={isSubmitting}
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition flex items-center gap-1.5 shadow-md hover:shadow-lg active:scale-98"
            >
              <Send className="w-4 h-4" />
              <span>{isSubmitting ? 'Mengirim...' : 'Kirim Jawaban ke Guru'}</span>
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
