import React, { useRef, useEffect, useState } from 'react';
import { Play, Pause, RotateCcw, Zap, Info } from 'lucide-react';
import { calculateCellPotential, getE0 } from '../../data/voltaData.js';

interface VoltaSimulationProps {
  onSetupChange?: (anode: string, cathode: string, eCell: number) => void;
}

export const VoltaSimulationCanvas: React.FC<VoltaSimulationProps> = ({ onSetupChange }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [anode, setAnode] = useState<string>('Zn');
  const [cathode, setCathode] = useState<string>('Cu');
  const [isRunning, setIsRunning] = useState<boolean>(true);
  const [animStep, setAnimStep] = useState<number>(0);

  const cellStats = calculateCellPotential(anode, cathode);

  useEffect(() => {
    if (onSetupChange) {
      onSetupChange(anode, cathode, cellStats.eCell);
    }
  }, [anode, cathode, cellStats.eCell, onSetupChange]);

  // Animation frame loop
  useEffect(() => {
    let animationId: number;

    const animate = () => {
      if (isRunning && cellStats.isSpontaneous) {
        setAnimStep((prev) => (prev + 1.2) % 200);
      }
      animationId = requestAnimationFrame(animate);
    };

    animationId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationId);
  }, [isRunning, cellStats.isSpontaneous]);

  // Draw on Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;

    ctx.clearRect(0, 0, w, h);

    // Background gradient
    const bgGradient = ctx.createLinearGradient(0, 0, 0, h);
    bgGradient.addColorStop(0, '#f8fafc');
    bgGradient.addColorStop(1, '#f1f5f9');
    ctx.fillStyle = bgGradient;
    ctx.fillRect(0, 0, w, h);

    // 1. Gelas Kimia Kiri (Kompartemen Anoda)
    const beakerLeftX = 65;
    const beakerY = 140;
    const beakerW = 140;
    const beakerH = 135;

    // Larutan elektrolit Anoda (biru muda/transparan)
    ctx.fillStyle = '#e0f2fe';
    ctx.fillRect(beakerLeftX, beakerY + 30, beakerW, beakerH - 30);
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 2.5;
    ctx.strokeRect(beakerLeftX, beakerY, beakerW, beakerH);

    ctx.fillStyle = '#0369a1';
    ctx.font = 'bold 11px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(`Larutan ${anode}SO₄ 1 M`, beakerLeftX + beakerW / 2, beakerY + beakerH - 18);
    ctx.font = '10px sans-serif';
    ctx.fillStyle = '#0284c7';
    ctx.fillText(`(Kation ${anode}²⁺ & Anion SO₄²⁻)`, beakerLeftX + beakerW / 2, beakerY + beakerH - 6);

    // 2. Gelas Kimia Kanan (Kompartemen Katoda)
    const beakerRightX = 355;
    ctx.fillStyle = '#f0fdf4';
    ctx.fillRect(beakerRightX, beakerY + 30, beakerW, beakerH - 30);
    ctx.strokeStyle = '#4ade80';
    ctx.lineWidth = 2.5;
    ctx.strokeRect(beakerRightX, beakerY, beakerW, beakerH);

    ctx.fillStyle = '#15803d';
    ctx.font = 'bold 11px sans-serif';
    ctx.fillText(`Larutan ${cathode}SO₄ 1 M`, beakerRightX + beakerW / 2, beakerY + beakerH - 18);
    ctx.font = '10px sans-serif';
    ctx.fillStyle = '#16a34a';
    ctx.fillText(`(Kation ${cathode}²⁺ & Anion SO₄²⁻)`, beakerRightX + beakerW / 2, beakerY + beakerH - 6);

    // 3. Batang Elektroda Padat
    // Elektroda Anoda
    const anodeElectrodeX = beakerLeftX + 50;
    const anodeElectrodeY = 95;
    ctx.fillStyle = '#94a3b8'; // zinc/silver shade
    ctx.fillRect(anodeElectrodeX, anodeElectrodeY, 26, 110);
    ctx.strokeStyle = '#475569';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(anodeElectrodeX, anodeElectrodeY, 26, 110);

    ctx.fillStyle = '#0f172a';
    ctx.font = 'bold 11px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(`Anoda: ${anode}(s)`, anodeElectrodeX + 13, anodeElectrodeY - 14);
    ctx.font = '10px sans-serif';
    ctx.fillStyle = '#e11d48';
    ctx.fillText(`[-] Oksidasi`, anodeElectrodeX + 13, anodeElectrodeY - 3);

    // Elektroda Katoda
    const cathodeElectrodeX = beakerRightX + 64;
    const cathodeElectrodeY = 95;
    ctx.fillStyle = cathode === 'Cu' ? '#d97706' : cathode === 'Ag' ? '#cbd5e1' : '#64748b';
    ctx.fillRect(cathodeElectrodeX, cathodeElectrodeY, 26, 110);
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(cathodeElectrodeX, cathodeElectrodeY, 26, 110);

    ctx.fillStyle = '#0f172a';
    ctx.font = 'bold 11px sans-serif';
    ctx.fillText(`Katoda: ${cathode}(s)`, cathodeElectrodeX + 13, cathodeElectrodeY - 14);
    ctx.font = '10px sans-serif';
    ctx.fillStyle = '#16a34a';
    ctx.fillText(`[+] Reduksi`, cathodeElectrodeX + 13, cathodeElectrodeY - 3);

    // 4. Jembatan Garam (Salt Bridge berbentuk U terbalik)
    const bridgeLeftX = beakerLeftX + beakerW - 20;
    const bridgeRightX = beakerRightX + 20;
    const bridgeTopY = 110;
    const bridgeBottomY = 185;
    const bridgeThickness = 22;

    ctx.fillStyle = '#fef08a';
    ctx.beginPath();
    ctx.moveTo(bridgeLeftX, bridgeBottomY);
    ctx.lineTo(bridgeLeftX, bridgeTopY);
    ctx.lineTo(bridgeRightX, bridgeTopY);
    ctx.lineTo(bridgeRightX, bridgeBottomY);
    ctx.lineTo(bridgeRightX - bridgeThickness, bridgeBottomY);
    ctx.lineTo(bridgeRightX - bridgeThickness, bridgeTopY + bridgeThickness);
    ctx.lineTo(bridgeLeftX + bridgeThickness, bridgeTopY + bridgeThickness);
    ctx.lineTo(bridgeLeftX + bridgeThickness, bridgeBottomY);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = '#ca8a04';
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.fillStyle = '#854d0e';
    ctx.font = 'bold 9px sans-serif';
    ctx.fillText('Jembatan Garam Agar (KNO₃ / KCl)', (bridgeLeftX + bridgeRightX) / 2, bridgeTopY + 15);

    // Ion diffusion markers on salt bridge
    ctx.font = '9px sans-serif';
    ctx.fillStyle = '#b45309';
    ctx.fillText('NO₃⁻ →', bridgeLeftX + 5, bridgeBottomY - 10);
    ctx.fillText('← K⁺', bridgeRightX - 5, bridgeBottomY - 10);

    // 5. Kawat Penghantar Sirkuit Luar
    const wireStartY = 95;
    const wireTopY = 40;
    const meterCenterX = (anodeElectrodeX + cathodeElectrodeX) / 2;

    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 3;
    ctx.beginPath();
    // Kiri ke meteran
    ctx.moveTo(anodeElectrodeX + 13, wireStartY);
    ctx.lineTo(anodeElectrodeX + 13, wireTopY);
    ctx.lineTo(meterCenterX - 35, wireTopY);
    // Meteran ke kanan
    ctx.moveTo(meterCenterX + 35, wireTopY);
    ctx.lineTo(cathodeElectrodeX + 13, wireTopY);
    ctx.lineTo(cathodeElectrodeX + 13, wireStartY);
    ctx.stroke();

    // 6. Voltmeter & LED Indicator Lamp
    const isLampOn = cellStats.isSpontaneous && isRunning;

    // Glowing aura if lamp is on
    if (isLampOn) {
      const glowGrad = ctx.createRadialGradient(
        meterCenterX,
        wireTopY,
        15,
        meterCenterX,
        wireTopY,
        50
      );
      glowGrad.addColorStop(0, 'rgba(250, 204, 21, 0.7)');
      glowGrad.addColorStop(1, 'rgba(250, 204, 21, 0)');
      ctx.fillStyle = glowGrad;
      ctx.beginPath();
      ctx.arc(meterCenterX, wireTopY, 50, 0, Math.PI * 2);
      ctx.fill();
    }

    // Voltmeter Case
    ctx.fillStyle = isLampOn ? '#fef08a' : '#e2e8f0';
    ctx.beginPath();
    ctx.arc(meterCenterX, wireTopY, 32, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 2.5;
    ctx.stroke();

    // Voltmeter Display Text
    ctx.fillStyle = '#0f172a';
    ctx.font = 'bold 11px sans-serif';
    ctx.fillText(isLampOn ? '💡 LED ON' : '⚪ OFF', meterCenterX, wireTopY - 6);

    ctx.font = 'bold 13px monospace';
    ctx.fillStyle = cellStats.eCell > 0 ? '#15803d' : '#be123c';
    ctx.fillText(
      `${cellStats.eCell > 0 ? '+' : ''}${cellStats.eCell.toFixed(2)} V`,
      meterCenterX,
      wireTopY + 11
    );

    ctx.font = '8px sans-serif';
    ctx.fillStyle = '#64748b';
    ctx.fillText('VOLTMETER', meterCenterX, wireTopY + 22);

    // 7. Animasi Elektron Mengalir (titik merah bergerak)
    if (isLampOn) {
      ctx.fillStyle = '#ef4444';
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1;

      // Jalur kiri (naik dan ke kanan)
      const leftWireLength = (anodeElectrodeX + 13 - (anodeElectrodeX + 13)) + (wireStartY - wireTopY) + (meterCenterX - 35 - (anodeElectrodeX + 13));
      const pos1 = (animStep * 1.5) % 180;

      if (pos1 < (wireStartY - wireTopY)) {
        // bergerak ke atas
        const curY = wireStartY - pos1;
        ctx.beginPath();
        ctx.arc(anodeElectrodeX + 13, curY, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      } else {
        // bergerak ke kanan
        const curX = anodeElectrodeX + 13 + (pos1 - (wireStartY - wireTopY));
        if (curX < meterCenterX - 35) {
          ctx.beginPath();
          ctx.arc(curX, wireTopY, 4, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();
        }
      }

      // Jalur kanan (dari meteran ke katoda)
      const pos2 = (animStep * 1.5 + 90) % 180;
      const rightWireStart = meterCenterX + 35;
      const rightTurnX = cathodeElectrodeX + 13;

      if (pos2 < (rightTurnX - rightWireStart)) {
        const curX = rightWireStart + pos2;
        ctx.beginPath();
        ctx.arc(curX, wireTopY, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      } else {
        const curY = wireTopY + (pos2 - (rightTurnX - rightWireStart));
        if (curY < wireStartY) {
          ctx.beginPath();
          ctx.arc(rightTurnX, curY, 4, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();
        }
      }
    }
  }, [anode, cathode, animStep, isRunning, cellStats]);

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-indigo-50 text-indigo-700 rounded-lg">
            <Zap className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold text-slate-800 text-sm">
              Simulator Interaktif Aliran Elektron &amp; Reaksi Sel Volta
            </h4>
            <p className="text-xs text-slate-500">
              Pilih pasangan logam untuk mengamati arah aliran elektron dan nilai $E^\circ_{'{sel}'}$.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsRunning(!isRunning)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition ${
              isRunning
                ? 'bg-amber-100 text-amber-800 hover:bg-amber-200'
                : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-sm'
            }`}
          >
            {isRunning ? (
              <>
                <Pause className="w-3.5 h-3.5" />
                <span>Jeda Aliran</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5" />
                <span>Jalankan Aliran</span>
              </>
            )}
          </button>
          <button
            onClick={() => {
              setAnode('Zn');
              setCathode('Cu');
              setIsRunning(true);
            }}
            className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg transition"
            title="Reset ke pasangan Zn-Cu"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-center">
        {/* Controls Column */}
        <div className="lg:col-span-4 space-y-3.5">
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Anoda (Kutub Negatif - Reaksi Oksidasi):
              </label>
              <select
                value={anode}
                onChange={(e) => setAnode(e.target.value)}
                className="w-full p-2 bg-white border border-slate-300 rounded-lg font-medium text-slate-800 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              >
                <option value="Mg">Magnesium (Mg) [E° = -2.37 V]</option>
                <option value="Al">Aluminium (Al) [E° = -1.66 V]</option>
                <option value="Zn">Seng (Zn) [E° = -0.76 V]</option>
                <option value="Fe">Besi (Fe) [E° = -0.44 V]</option>
                <option value="Cu">Tembaga (Cu) [E° = +0.34 V]</option>
                <option value="Ag">Perak (Ag) [E° = +0.80 V]</option>
              </select>
              <span className="text-[11px] text-slate-500 mt-0.5 block">
                E° reduksi {anode}: {getE0(anode) > 0 ? '+' : ''}
                {getE0(anode).toFixed(2)} V
              </span>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Katoda (Kutub Positif - Reaksi Reduksi):
              </label>
              <select
                value={cathode}
                onChange={(e) => setCathode(e.target.value)}
                className="w-full p-2 bg-white border border-slate-300 rounded-lg font-medium text-slate-800 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              >
                <option value="Cu">Tembaga (Cu) [E° = +0.34 V]</option>
                <option value="Ag">Perak (Ag) [E° = +0.80 V]</option>
                <option value="Au">Emas (Au) [E° = +1.50 V]</option>
                <option value="Fe">Besi (Fe) [E° = -0.44 V]</option>
                <option value="Zn">Seng (Zn) [E° = -0.76 V]</option>
              </select>
              <span className="text-[11px] text-slate-500 mt-0.5 block">
                E° reduksi {cathode}: {getE0(cathode) > 0 ? '+' : ''}
                {getE0(cathode).toFixed(2)} V
              </span>
            </div>

            {/* Readout Card */}
            <div className="p-3 bg-indigo-50/70 border border-indigo-200/70 rounded-lg space-y-1.5">
              <div className="flex justify-between items-center text-xs font-bold">
                <span className="text-indigo-950">Potensial Sel ($E^\circ_{'{sel}'}$):</span>
                <span
                  className={`text-sm font-mono ${
                    cellStats.eCell > 0
                      ? 'text-emerald-700 font-extrabold'
                      : 'text-rose-700 font-extrabold'
                  }`}
                >
                  {cellStats.eCell > 0 ? '+' : ''}
                  {cellStats.eCell.toFixed(2)} V
                </span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-600">Status Kespontanan:</span>
                <span
                  className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                    cellStats.isSpontaneous
                      ? 'bg-emerald-100 text-emerald-800'
                      : cellStats.eCell === 0
                      ? 'bg-slate-200 text-slate-800'
                      : 'bg-rose-100 text-rose-800'
                  }`}
                >
                  {cellStats.isSpontaneous
                    ? 'SPONTAN'
                    : cellStats.eCell === 0
                    ? 'SETIMBANG'
                    : 'TIDAK SPONTAN'}
                </span>
              </div>
              <div className="text-[11px] text-slate-600 pt-1 border-t border-indigo-200/60">
                <span className="font-semibold block text-slate-700">Notasi Sel Volta:</span>
                <code className="text-indigo-900 font-bold font-mono">
                  {cellStats.cellNotation}
                </code>
              </div>
            </div>
          </div>

          <div className="flex items-start gap-2 text-[11px] text-slate-500 bg-amber-50/60 p-2.5 rounded-lg border border-amber-200/60">
            <Info className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <span>
              Perhatikan arah titik merah (elektron) yang mengalir dari anoda ke katoda saat
              $E^\circ_{'{sel}'} &gt; 0$.
            </span>
          </div>
        </div>

        {/* Canvas Display Column */}
        <div className="lg:col-span-8 flex justify-center">
          <div className="w-full max-w-[560px] overflow-hidden rounded-xl border border-slate-300 shadow-inner bg-slate-100">
            <canvas
              ref={canvasRef}
              width={560}
              height={300}
              className="w-full h-auto block"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
