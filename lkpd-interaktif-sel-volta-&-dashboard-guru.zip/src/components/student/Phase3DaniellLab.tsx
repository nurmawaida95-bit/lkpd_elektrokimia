import React, { useState } from 'react';
import {
  FlaskConical,
  Gauge,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  ArrowRight,
  Sparkles,
  Zap,
  Info,
} from 'lucide-react';
import { calculateCellPotential, getE0 } from '../../data/voltaData.js';
import type { LKPDConfig } from '../../types.js';

interface Phase3DaniellLabProps {
  lkpdConfig: LKPDConfig;
  answers: Record<string, string>;
  onAnswerChange: (key: string, value: string) => void;
}

export const Phase3DaniellLab: React.FC<Phase3DaniellLabProps> = ({
  lkpdConfig,
  answers,
  onAnswerChange,
}) => {
  // Selected metals for Daniell cell assembly
  const [anodeMetal, setAnodeMetal] = useState<string>('Zn');
  const [cathodeMetal, setCathodeMetal] = useState<string>('Cu');
  const [multimeterRange, setMultimeterRange] = useState<'2V' | '20V'>('20V');
  const [isProbeConnected, setIsProbeConnected] = useState<boolean>(true);
  const [activeStepTab, setActiveStepTab] = useState<number>(1);

  // Metal library for exploration
  const availableMetals = [
    { symbol: 'Mg', name: 'Magnesium', e0: -2.37, color: '#facc15' },
    { symbol: 'Al', name: 'Aluminium', e0: -1.66, color: '#eab308' },
    { symbol: 'Zn', name: 'Seng', e0: -0.76, color: '#94a3b8' },
    { symbol: 'Fe', name: 'Besi', e0: -0.44, color: '#64748b' },
    { symbol: 'Cu', name: 'Tembaga', e0: +0.34, color: '#d97706' },
  ];

  // Calculate theoretical E0
  const theoreticalE0 = Number((getE0(cathodeMetal) - getE0(anodeMetal)).toFixed(2));
  const isSpontaneous = theoreticalE0 > 0;

  // Realistic experimental reading with typical 0.02 - 0.05 V internal resistance loss in student lab
  const expLoss = isSpontaneous ? (anodeMetal === 'Zn' && cathodeMetal === 'Cu' ? 0.02 : 0.04) : 0;
  const experimentalVoltage = isSpontaneous
    ? Number((theoreticalE0 - expLoss).toFixed(2))
    : 0.00;

  const handleCopyVoltage = () => {
    const key = `exp_${anodeMetal.toLowerCase()}_${cathodeMetal.toLowerCase()}_volt`;
    onAnswerChange(key, `${experimentalVoltage}`);
    if (anodeMetal === 'Zn' && cathodeMetal === 'Cu') {
      onAnswerChange('exp_zn_cu_volt', `${experimentalVoltage}`);
    }
  };

  const saltBridgeSteps = lkpdConfig.saltBridgeGuide?.steps || [
    {
      stepNumber: 1,
      title: 'Penimbangan & Pelarutan',
      instruction: 'Timbang 3–5 gram bubuk agar-agar tanpa rasa dan 15 gram kalium klorida (KCl). Larutkan ke dalam 100 mL air suling (akuades) dalam gelas kimia 250 mL.',
      keyTip: 'KCl dipilih karena ion K⁺ dan Cl⁻ memiliki mobilitas ionik (kecepatan gerak) yang hampir identik.',
    },
    {
      stepNumber: 2,
      title: 'Pemanasan Homogen',
      instruction: 'Panaskan campuran di atas penangas air atau hotplate sambil diaduk perlahan menggunakan batang pengaduk hingga larutan mendidih dan menjadi bening/transparan.',
      keyTip: 'Jangan biarkan larutan hangus atau berbuih meluap; aduk konstan agar agar-agar larut sempurna.',
    },
    {
      stepNumber: 3,
      title: 'Pengisian Pipa U',
      instruction: 'Selagi hangat dan masih cair, tuangkan larutan agar-agar KCl ke dalam pipa U kaca (atau selang plastik transparan fleksibel) secara perlahan hingga terisi penuh.',
      keyTip: 'Pastikan TIDAK ADA gelembung udara di dalam pipa U karena gelembung akan memutuskan aliran arus ion!',
    },
    {
      stepNumber: 4,
      title: 'Pendinginan & Gelasi',
      instruction: 'Sumbat kedua ujung pipa U dengan sedikit kapas steril jika diperlukan, lalu diamkan pada suhu ruang atau rendam di air es hingga memadat membentuk gel kenyal.',
      keyTip: 'Gel agar-agar menahan cairan agar tidak tumpah dan mencegah larutan kedua gelas kimia bercampur secara langsung.',
    },
    {
      stepNumber: 5,
      title: 'Pemasangan ke Rangkaian',
      instruction: 'Celupkan salah satu kaki pipa U ke dalam gelas kimia Anoda dan kaki lainnya ke dalam gelas kimia Katoda. Jembatan garam siap menghantarkan ion.',
      keyTip: 'Jika tidak sedang digunakan, simpan jembatan garam dalam larutan KCl jenuh agar tidak mengering.',
    },
  ];

  return (
    <div className="space-y-6">
      {/* 1. Panduan Pembuatan Jembatan Garam Agar-Agar KCl */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
              <FlaskConical className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-slate-800 text-sm">
                Panduan Prosedur Laboratorium: Pembuatan Jembatan Garam Agar-Agar KCl
              </h4>
              <p className="text-xs text-slate-500">
                Langkah-langkah pembuatan jembatan garam elektrolit padat untuk merangkai Sel Daniell.
              </p>
            </div>
          </div>
          <span className="px-2.5 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-lg text-xs font-semibold">
            5 Langkah Terbimbing
          </span>
        </div>

        {/* Step Indicator Tabs */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
          {saltBridgeSteps.map((s) => (
            <button
              key={s.stepNumber}
              onClick={() => setActiveStepTab(s.stepNumber)}
              className={`p-2.5 rounded-xl text-left border transition text-xs flex flex-col justify-between ${
                activeStepTab === s.stepNumber
                  ? 'bg-emerald-700 text-white border-emerald-800 shadow-sm'
                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
              }`}
            >
              <div className="flex items-center justify-between font-bold mb-1">
                <span>Langkah {s.stepNumber}</span>
                {activeStepTab === s.stepNumber && <Sparkles className="w-3 h-3 text-amber-300" />}
              </div>
              <span className="truncate text-[11px] opacity-90">{s.title}</span>
            </button>
          ))}
        </div>

        {/* Step Content Card */}
        {saltBridgeSteps.map((step) => {
          if (step.stepNumber !== activeStepTab) return null;
          return (
            <div
              key={step.stepNumber}
              className="bg-emerald-50/50 border border-emerald-200 rounded-xl p-4 text-xs space-y-3 animate-in fade-in"
            >
              <div className="flex items-center justify-between">
                <h5 className="font-bold text-emerald-950 text-sm flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-emerald-700 text-white flex items-center justify-center text-xs font-mono">
                    {step.stepNumber}
                  </span>
                  {step.title}
                </h5>
                <span className="text-[11px] text-emerald-700 font-medium">Prosedur Kerja Saintifik</span>
              </div>

              <p className="text-slate-700 leading-relaxed text-xs">
                {step.instruction}
              </p>

              <div className="p-2.5 bg-white rounded-lg border border-emerald-200 text-emerald-900 flex items-start gap-2">
                <Sparkles className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-[11px] font-bold text-emerald-800">
                    Kunci Pengetahuan &amp; Tips Laboratorium:
                  </strong>
                  <span className="text-[11px] leading-normal">{step.keyTip}</span>
                </div>
              </div>
            </div>
          );
        })}

        {/* Scaffolding Question about Salt Bridge Preparation */}
        <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs space-y-2">
          <label className="block font-semibold text-slate-700">
            Pertanyaan Refleksi Penyelidikan: Mengapa garam KCl sangat cocok digunakan untuk jembatan garam pada Sel Daniell, dan mengapa tidak boleh ada gelembung udara di dalam pipa U?
          </label>
          <textarea
            rows={2}
            placeholder="Jelaskan ditinjau dari mobilitas ion K⁺ & Cl⁻ dan kontinuitas sirkuit ionik..."
            value={answers.salt_bridge_understanding || ''}
            onChange={(e) => onAnswerChange('salt_bridge_understanding', e.target.value)}
            className="w-full p-2.5 border rounded-lg bg-white text-xs"
          />
        </div>
      </div>

      {/* 2. Perakitan Sel Daniell & Eksplorasi Variasi Logam + Voltmeter Digital */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-indigo-100 text-indigo-800 rounded-xl">
              <Gauge className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-slate-800 text-sm">
                Laboratorium Perakitan Sel Daniell &amp; Penggunaan Voltmeter Digital
              </h4>
              <p className="text-xs text-slate-500">
                Pilih kombinasi elektroda (Mg, Fe, Al, Cu, Zn) dan amati pengukuran tegangan pada multimeter digital.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <button
              onClick={() => {
                setAnodeMetal('Zn');
                setCathodeMetal('Cu');
                setIsProbeConnected(true);
              }}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-medium transition"
            >
              Reset ke Sel Daniell (Zn-Cu)
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          {/* Controls Column */}
          <div className="lg:col-span-5 space-y-4 text-xs">
            {/* Anode Selector */}
            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <label className="font-bold text-slate-800 flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
                  Kutub Anoda [-] (Probe Hitam / Oksidasi):
                </label>
                <span className="text-[11px] font-mono text-slate-500">
                  E° = {getE0(anodeMetal).toFixed(2)} V
                </span>
              </div>
              <div className="grid grid-cols-5 gap-1.5">
                {availableMetals.map((m) => (
                  <button
                    key={m.symbol}
                    onClick={() => setAnodeMetal(m.symbol)}
                    className={`py-2 px-1 rounded-lg font-bold text-center border transition ${
                      anodeMetal === m.symbol
                        ? 'bg-rose-600 text-white border-rose-700 shadow-xs ring-2 ring-rose-300'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {m.symbol}
                  </button>
                ))}
              </div>
              <span className="text-[10px] text-slate-500 block">
                Dipasangkan ke larutan elektrolit: <strong>{anodeMetal}SO₄ 1 M</strong>
              </span>
            </div>

            {/* Cathode Selector */}
            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <label className="font-bold text-slate-800 flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                  Kutub Katoda [+] (Probe Merah / Reduksi):
                </label>
                <span className="text-[11px] font-mono text-slate-500">
                  E° = {getE0(cathodeMetal) > 0 ? '+' : ''}
                  {getE0(cathodeMetal).toFixed(2)} V
                </span>
              </div>
              <div className="grid grid-cols-5 gap-1.5">
                {availableMetals.map((m) => (
                  <button
                    key={m.symbol}
                    onClick={() => setCathodeMetal(m.symbol)}
                    className={`py-2 px-1 rounded-lg font-bold text-center border transition ${
                      cathodeMetal === m.symbol
                        ? 'bg-emerald-600 text-white border-emerald-700 shadow-xs ring-2 ring-emerald-300'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {m.symbol}
                  </button>
                ))}
              </div>
              <span className="text-[10px] text-slate-500 block">
                Dipasangkan ke larutan elektrolit: <strong>{cathodeMetal}SO₄ 1 M</strong>
              </span>
            </div>

            {/* Comparison theoretical vs experimental card */}
            <div className="bg-indigo-50/70 border border-indigo-200 rounded-xl p-3.5 space-y-2 text-xs">
              <div className="flex justify-between items-center">
                <span className="text-slate-600">Potensial Teoritis (E°sel):</span>
                <span className="font-bold font-mono text-indigo-900 text-sm">
                  {theoreticalE0 > 0 ? '+' : ''}
                  {theoreticalE0.toFixed(2)} Volt
                </span>
              </div>
              <div className="flex justify-between items-center border-t border-indigo-100 pt-1.5">
                <span className="text-slate-600">Potensial Terukur Eksperimen:</span>
                <span className="font-extrabold font-mono text-emerald-700 text-sm">
                  {isSpontaneous ? `+${experimentalVoltage.toFixed(2)} Volt` : '0.00 Volt'}
                </span>
              </div>
              <button
                onClick={handleCopyVoltage}
                className="w-full mt-2 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg transition text-xs shadow-xs flex items-center justify-center gap-1.5"
              >
                <span>Catat Hasil Pengukuran ({anodeMetal}-{cathodeMetal})</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Interactive Digital Multimeter Column */}
          <div className="lg:col-span-7 flex flex-col items-center">
            {/* Multimeter Casing */}
            <div className="w-full max-w-[340px] bg-slate-900 rounded-3xl p-5 shadow-2xl border-4 border-slate-800 text-white space-y-4">
              {/* Brand Header */}
              <div className="flex items-center justify-between text-[11px] text-slate-400 border-b border-slate-800 pb-2">
                <span className="font-black tracking-wider text-amber-400">DIGITAL VOLTMETER</span>
                <span className="text-[10px] font-mono">MODEL D-2026</span>
              </div>

              {/* Digital 7-Segment LCD Display */}
              <div className="bg-[#12281e] p-4 rounded-xl border-2 border-emerald-950/80 shadow-inner relative overflow-hidden">
                <div className="text-[9px] font-mono text-emerald-400/60 uppercase tracking-widest flex justify-between mb-1">
                  <span>DC VOLTAGE</span>
                  <span>{multimeterRange} RANGE</span>
                </div>
                <div className="text-right font-mono font-black text-4xl tracking-wider text-[#34d399] drop-shadow-[0_0_8px_rgba(52,211,153,0.6)]">
                  {isProbeConnected
                    ? isSpontaneous
                      ? `+${experimentalVoltage.toFixed(2)}`
                      : '0.00'
                    : '---'}
                  <span className="text-xl ml-1 text-emerald-400">V</span>
                </div>
                <div className="text-[10px] text-emerald-400/70 mt-1 flex justify-between font-mono">
                  <span>AUTO-RANGE</span>
                  <span>{isSpontaneous ? 'SPONTANEOUS' : 'INACTIVE'}</span>
                </div>
              </div>

              {/* Rotary Switch Range Selector */}
              <div className="flex justify-center items-center gap-3 pt-1">
                <button
                  onClick={() => setMultimeterRange('2V')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition border ${
                    multimeterRange === '2V'
                      ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-md'
                      : 'bg-slate-800 text-slate-300 border-slate-700'
                  }`}
                >
                  2V DC
                </button>
                <button
                  onClick={() => setMultimeterRange('20V')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition border ${
                    multimeterRange === '20V'
                      ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-md'
                      : 'bg-slate-800 text-slate-300 border-slate-700'
                  }`}
                >
                  20V DC
                </button>
              </div>

              {/* Probe Terminals */}
              <div className="pt-2 border-t border-slate-800 flex justify-around text-center text-[10px]">
                <div className="space-y-1">
                  <div className="w-8 h-8 rounded-full bg-rose-600 border-2 border-white mx-auto flex items-center justify-center font-bold text-white shadow-sm">
                    +
                  </div>
                  <span className="text-slate-400">Probe Merah</span>
                  <span className="block text-[9px] text-emerald-400 font-bold">
                    Katoda: {cathodeMetal}
                  </span>
                </div>

                <div className="space-y-1">
                  <div className="w-8 h-8 rounded-full bg-slate-950 border-2 border-slate-500 mx-auto flex items-center justify-center font-bold text-white shadow-sm">
                    -
                  </div>
                  <span className="text-slate-400">Probe Hitam</span>
                  <span className="block text-[9px] text-rose-400 font-bold">
                    Anoda: {anodeMetal}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
