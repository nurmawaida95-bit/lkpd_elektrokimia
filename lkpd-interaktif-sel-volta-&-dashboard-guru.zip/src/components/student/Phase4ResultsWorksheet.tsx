import React, { useState, useEffect } from 'react';
import {
  Calculator,
  Percent,
  CheckCircle2,
  AlertTriangle,
  Layers,
  ArrowUpDown,
  Sparkles,
  HelpCircle,
  FileCheck,
  Check,
} from 'lucide-react';
import type { LKPDConfig } from '../../types.js';

interface Phase4ResultsWorksheetProps {
  lkpdConfig: LKPDConfig;
  answers: Record<string, string>;
  onAnswerChange: (key: string, value: string) => void;
}

export const Phase4ResultsWorksheet: React.FC<Phase4ResultsWorksheetProps> = ({
  lkpdConfig,
  answers,
  onAnswerChange,
}) => {
  // Percent Error State
  const theoreticalZnCu = 1.10;
  const initialExp = parseFloat(answers.exp_zn_cu_volt || '1.08') || 1.08;
  const [expVoltInput, setExpVoltInput] = useState<string>(answers.exp_zn_cu_volt || '1.08');

  // Cell Notations Tasks
  const notationList = [
    {
      id: 'notation_zn_cu',
      pair: 'Zn - Cu (Sel Daniell)',
      anode: 'Zn',
      cathode: 'Cu',
      e0Teoritis: 1.10,
      correctNotation: 'Zn | Zn²⁺ || Cu²⁺ | Cu',
      sampleHint: 'Anoda: Zn teroksidasi ke Zn²⁺; Katoda: Cu²⁺ tereduksi ke Cu',
    },
    {
      id: 'notation_mg_cu',
      pair: 'Mg - Cu',
      anode: 'Mg',
      cathode: 'Cu',
      e0Teoritis: 2.71,
      correctNotation: 'Mg | Mg²⁺ || Cu²⁺ | Cu',
      sampleHint: 'Mg | Mg²⁺ || Cu²⁺ | Cu',
    },
    {
      id: 'notation_al_cu',
      pair: 'Al - Cu',
      anode: 'Al',
      cathode: 'Cu',
      e0Teoritis: 2.00,
      correctNotation: 'Al | Al³⁺ || Cu²⁺ | Cu',
      sampleHint: 'Al | Al³⁺ || Cu²⁺ | Cu (perhatikan ion Al³⁺)',
    },
    {
      id: 'notation_fe_cu',
      pair: 'Fe - Cu',
      anode: 'Fe',
      cathode: 'Cu',
      e0Teoritis: 0.78,
      correctNotation: 'Fe | Fe²⁺ || Cu²⁺ | Cu',
      sampleHint: 'Fe | Fe²⁺ || Cu²⁺ | Cu',
    },
    {
      id: 'notation_zn_fe',
      pair: 'Zn - Fe',
      anode: 'Zn',
      cathode: 'Fe',
      e0Teoritis: 0.32,
      correctNotation: 'Zn | Zn²⁺ || Fe²⁺ | Fe',
      sampleHint: 'Zn | Zn²⁺ || Fe²⁺ | Fe',
    },
  ];

  // Volta Series Ordering State
  // Correct order from strongest reducer (easiest oxidized) to weakest: Mg > Al > Zn > Fe > Cu
  const correctVoltaOrder = ['Mg', 'Al', 'Zn', 'Fe', 'Cu'];
  const [currentOrder, setCurrentOrder] = useState<string[]>(() => {
    if (answers.volta_series_order) {
      const parsed = answers.volta_series_order.split('>').map((s) => s.trim());
      if (parsed.length === 5) return parsed;
    }
    return ['Cu', 'Fe', 'Zn', 'Al', 'Mg']; // Initial shuffled
  });
  const [orderChecked, setOrderChecked] = useState<boolean>(false);
  const [isOrderCorrect, setIsOrderCorrect] = useState<boolean>(false);

  // Calculate live error percent
  const numExp = parseFloat(expVoltInput) || 0;
  const calculatedErrorPercent =
    numExp > 0
      ? Number(((Math.abs(theoreticalZnCu - numExp) / theoreticalZnCu) * 100).toFixed(2))
      : 0;

  useEffect(() => {
    onAnswerChange('percent_error_zn_cu', `${calculatedErrorPercent}%`);
    onAnswerChange('exp_zn_cu_volt', expVoltInput);
  }, [calculatedErrorPercent, expVoltInput]);

  const moveItem = (index: number, direction: 'left' | 'right') => {
    const newArr = [...currentOrder];
    const targetIdx = direction === 'left' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= newArr.length) return;
    const temp = newArr[index];
    newArr[index] = newArr[targetIdx];
    newArr[targetIdx] = temp;
    setCurrentOrder(newArr);
    onAnswerChange('volta_series_order', newArr.join(' > '));
    setOrderChecked(false);
  };

  const verifyVoltaOrder = () => {
    const isMatch = currentOrder.every((m, idx) => m === correctVoltaOrder[idx]);
    setIsOrderCorrect(isMatch);
    setOrderChecked(true);
    onAnswerChange('volta_series_order', currentOrder.join(' > '));
  };

  return (
    <div className="space-y-6">
      {/* 1. Perhitungan Galat Persen (% Error) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-indigo-100 text-indigo-800 rounded-xl">
              <Percent className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-slate-800 text-sm">
                1. Perhitungan Galat Persen (% Error) Sel Daniell (Zn - Cu)
              </h4>
              <p className="text-xs text-slate-500">
                Bandingkan potensial teoritis (E° = 1,10 V) dengan nilai eksperimen yang diperoleh.
              </p>
            </div>
          </div>
          <span className="px-2.5 py-1 bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-lg text-xs font-semibold">
            E° Teoritis: 1,10 V
          </span>
        </div>

        {/* Formula Box */}
        <div className="p-4 bg-slate-900 text-white rounded-xl space-y-2">
          <div className="flex items-center gap-2 text-amber-300 font-bold text-xs">
            <Calculator className="w-4 h-4" />
            <span>Rumus Perhitungan Galat Persen:</span>
          </div>
          <div className="p-3 bg-slate-950 rounded-lg text-center font-mono text-xs sm:text-sm text-amber-200 border border-slate-800">
            % Galat = [ | E° teoritis - E° eksperimen | / E° teoritis ] × 100%
          </div>
        </div>

        {/* Interactive Calculation Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs items-center">
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1.5">
            <label className="font-semibold text-slate-700 block">
              E° Teoritis Zn-Cu:
            </label>
            <input
              type="text"
              readOnly
              value="1.10 Volt"
              className="w-full p-2 bg-slate-200 border border-slate-300 rounded-lg font-mono font-bold text-slate-800"
            />
            <span className="text-[10px] text-slate-500 block">
              E° = E°(Cu²⁺/Cu) - E°(Zn²⁺/Zn) = 0.34 - (-0.76) = 1.10 V
            </span>
          </div>

          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1.5">
            <label className="font-semibold text-slate-700 block">
              E° Eksperimen Terukur (Volt):
            </label>
            <input
              type="number"
              step="0.01"
              value={expVoltInput}
              onChange={(e) => setExpVoltInput(e.target.value)}
              className="w-full p-2 bg-white border border-indigo-300 rounded-lg font-mono font-bold text-indigo-950 focus:ring-2 focus:ring-indigo-500"
              placeholder="Contoh: 1.08"
            />
            <span className="text-[10px] text-slate-500 block">
              Masukkan hasil pembacaan voltmeter digital kalian
            </span>
          </div>

          <div className="bg-indigo-50 border border-indigo-200 p-3.5 rounded-xl text-center space-y-1">
            <span className="text-[11px] font-semibold text-indigo-900 block">
              Hasil Perhitungan % Galat:
            </span>
            <span className="text-2xl font-black font-mono text-indigo-950 block">
              {calculatedErrorPercent}%
            </span>
            <span className="text-[10px] text-indigo-700 block">
              | 1.10 - {expVoltInput || '0'} | / 1.10 × 100%
            </span>
          </div>
        </div>

        {/* Error Factor Analysis Question */}
        <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs space-y-2">
          <label className="block font-semibold text-slate-700">
            Analisis Galat: Mengapa hasil eksperimen laboratorium seringkali sedikit lebih rendah (misal 1,08 V) dibandingkan nilai potensial standar teoritis 1,10 V?
          </label>
          <textarea
            rows={2}
            placeholder="Jelaskan pengaruh hambatan dalam (internal resistance) larutan/jembatan garam, konsentrasi yang tidak tepat 1 M standar, lapisan oksida pada elektroda, atau suhu lingkungan..."
            value={answers.error_analysis || ''}
            onChange={(e) => onAnswerChange('error_analysis', e.target.value)}
            className="w-full p-2.5 border rounded-lg bg-white text-xs leading-relaxed"
          />
        </div>
      </div>

      {/* 2. Menuliskan Notasi Sel Lengkap Tiap Kombinasi Logam */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
              <FileCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-slate-800 text-sm">
                2. Menuliskan Notasi Sel Lengkap Tiap Pasangan Logam
              </h4>
              <p className="text-xs text-slate-500">
                Format baku notasi sel: <strong>Anoda | Ion Anoda (aq) || Ion Katoda (aq) | Katoda</strong>
              </p>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-100 border-b border-slate-200 text-slate-700 font-bold">
                <th className="p-2.5">No</th>
                <th className="p-2.5">Pasangan Logam</th>
                <th className="p-2.5">E° Teoritis</th>
                <th className="p-2.5">Tuliskan Notasi Sel Volta Lengkap</th>
                <th className="p-2.5">Kunci / Petunjuk</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {notationList.map((item, idx) => {
                const userVal = answers[item.id] || '';
                const isMatched =
                  userVal.replace(/\s+/g, '') === item.correctNotation.replace(/\s+/g, '');
                return (
                  <tr key={item.id} className="hover:bg-slate-50">
                    <td className="p-2.5 font-bold text-slate-500">{idx + 1}</td>
                    <td className="p-2.5 font-semibold text-slate-800">{item.pair}</td>
                    <td className="p-2.5 font-mono font-bold text-indigo-700">
                      +{item.e0Teoritis.toFixed(2)} V
                    </td>
                    <td className="p-2.5">
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          placeholder={item.sampleHint}
                          value={userVal}
                          onChange={(e) => onAnswerChange(item.id, e.target.value)}
                          className="w-full p-2 border rounded-lg bg-white font-mono text-xs focus:ring-2 focus:ring-emerald-500"
                        />
                        {userVal && isMatched && (
                          <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                        )}
                      </div>
                    </td>
                    <td className="p-2.5 text-[11px] font-mono text-slate-500">
                      <code>{item.correctNotation}</code>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* 3. Mengurutkan Logam Berdasarkan Daya Desak Reduksinya (Deret Volta) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-100 text-amber-800 rounded-xl">
              <ArrowUpDown className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-slate-800 text-sm">
                3. Mengurutkan Logam Berdasarkan Daya Desak Reduksinya (Deret Volta)
              </h4>
              <p className="text-xs text-slate-500">
                Susun 5 logam yang diselidiki (Mg, Al, Zn, Fe, Cu) dari yang memiliki <strong>daya pereduksi paling kuat</strong> (paling mudah melepaskan elektron / E° paling negatif) hingga paling lemah.
              </p>
            </div>
          </div>

          <button
            onClick={verifyVoltaOrder}
            className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold transition shadow-xs flex items-center gap-1.5"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Periksa Urutan</span>
          </button>
        </div>

        {/* Interactive Reordering Blocks */}
        <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
          <div className="flex justify-between text-[11px] font-bold text-slate-600">
            <span>Daya Desak Kuat (E° Paling Negatif)</span>
            <span>Daya Desak Lemah (E° Paling Positif)</span>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2">
            {currentOrder.map((metal, idx) => (
              <div key={metal} className="flex items-center gap-1">
                <div className="flex flex-col items-center bg-white border border-slate-300 rounded-xl p-2.5 shadow-sm min-w-[75px]">
                  <span className="text-[10px] text-slate-400 font-bold">Posisi {idx + 1}</span>
                  <span className="text-base font-black text-indigo-900 my-0.5">{metal}</span>
                  <div className="flex items-center gap-1 mt-1">
                    <button
                      disabled={idx === 0}
                      onClick={() => moveItem(idx, 'left')}
                      className="px-1.5 py-0.5 bg-slate-100 hover:bg-slate-200 rounded text-[10px] disabled:opacity-30"
                      title="Geser ke kiri"
                    >
                      ◀
                    </button>
                    <button
                      disabled={idx === currentOrder.length - 1}
                      onClick={() => moveItem(idx, 'right')}
                      className="px-1.5 py-0.5 bg-slate-100 hover:bg-slate-200 rounded text-[10px] disabled:opacity-30"
                      title="Geser ke kanan"
                    >
                      ▶
                    </button>
                  </div>
                </div>
                {idx < currentOrder.length - 1 && (
                  <span className="font-bold text-slate-400 text-lg px-1">&gt;</span>
                )}
              </div>
            ))}
          </div>

          {/* Verification Feedback Banner */}
          {orderChecked && (
            <div
              className={`p-3 rounded-xl border text-xs flex items-start gap-2.5 animate-in fade-in ${
                isOrderCorrect
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                  : 'bg-rose-50 border-rose-300 text-rose-900'
              }`}
            >
              {isOrderCorrect ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              )}
              <div>
                <strong className="block font-bold">
                  {isOrderCorrect
                    ? 'Benar Sekali! Urutan Deret Volta Tepat.'
                    : 'Urutan Belum Tepat. Silakan tinjau kembali nilai E° tiap logam.'}
                </strong>
                <span className="text-[11px] block mt-0.5">
                  {isOrderCorrect
                    ? 'Mg (E° = -2,37 V) > Al (E° = -1,66 V) > Zn (E° = -0,76 V) > Fe (E° = -0,44 V) > Cu (E° = +0,34 V). Logam di sebelah kiri mampu mendesak / mereduksi ion logam di sebelah kanannya dari larutan!'
                    : 'Ingat aturan: Logam dengan E° semakin negatif memiliki daya pereduksi semakin kuat dan terletak di sebelah kiri!'}
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
