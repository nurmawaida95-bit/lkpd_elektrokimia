import React from 'react';
import {
  GraduationCap,
  Users,
  Clock,
  Radio,
  FileSpreadsheet,
  Share2,
  Bell,
  AlertTriangle,
  Sparkles,
} from 'lucide-react';
import type { LKPDConfig } from '../types.js';

interface NavbarProps {
  currentView: 'student' | 'teacher';
  onSwitchView: (view: 'student' | 'teacher') => void;
  lkpdConfig: LKPDConfig;
  isRealtimeConnected: boolean;
  submissionCount: number;
  overdueCount: number;
  onExportExcel: () => void;
  onOpenShareModal: () => void;
  onTriggerReminder: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onSwitchView,
  lkpdConfig,
  isRealtimeConnected,
  submissionCount,
  overdueCount,
  onExportExcel,
  onOpenShareModal,
  onTriggerReminder,
}) => {
  const isDeadlinePassed = Boolean(
    lkpdConfig.deadline && new Date().toISOString() > lkpdConfig.deadline
  );

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-40 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-3">
        {/* Logo & App Title */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white font-bold shadow-md ring-2 ring-indigo-400/30">
            <Sparkles className="w-5 h-5 text-amber-300" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-bold tracking-tight text-white">
                LKPD Sel Volta &amp; Dashboard Guru
              </h1>
              <span className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-semibold bg-indigo-950 text-indigo-300 border border-indigo-700/50 rounded-full">
                PBL Kimia XII
              </span>
            </div>
            <div className="flex items-center gap-3 text-xs text-slate-400">
              <span className="flex items-center gap-1">
                <Radio
                  className={`w-3.5 h-3.5 ${
                    isRealtimeConnected
                      ? 'text-emerald-400 animate-pulse'
                      : 'text-amber-400'
                  }`}
                />
                <span className="text-[11px]">
                  {isRealtimeConnected ? 'Sinkron Real-Time' : 'Menghubungkan...'}
                </span>
              </span>
              <span className="hidden md:inline text-slate-600">•</span>
              <span className="hidden md:flex items-center gap-1 text-[11px]">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                Tenggat:{' '}
                <span
                  className={
                    isDeadlinePassed ? 'text-rose-400 font-semibold' : 'text-slate-300'
                  }
                >
                  {lkpdConfig.deadline
                    ? new Date(lkpdConfig.deadline).toLocaleString('id-ID', {
                        day: 'numeric',
                        month: 'short',
                        hour: '2-digit',
                        minute: '2-digit',
                      })
                    : '-'}
                </span>
              </span>
            </div>
          </div>
        </div>

        {/* Center Mode Switcher Tabs */}
        <div className="flex items-center bg-slate-950/80 p-1 rounded-xl border border-slate-800 shadow-inner">
          <button
            id="btnNavModeStudent"
            onClick={() => onSwitchView('student')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 ${
              currentView === 'student'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <GraduationCap className="w-4 h-4" />
            <span>Mode Siswa (LKPD)</span>
          </button>
          <button
            id="btnNavModeTeacher"
            onClick={() => onSwitchView('teacher')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 relative ${
              currentView === 'teacher'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Dashboard Guru</span>
            {submissionCount > 0 && (
              <span className="px-1.5 py-0.2 bg-amber-400 text-slate-950 font-bold rounded-full text-[10px]">
                {submissionCount}
              </span>
            )}
          </button>
        </div>

        {/* Right Tools Action Buttons */}
        <div className="flex items-center gap-2">
          {overdueCount > 0 && (
            <button
              onClick={onTriggerReminder}
              title={`${overdueCount} kelompok belum menyelesaikan tugas`}
              className="px-2.5 py-1.5 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 rounded-lg text-xs font-medium transition flex items-center gap-1.5"
            >
              <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
              <span className="hidden sm:inline">{overdueCount} Terlambat</span>
              <Bell className="w-3 h-3 text-rose-400" />
            </button>
          )}

          <button
            onClick={onOpenShareModal}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-medium transition flex items-center gap-1.5 shadow-sm"
          >
            <Share2 className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Bagikan Link</span>
          </button>

          <button
            onClick={onExportExcel}
            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-lg text-xs transition flex items-center gap-1.5 shadow-sm"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Unduh Excel</span>
          </button>
        </div>
      </div>
    </header>
  );
};
