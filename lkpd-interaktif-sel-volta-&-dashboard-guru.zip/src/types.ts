export interface LKPDConfig {
  id: string;
  title: string;
  subject: string;
  topic: string;
  timeAllocation: string;
  deadline: string; // ISO date string
  instructions: string[];
  historicalContext: {
    title: string;
    galvaniStory: string;
    voltaStory: string;
    controversyProblem: string;
    guidingQuestions: string[];
  };
  case1?: {
    title: string;
    description: string;
    hint: string;
  };
  case2?: {
    title: string;
    description: string;
    hint: string;
  };
  saltBridgeGuide: {
    title: string;
    materials: string[];
    steps: { stepNumber: number; title: string; instruction: string; keyTip: string }[];
  };
  cellNotationTasks: {
    id: string;
    anode: string;
    cathode: string;
    e0Theoretical: number;
    expectedNotation: string;
  }[];
  voltaOrderTask: {
    metals: string[];
    expectedOrder: string[];
    explanation: string;
  };
  scaffoldingQuestions: {
    id: string;
    phase: string;
    question: string;
    expectedAnswerKey?: string;
  }[];
  solutionQuestions: {
    id: string;
    caseRef: number;
    title: string;
    question: string;
    expectedAnswerKey?: string;
  }[];
  hotsQuestion: {
    context: string;
    partA: { label: string; question: string; expectedAnswerKey?: string };
    partB: { label: string; question: string; expectedAnswerKey?: string };
    partC?: { label: string; question: string; expectedAnswerKey?: string };
  };
  rubricCriteria: {
    id: string;
    phase: string;
    name: string;
    maxScore: number;
    description: string;
  }[];
  targetGroups: {
    id: string;
    name: string;
    classGrade: string;
    leader: string;
  }[];
}

export interface StudentSubmission {
  id: string;
  groupName: string;
  classGrade: string;
  members: string[];
  answers: {
    // Fase 1 & 2: Masalah & Hipotesis
    prob_galvani_volta?: string;
    hypo_galvani_volta?: string;
    prob1?: string;
    prob2?: string;
    hypo1?: string;
    hypo2?: string;
    // Fase 2 TCK: Jembatan Garam & Aliran Elektron
    tck_electron_flow?: string;
    tck_salt_bridge_role?: string;
    // Fase 3: Penyelidikan Sel Daniell, Agar KCl & Voltmeter
    scaff1_1?: string; // Anode oxidation metal
    scaff1_2?: string; // Electron direction
    scaff1_3?: string; // Salt bridge & notation
    scaff2_1?: string; // Positive E0 tendency
    scaff2_2?: string; // Negative E0 tendency
    salt_bridge_understanding?: string;
    exp_zn_cu_volt?: string;
    exp_mg_cu_volt?: string;
    exp_al_cu_volt?: string;
    exp_fe_cu_volt?: string;
    exp_zn_fe_volt?: string;
    // Fase 4: Solusi, Galat Persen, Notasi Sel & Deret Volta
    percent_error_zn_cu?: string;
    error_analysis?: string;
    solCase1?: string;
    case2_fe_e0?: string;
    case2_cu_e0?: string;
    case2_recommendation?: string;
    notation_zn_cu?: string;
    notation_mg_cu?: string;
    notation_al_cu?: string;
    notation_fe_cu?: string;
    notation_zn_fe?: string;
    volta_series_order?: string;
    // Fase 5: Evaluasi HOTS & Refleksi
    hots_1?: string;
    hots_a?: string;
    hots_b?: string;
    hots_3_corrosion?: string;
    reflection?: string;
    [key: string]: string | undefined;
  };
  submittedAt: string | null;
  lastUpdatedAt: string;
  status: 'draft' | 'submitted' | 'late' | 'graded';
  isOverdue: boolean;
  scoreBreakdown: {
    fase2: number;
    fase3: number;
    fase4: number;
    fase5: number;
  };
  totalScore: number | null;
  teacherFeedback: string;
  gradedAt: string | null;
}

export interface ReminderLog {
  id: string;
  sentAt: string;
  targetCount: number;
  targetGroupNames: string[];
  message: string;
}

export interface RealtimeMessage {
  type: 'connected' | 'lkpd_updated' | 'submission_saved' | 'submission_graded' | 'submission_deleted' | 'reminder_sent' | 'deadline_check';
  payload?: any;
  timestamp: string;
}
