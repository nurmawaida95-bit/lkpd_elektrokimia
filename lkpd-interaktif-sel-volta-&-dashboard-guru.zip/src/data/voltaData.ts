export interface RedoxCouple {
  metal: string;
  name: string;
  ion: string;
  reaction: string;
  e0: number; // in Volts
  standardColor: string;
}

export const voltaSeries: string[] = [
  'Li', 'K', 'Ba', 'Ca', 'Na', 'Mg', 'Al', 'Mn', 'Zn', 'Cr', 'Fe', 'Ni', 'Sn', 'Pb', '(H)', 'Cu', 'Hg', 'Ag', 'Pt', 'Au'
];

export const e0Data: RedoxCouple[] = [
  { metal: 'Li', name: 'Litium', ion: 'Li⁺', reaction: 'Li⁺(aq) + e⁻ → Li(s)', e0: -3.04, standardColor: '#fca5a5' },
  { metal: 'K', name: 'Kalium', ion: 'K⁺', reaction: 'K⁺(aq) + e⁻ → K(s)', e0: -2.92, standardColor: '#f87171' },
  { metal: 'Ba', name: 'Barium', ion: 'Ba²⁺', reaction: 'Ba²⁺(aq) + 2e⁻ → Ba(s)', e0: -2.90, standardColor: '#fb923c' },
  { metal: 'Ca', name: 'Kalsium', ion: 'Ca²⁺', reaction: 'Ca²⁺(aq) + 2e⁻ → Ca(s)', e0: -2.87, standardColor: '#f97316' },
  { metal: 'Na', name: 'Natrium', ion: 'Na⁺', reaction: 'Na⁺(aq) + e⁻ → Na(s)', e0: -2.71, standardColor: '#fdba74' },
  { metal: 'Mg', name: 'Magnesium', ion: 'Mg²⁺', reaction: 'Mg²⁺(aq) + 2e⁻ → Mg(s)', e0: -2.37, standardColor: '#facc15' },
  { metal: 'Al', name: 'Aluminium', ion: 'Al³⁺', reaction: 'Al³⁺(aq) + 3e⁻ → Al(s)', e0: -1.66, standardColor: '#eab308' },
  { metal: 'Zn', name: 'Seng', ion: 'Zn²⁺', reaction: 'Zn²⁺(aq) + 2e⁻ → Zn(s)', e0: -0.76, standardColor: '#94a3b8' },
  { metal: 'Cr', name: 'Kromium', ion: 'Cr³⁺', reaction: 'Cr³⁺(aq) + 3e⁻ → Cr(s)', e0: -0.74, standardColor: '#a1a1aa' },
  { metal: 'Fe', name: 'Besi', ion: 'Fe²⁺', reaction: 'Fe²⁺(aq) + 2e⁻ → Fe(s)', e0: -0.44, standardColor: '#64748b' },
  { metal: 'Ni', name: 'Nikel', ion: 'Ni²⁺', reaction: 'Ni²⁺(aq) + 2e⁻ → Ni(s)', e0: -0.25, standardColor: '#71717a' },
  { metal: 'Sn', name: 'Timah', ion: 'Sn²⁺', reaction: 'Sn²⁺(aq) + 2e⁻ → Sn(s)', e0: -0.14, standardColor: '#9ca3af' },
  { metal: 'Pb', name: 'Timbal', ion: 'Pb²⁺', reaction: 'Pb²⁺(aq) + 2e⁻ → Pb(s)', e0: -0.13, standardColor: '#475569' },
  { metal: '(H)', name: 'Hidrogen (Standar)', ion: 'H⁺', reaction: '2H⁺(aq) + 2e⁻ → H₂(g)', e0: 0.00, standardColor: '#a855f7' },
  { metal: 'Cu', name: 'Tembaga', ion: 'Cu²⁺', reaction: 'Cu²⁺(aq) + 2e⁻ → Cu(s)', e0: +0.34, standardColor: '#b45309' },
  { metal: 'Ag', name: 'Perak', ion: 'Ag⁺', reaction: 'Ag⁺(aq) + e⁻ → Ag(s)', e0: +0.80, standardColor: '#cbd5e1' },
  { metal: 'Pt', name: 'Platina', ion: 'Pt²⁺', reaction: 'Pt²⁺(aq) + 2e⁻ → Pt(s)', e0: +1.20, standardColor: '#94a3b8' },
  { metal: 'Au', name: 'Emas', ion: 'Au³⁺', reaction: 'Au³⁺(aq) + 3e⁻ → Au(s)', e0: +1.50, standardColor: '#eab308' },
];

export function getE0(metalSymbol: string): number {
  const found = e0Data.find((d) => d.metal.toLowerCase() === metalSymbol.toLowerCase());
  return found ? found.e0 : 0;
}

export function calculateCellPotential(anode: string, cathode: string): {
  eAnode: number;
  eCathode: number;
  eCell: number;
  isSpontaneous: boolean;
  cellNotation: string;
} {
  const eAnode = getE0(anode);
  const eCathode = getE0(cathode);
  const eCell = Number((eCathode - eAnode).toFixed(2));
  const isSpontaneous = eCell > 0;
  const cellNotation = `${anode} | ${anode}²⁺ || ${cathode}²⁺ | ${cathode}`;

  return { eAnode, eCathode, eCell, isSpontaneous, cellNotation };
}

export function checkSpontaneity(solidMetal: string, solutionIon: string): {
  eSolid: number;
  eIon: number;
  eCell: number;
  isSpontaneous: boolean;
  statusText: string;
} {
  const eSolid = getE0(solidMetal);
  const eIon = getE0(solutionIon);
  const eCell = Number((eIon - eSolid).toFixed(2));

  if (solidMetal.toLowerCase() === solutionIon.toLowerCase()) {
    return {
      eSolid,
      eIon,
      eCell: 0,
      isSpontaneous: false,
      statusText: 'Setimbang (Tidak bereaksi lebih lanjut)',
    };
  }

  const isSpontaneous = eCell > 0;
  return {
    eSolid,
    eIon,
    eCell,
    isSpontaneous,
    statusText: isSpontaneous
      ? 'SPONTAN (Reaksi Berlangsung & Logam Terkorosi)'
      : 'TIDAK SPONTAN (Aman / Logam Tidak Terkorosi)',
  };
}
