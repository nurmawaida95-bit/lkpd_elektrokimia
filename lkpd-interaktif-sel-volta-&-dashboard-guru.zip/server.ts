import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import type { LKPDConfig, StudentSubmission, ReminderLog, RealtimeMessage } from './src/types.js';

const PORT = 3000;
const app = express();

app.use(express.json());

// Set default deadline 24 hours from now
const defaultDeadline = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().slice(0, 16);

// Initial LKPD Configuration
let currentLKPD: LKPDConfig = {
  id: 'lkpd-sel-volta-pbl-01',
  title: 'LKPD Interaktif: Sel Volta, Kontroversi Galvani-Volta & Sel Daniell',
  subject: 'Kimia SMA / SMK Kelas XII',
  topic: 'Elektrokimia - Sel Volta, Aliran Elektron, Jembatan Garam & Deret Volta (PBL)',
  timeAllocation: '2 x 45 Menit',
  deadline: defaultDeadline,
  instructions: [
    'Bacalah wacana kontroversi sejarah Luigi Galvani vs Alessandro Volta dengan seksama.',
    'Bekerjasamalah secara aktif dalam kelompok untuk merumuskan masalah dan hipotesis saintifik.',
    'Gunakan visualisasi TCK aliran elektron dan simulasi transfer ion di jembatan garam.',
    'Lakukan penyelidikan laboratorium perakitan Sel Daniell, pembuatan jembatan garam agar KCl, dan penggunaan voltmeter digital.',
    'Hitung galat persen (% error), tuliskan notasi sel lengkap, susun deret Volta, dan selesaikan evaluasi HOTS.',
    'Kirimkan jawaban sebelum batas waktu berakhir agar tersinkronisasi langsung ke Dashboard Guru.',
  ],
  historicalContext: {
    title: 'Orientasi Masalah Sejarah: Kontroversi Listrik Katak Galvani vs Tumpukan Logam Volta',
    galvaniStory: 'Pada tahun 1780, Luigi Galvani (ahli anatomi Italia) mengamati fenomena mengejutkan: otot kaki katak yang telah dikuliti berkedut kuat saat saraf kakinya disentuh skalpel logam di dekat mesin elektrostatik. Galvani juga mengamati bahwa ketika kaki katak digantung dengan kait tembaga pada pagar besi teralis, otot kaki katak berkedut setiap kali menyentuh besi. Galvani menyimpulkan bahwa jaringan otot dan saraf hewan menyimpan cairan listrik alami yang ia namakan "Listrik Hewani" (Animal Electricity).',
    voltaStory: 'Alessandro Volta (ahli fisika Italia, 1791) meragukan hipotesis listrik hewani Galvani. Volta menduga otot katak yang basah hanya bertindak sebagai larutan elektrolit / sensor peka, sedangkan sumber listrik sesungguhnya berasal dari kontak antara dua logam yang berbeda jenis (tembaga dan besi). Untuk membuktikan teorinya, pada tahun 1800 Volta membuat "Tumpukan Volta" (Voltaic Pile) dari cakram seng (Zn) dan tembaga/perak (Cu/Ag) yang diselingi kain dibasahi air garam (tanpa bagian hewan sama sekali!), dan berhasil menghasilkan arus listrik kontinu pertama di dunia!',
    controversyProblem: 'Mengapa otot kaki katak berkedut saat tersentuh dua logam berbeda (besi & tembaga)? Apakah listrik berasal dari hewan (Galvani) atau dari kontak dua logam berbeda melalui larutan elektrolit (Volta)?',
    guidingQuestions: [
      'Mengapa otot kaki katak hanya berkedut saat tersentuh dua logam yang berbeda (kait tembaga dan pagar besi), tetapi tidak berkedut jika menggunakan dua logam sejenis?',
      'Apakah listrik tersebut benar-benar berasal dari cairan hewan (Galvani) atau dari kontak dua logam berbeda melalui konduktor elektrolit (Volta)?',
      'Bagaimana penemuan tumpukan Volta mengilhami rancangan Sel Volta modern seperti Sel Daniell (Zn-Cu)?',
    ],
  },
  case1: {
    title: 'Kasus 1: Replikasi Baterai Volta & Baterai Buah Lemon',
    description: 'Saat listrik padam, tim relawan menyalakan lampu LED darurat dengan menancapkan lempeng seng (Zn) dan tembaga (Cu) pada buah lemon yang mengandung asam sitrat. Mengapa kombinasi dua logam berbeda ini dapat menghasilkan arus listrik? Mengapa jika kedua elektroda menggunakan logam seng (Zn) yang sama, lampu LED justru tidak menyala sama sekali?',
    hint: 'Hubungkan dengan perbedaan potensial reduksi standar (E°), kecenderungan pelepasan elektron (oksidasi), dan beda potensial gaya gerak listrik.',
  },
  case2: {
    title: 'Kasus 2: Pemilihan Bahan Tangki Penyimpan Larutan Seng Sulfat (ZnSO₄)',
    description: 'Sebuah pabrik kimia perlu menyimpan larutan seng sulfat (ZnSO₄). Tersedia dua opsi bahan tangki: Tembaga (Cu) atau Besi (Fe). Jika terjadi reaksi redoks spontan antara logam tangki dan ion seng di larutan, dinding tangki akan mengalami korosi hebat dan bocor. Bahan manakah yang paling aman dipilih pabrik?',
    hint: 'Gunakan aturan deret Volta dan nilai E°sel = E°katoda - E°anoda. Reaksi berlangsung spontan jika E°sel > 0.',
  },
  saltBridgeGuide: {
    title: 'Panduan Laboratorium: Pembuatan Jembatan Garam Agar-Agar KCl',
    materials: [
      'Bubuk agar-agar murni (plain) 3-5 gram',
      'Kalium klorida (KCl) padat 15 gram (atau 100 mL larutan KCl 1 M)',
      'Akuades / air suling 100 mL',
      'Pipa kaca bentuk U (diameter 1-1,5 cm) atau selang plastik transparan',
      'Gelas kimia 250 mL, hotplate, batang pengaduk, dan kapas',
    ],
    steps: [
      {
        stepNumber: 1,
        title: 'Penimbangan & Pelarutan',
        instruction: 'Timbang 3–5 gram bubuk agar-agar tanpa rasa dan 15 gram KCl. Larutkan ke dalam 100 mL akuades dalam gelas kimia 250 mL.',
        keyTip: 'KCl dipilih karena ion K⁺ dan Cl⁻ memiliki mobilitas ionik yang hampir setara sehingga meminimalkan potensial batas cairan (liquid junction potential).',
      },
      {
        stepNumber: 2,
        title: 'Pemanasan Homogen',
        instruction: 'Panaskan campuran di atas hotplate sambil diaduk konstan hingga mendidih perlahan dan larutan berubah menjadi jernih transparan.',
        keyTip: 'Aduk secara merata agar agar-agar tidak gosong di dasar gelas kimia.',
      },
      {
        stepNumber: 3,
        title: 'Pengisian Pipa U Bebas Gelembung',
        instruction: 'Tuangkan larutan agar-agar KCl panas ke dalam pipa U kaca secara perlahan dan hati-hati hingga terisi penuh.',
        keyTip: 'Pastikan TIDAK ADA gelembung udara di dalam pipa U. Gelembung udara akan memutuskan jembatan ion dan membuat tegangan sel jatuh ke 0 V!',
      },
      {
        stepNumber: 4,
        title: 'Pendinginan & Gelasi',
        instruction: 'Sumbat kedua ujung dengan kapas steril, lalu dinginkan pipa U pada suhu ruang atau rendam di air es hingga memadat menjadi gel kenyal.',
        keyTip: 'Gel agar-agar menjaga ion tetap leluasa bermigrasi sekaligus mencegah larutan anoda dan katoda bercampur secara fisik.',
      },
      {
        stepNumber: 5,
        title: 'Pemasangan ke Rangkaian Sel',
        instruction: 'Celupkan salah satu ujung pipa U ke gelas kimia anoda (ZnSO₄) dan ujung lainnya ke katoda (CuSO₄). Rangkaian siap beroperasi.',
        keyTip: 'Simpan jembatan garam dalam larutan KCl pekat saat tidak dipakai agar tidak mengering.',
      },
    ],
  },
  cellNotationTasks: [
    { id: 'notation_zn_cu', anode: 'Zn', cathode: 'Cu', e0Theoretical: 1.10, expectedNotation: 'Zn | Zn²⁺ || Cu²⁺ | Cu' },
    { id: 'notation_mg_cu', anode: 'Mg', cathode: 'Cu', e0Theoretical: 2.71, expectedNotation: 'Mg | Mg²⁺ || Cu²⁺ | Cu' },
    { id: 'notation_al_cu', anode: 'Al', cathode: 'Cu', e0Theoretical: 2.00, expectedNotation: 'Al | Al³⁺ || Cu²⁺ | Cu' },
    { id: 'notation_fe_cu', anode: 'Fe', cathode: 'Cu', e0Theoretical: 0.78, expectedNotation: 'Fe | Fe²⁺ || Cu²⁺ | Cu' },
    { id: 'notation_zn_fe', anode: 'Zn', cathode: 'Fe', e0Theoretical: 0.32, expectedNotation: 'Zn | Zn²⁺ || Fe²⁺ | Fe' },
  ],
  voltaOrderTask: {
    metals: ['Mg', 'Al', 'Zn', 'Fe', 'Cu'],
    expectedOrder: ['Mg', 'Al', 'Zn', 'Fe', 'Cu'],
    explanation: 'Semakin ke kiri (Mg), E° semakin negatif (-2.37 V) sehingga daya desak reduksi semakin kuat (paling mudah teroksidasi). Semakin ke kanan (Cu), E° semakin positif (+0.34 V) sehingga daya pengoksidasi semakin kuat (paling mudah tereduksi).',
  },
  scaffoldingQuestions: [
    {
      id: 'scaff1_1',
      phase: 'Fase 3 - Kegiatan 1',
      question: 'Pada pasangan elektroda Zn dan Cu, logam manakah yang bertindak sebagai Anoda (mengalami oksidasi)? Berikan alasan berdasarkan nilai E°!',
      expectedAnswerKey: 'Zn (Seng) bertindak sebagai Anoda karena memiliki E° lebih negatif (-0.76 V) dibandingkan Cu (+0.34 V), sehingga lebih mudah mengalami oksidasi.',
    },
    {
      id: 'scaff1_2',
      phase: 'Fase 3 - Kegiatan 1',
      question: 'Jelaskan arah aliran elektron pada kawat penghantar luar rangkaian Sel Volta Zn-Cu!',
      expectedAnswerKey: 'Elektron mengalir dari Anoda seng (Zn) menuju Katoda tembaga (Cu) melalui kawat penghantar.',
    },
    {
      id: 'scaff1_3',
      phase: 'Fase 3 - Kegiatan 1',
      question: 'Apakah fungsi jembatan garam pada rangkaian Sel Volta? Dan bagaimana notasi sel untuk pasangan Zn-Cu?',
      expectedAnswerKey: 'Fungsi jembatan garam adalah menetralkan kelebihan muatan ionik pada kedua kompartemen setengah sel dan melengkapi sirkuit listrik. Notasi sel: Zn | Zn²⁺ || Cu²⁺ | Cu.',
    },
    {
      id: 'scaff2_1',
      phase: 'Fase 3 - Kegiatan 2',
      question: 'Berdasarkan data grafik E°, logam dengan nilai E° semakin POSITIF cenderung mengalami reaksi apa?',
      expectedAnswerKey: 'Cenderung mengalami reaksi reduksi (menangkap elektron / bertindak sebagai oksidator lebih kuat).',
    },
    {
      id: 'scaff2_2',
      phase: 'Fase 3 - Kegiatan 2',
      question: 'Sebaliknya, logam dengan nilai E° semakin NEGATIF cenderung mengalami reaksi apa?',
      expectedAnswerKey: 'Cenderung mengalami reaksi oksidasi (melepaskan elektron / bertindak sebagai reduktor lebih kuat).',
    },
  ],
  solutionQuestions: [
    {
      id: 'solCase1',
      caseRef: 1,
      title: 'Pemecahan Masalah Kasus 1 (Baterai Lemon & Tumpukan Volta)',
      question: 'Jelaskan mengapa pasangan Zn-Cu menghasilkan tegangan listrik, sedangkan pasangan Zn-Zn menghasilkan tegangan 0 V!',
      expectedAnswerKey: 'Pasangan Zn-Cu memiliki beda potensial (E°sel = +0.34 - (-0.76) = +1.10 V) sehingga terjadi perpindahan elektron spontan dari Zn ke Cu dengan sari lemon sebagai larutan elektrolit asam (ion H⁺). Pada pasangan Zn-Zn, beda potensialnya nol (E°sel = -0.76 - (-0.76) = 0 V), tidak ada gaya dorong listrik sehingga tidak timbul arus.',
    },
    {
      id: 'case2_recommendation',
      caseRef: 2,
      title: 'Pemecahan Masalah Kasus 2 (Bahan Tangki ZnSO₄)',
      question: 'Berdasarkan perhitungan E°sel untuk Fe + Zn²⁺ dan Cu + Zn²⁺, logam manakah yang aman digunakan sebagai bahan tangki penyimpan larutan ZnSO₄?',
      expectedAnswerKey: 'Logam Tembaga (Cu) aman digunakan. Nilai E°sel reaksi Cu + Zn²⁺ -> Cu²⁺ + Zn adalah -0.76 - (+0.34) = -1.10 V (< 0 / Tidak Spontan), sehingga Cu tidak akan bereaksi dengan larutan ZnSO₄. Besi (Fe) juga tidak bereaksi secara spontan dengan Zn²⁺ (E°sel = -0.76 - (-0.44) = -0.32 V), tetapi Tembaga (Cu) jauh lebih mulia dan tahan terhadap kelembaban asam.',
    },
  ],
  hotsQuestion: {
    context: 'Diketahui data potensial sel dari percobaan Volta:\\n(1) A | A²⁺ || B²⁺ | B   E° = +1.10 V\\n(2) C | C²⁺ || B²⁺ | B   E° = +0.46 V\\n(3) A | A²⁺ || D²⁺ | D   E° = +2.12 V',
    partA: {
      label: 'a. Urutan Daya Pereduksi',
      question: 'Tentukan urutan bertambahnya daya pereduksi (dari reduktor terlemah ke reduktor terkuat)!',
      expectedAnswerKey: 'D < B < C < A (atau dari reduktor terlemah: D, B, C, A). Logam A memiliki daya pereduksi paling kuat.',
    },
    partB: {
      label: 'b. Hitung E°sel Reaksi C | C²⁺ || D²⁺ | D',
      question: 'Hitunglah nilai potensial sel standar (E°sel) untuk reaksi C | C²⁺ || D²⁺ | D!',
      expectedAnswerKey: 'E°sel (C || D) = E°(A||D) - E°(A||C). Karena E°(A||B) = 1.10 V dan E°(C||B) = 0.46 V, maka E°(A||C) = 1.10 - 0.46 = 0.64 V. Sehingga E°(C||D) = 2.12 - 0.64 = +1.48 V.',
    },
    partC: {
      label: 'c. Analisis Proteksi Katodik (Anoda Korban)',
      question: 'Pipa baja (Fe, E° = -0.44 V) bawah tanah dilindungi dari karat menggunakan metode anoda korban. Antara logam Magnesium (Mg, E° = -2.37 V) dan Tembaga (Cu, E° = +0.34 V), logam manakah yang harus dihubungkan ke pipa baja? Jelaskan alasannya berdasarkan arah transfer elektron!',
      expectedAnswerKey: 'Logam Magnesium (Mg) harus dipilih. Mg memiliki E° lebih negatif (-2.37 V) daripada Fe (-0.44 V), sehingga Mg bertindak sebagai anoda korban yang teroksidasi melepaskan elektron menuju pipa besi. Aliran elektron ini menjaga besi tetap dalam wujud tereduksi dan bebas dari karat. Jika tembaga (Cu) yang dipasang, pipa besi justru yang akan terkorosi jauh lebih cepat.',
    },
  },
  rubricCriteria: [
    { id: 'fase2', phase: 'Fase 2', name: 'Rumusan Masalah & Hipotesis', maxScore: 20, description: 'Ketepatan perumusan masalah saintifik kontroversi Galvani-Volta dan kesesuaian hipotesis awal.' },
    { id: 'fase3', phase: 'Fase 3', name: 'Penyelidikan Sel Daniell, Agar KCl & Voltmeter', maxScore: 30, description: 'Analisis simulasi aliran elektron, pemahaman pembuatan jembatan garam, dan ketepatan pengukuran voltmeter.' },
    { id: 'fase4', phase: 'Fase 4', name: 'Galat Persen, Notasi Sel & Deret Volta', maxScore: 30, description: 'Ketepatan perhitungan % galat (teoritis 1.10 V), kebenaran notasi sel 5 variasi logam, dan urutan deret Volta.' },
    { id: 'fase5', phase: 'Fase 5', name: 'Evaluasi HOTS & Refleksi Belajar', maxScore: 20, description: 'Kemampuan analisis tingkat tinggi pada sel volta hipotesis, proteksi katodik, dan refleksi metakognitif.' },
  ],
  targetGroups: [
    { id: 'grp-1', name: 'Kelompok 1 (Galvani)', classGrade: 'XII MIPA 1', leader: 'Farhan Maulana' },
    { id: 'grp-2', name: 'Kelompok 2 (Volta)', classGrade: 'XII MIPA 1', leader: 'Aisyah Putri' },
    { id: 'grp-3', name: 'Kelompok 3 (Nernst)', classGrade: 'XII MIPA 1', leader: 'Bagus Pratama' },
    { id: 'grp-4', name: 'Kelompok 4 (Faraday)', classGrade: 'XII MIPA 1', leader: 'Dewi Lestari' },
    { id: 'grp-5', name: 'Kelompok 5 (Arrhenius)', classGrade: 'XII MIPA 1', leader: 'Eko Ramadhan' },
    { id: 'grp-6', name: 'Kelompok 6 (Daniell)', classGrade: 'XII MIPA 1', leader: 'Fitri Handayani' },
  ],
};

// Initial realistic submissions for testing & immediate dashboard demonstration
let submissions: StudentSubmission[] = [
  {
    id: 'sub-001',
    groupName: 'Kelompok 1 (Galvani)',
    classGrade: 'XII MIPA 1',
    members: ['Farhan Maulana', 'Indah Permata', 'Gilang Saputra', 'Hana Zahra'],
    answers: {
      prob1: 'Mengapa lempeng Zn dan Cu yang ditancapkan pada lemon dapat menghasilkan arus listrik sedangkan lempeng yang sama tidak?',
      prob2: 'Bagaimana menentukan bahan logam tangki yang aman untuk menyimpan larutan ZnSO4 tanpa mengalami korosi?',
      hypo1: 'Arus listrik timbul karena perbedaan keelektronegatifan dan potensial reduksi antara logam seng dan tembaga.',
      hypo2: 'Bahan yang dipilih harus memiliki potensial reduksi yang lebih besar atau tidak bereaksi spontan dengan larutan ZnSO4.',
      scaff1_1: 'Zn (Seng), karena memiliki nilai E° lebih negatif (-0.76 V) dibandingkan Cu (+0.34 V).',
      scaff1_2: 'Elektron mengalir dari anoda seng (Zn) menuju katoda tembaga (Cu) melewati lampu LED.',
      scaff1_3: 'Jembatan garam berfungsi menetralkan akumulasi ion muatan di kedua kompartemen. Notasi sel: Zn | Zn²⁺ || Cu²⁺ | Cu.',
      scaff2_1: 'reduksi',
      scaff2_2: 'oksidasi',
      solCase1: 'Pasangan Zn-Cu menghasilkan tegangan E°sel = +0.34 - (-0.76) = +1.10 V (> 0, spontan), sehingga elektron mengalir dan lampu LED menyala. Pada pasangan Zn-Zn, potensial kedua elektroda sama sehingga beda potensial E°sel = 0 V dan tidak ada aliran elektron.',
      case2_fe_e0: 'Fe + Zn²⁺: E°sel = -0.76 - (-0.44) = -0.32 V (Tidak Spontan)',
      case2_cu_e0: 'Cu + Zn²⁺: E°sel = -0.76 - (+0.34) = -1.10 V (Tidak Spontan)',
      case2_recommendation: 'Pabrik kimia direkomendasikan memilih bahan Tembaga (Cu) karena memiliki beda potensial non-spontan yang sangat besar (-1.10 V) dan tembaga tahan terhadap kelembaban serta korosi lingkungan.',
      hots_a: 'D < B < C < A (Reduktor terlemah: D, terkuat: A)',
      hots_b: '+1.48 V',
      reflection: 'Kami belajar bahwa konsep elektrokimia sangat penting dalam kehidupan nyata, seperti pada baterai alternatif dan pencegahan korosi tangki industri.',
    },
    submittedAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    lastUpdatedAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    status: 'graded',
    isOverdue: false,
    scoreBreakdown: { fase2: 19, fase3: 29, fase4: 28, fase5: 18 },
    totalScore: 94,
    teacherFeedback: 'Analisis sangat komprehensif dan perhitungan E°sel sangat akurat. Kerja kelompok yang luar biasa!',
    gradedAt: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
  },
  {
    id: 'sub-002',
    groupName: 'Kelompok 2 (Volta)',
    classGrade: 'XII MIPA 1',
    members: ['Aisyah Putri', 'Bambang Irawan', 'Cinta Laura', 'Dodi Kurniawan'],
    answers: {
      prob1: 'Bagaimana buah lemon dapat berfungsi sebagai sumber daya listrik bagi lampu LED?',
      prob2: 'Mengapa pemilihan logam tangki harus memperhatikan kespontanan reaksi redoks?',
      hypo1: 'Air lemon bertindak sebagai elektrolit asam sedangkan Zn dan Cu sebagai kutub negatif dan positif.',
      hypo2: 'Jika reaksi spontan, tangki akan berlubang dan larutan bocor.',
      scaff1_1: 'Logam Zn sebagai anoda.',
      scaff1_2: 'Dari Zn menuju Cu.',
      scaff1_3: 'Menjaga netralitas larutan agar reaksi terus berjalan.',
      scaff2_1: 'reduksi',
      scaff2_2: 'oksidasi',
      solCase1: 'Karena ada selisih potensial 1.1 Volt antara seng dan tembaga yang mendorong elektron mengalir.',
      case2_recommendation: 'Memilih tangki tembaga (Cu) karena nilai E°sel negatif sehingga tidak terjadi reaksi pelarutan tangki.',
      hots_a: 'D - B - C - A',
      hots_b: '+1.48 V',
      reflection: 'Simulasi sel volta sangat membantu kami memahami pergerakan elektron yang tidak terlihat mata.',
    },
    submittedAt: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
    lastUpdatedAt: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
    status: 'graded',
    isOverdue: false,
    scoreBreakdown: { fase2: 17, fase3: 26, fase4: 25, fase5: 17 },
    totalScore: 85,
    teacherFeedback: 'Bagus! Penjelasan sudah baik, perlu diperdalam pada penulisan notasi sel lengkap.',
    gradedAt: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
  },
  {
    id: 'sub-003',
    groupName: 'Kelompok 3 (Nernst)',
    classGrade: 'XII MIPA 1',
    members: ['Bagus Pratama', 'Dian Sastro', 'Faisal Akbar'],
    answers: {
      prob1: 'Faktor apa yang menyebabkan timbulnya voltase pada lemon baterai?',
      prob2: 'Kriteria logam tangki penyimpan larutan ZnSO4.',
      hypo1: 'Ada reaksi redoks antara elektroda dan asam sitrat lemon.',
      hypo2: 'Logam tidak boleh bereaksi dengan ion seng.',
      scaff1_1: 'Zn mengalami oksidasi',
      scaff1_2: 'Dari anoda ke katoda',
      scaff1_3: 'Jembatan garam menghantarkan ion.',
      scaff2_1: 'reduksi',
      scaff2_2: 'oksidasi',
      solCase1: 'Pasangan Zn-Cu menghasilkan listrik karena E sel positif. Zn-Zn E sel 0.',
      case2_recommendation: 'Gunakan tangki Cu karena reaksi tidak spontan.',
      hots_a: 'D, B, C, A',
      hots_b: '+1.48 V',
    },
    submittedAt: new Date(Date.now() - 10 * 60 * 1000).toISOString(),
    lastUpdatedAt: new Date(Date.now() - 10 * 60 * 1000).toISOString(),
    status: 'submitted',
    isOverdue: false,
    scoreBreakdown: { fase2: 0, fase3: 0, fase4: 0, fase5: 0 },
    totalScore: null,
    teacherFeedback: '',
    gradedAt: null,
  },
];

let reminderLogs: ReminderLog[] = [];

// SSE Clients Registry
let sseClients: { id: number; res: express.Response }[] = [];
let nextClientId = 1;

function broadcastSSE(message: RealtimeMessage) {
  const payload = `data: ${JSON.stringify(message)}\n\n`;
  sseClients.forEach((client) => {
    try {
      client.res.write(payload);
    } catch {
      // client disconnected
    }
  });
}

// Keep-alive heartbeat every 20 seconds
setInterval(() => {
  sseClients.forEach((client) => {
    try {
      client.res.write(': heartbeat\n\n');
    } catch {
      // ignore
    }
  });
}, 20000);

// Check deadlines periodically (every 30s) and flag overdue submissions
setInterval(() => {
  const now = new Date().toISOString();
  let updated = false;

  // Check if deadline passed
  if (currentLKPD.deadline && now > currentLKPD.deadline) {
    submissions.forEach((sub) => {
      if (sub.status === 'draft' && !sub.isOverdue) {
        sub.isOverdue = true;
        sub.status = 'late';
        updated = true;
      }
    });
  }

  if (updated) {
    broadcastSSE({
      type: 'deadline_check',
      payload: { now, deadline: currentLKPD.deadline },
      timestamp: new Date().toISOString(),
    });
  }
}, 30000);

// API Endpoints

// 1. SSE Real-time Endpoint
app.get('/api/events', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  const clientId = nextClientId++;
  sseClients.push({ id: clientId, res });

  // Send initial handshake
  res.write(`data: ${JSON.stringify({ type: 'connected', clientId, timestamp: new Date().toISOString() })}\n\n`);

  req.on('close', () => {
    sseClients = sseClients.filter((c) => c.id !== clientId);
  });
});

// 2. LKPD Configuration Endpoints
app.get('/api/lkpd', (req, res) => {
  res.json({
    success: true,
    data: currentLKPD,
    serverTime: new Date().toISOString(),
  });
});

app.put('/api/lkpd', (req, res) => {
  const updatedData = req.body;
  if (!updatedData || !updatedData.title) {
    res.status(400).json({ success: false, message: 'Data LKPD tidak valid' });
    return;
  }

  currentLKPD = {
    ...currentLKPD,
    ...updatedData,
  };

  broadcastSSE({
    type: 'lkpd_updated',
    payload: currentLKPD,
    timestamp: new Date().toISOString(),
  });

  res.json({
    success: true,
    data: currentLKPD,
    message: 'Konfigurasi LKPD berhasil diperbarui dan disinkronkan secara real-time.',
  });
});

// 3. Submissions Endpoints
app.get('/api/submissions', (req, res) => {
  res.json({
    success: true,
    data: submissions,
    targetGroups: currentLKPD.targetGroups,
    deadline: currentLKPD.deadline,
    serverTime: new Date().toISOString(),
  });
});

// Create or update student submission
app.post('/api/submissions', (req, res) => {
  const body = req.body;
  const now = new Date().toISOString();
  const isLate = Boolean(currentLKPD.deadline && now > currentLKPD.deadline);

  const existingIdx = submissions.findIndex((s) => s.id === body.id || (body.groupName && s.groupName.toLowerCase() === body.groupName.toLowerCase()));

  const subStatus: 'draft' | 'submitted' | 'late' = body.isDraft
    ? 'draft'
    : isLate
    ? 'late'
    : 'submitted';

  let savedSubmission: StudentSubmission;

  if (existingIdx >= 0) {
    const existing = submissions[existingIdx];
    savedSubmission = {
      ...existing,
      groupName: body.groupName || existing.groupName,
      classGrade: body.classGrade || existing.classGrade,
      members: body.members || existing.members,
      answers: { ...existing.answers, ...body.answers },
      lastUpdatedAt: now,
      status: existing.status === 'graded' ? 'graded' : subStatus,
      isOverdue: isLate,
      submittedAt: body.isDraft ? existing.submittedAt : (existing.submittedAt || now),
    };
    submissions[existingIdx] = savedSubmission;
  } else {
    savedSubmission = {
      id: body.id || `sub-${Date.now()}`,
      groupName: body.groupName || 'Kelompok Belum Dinamai',
      classGrade: body.classGrade || 'XII',
      members: body.members || [],
      answers: body.answers || {},
      submittedAt: body.isDraft ? null : now,
      lastUpdatedAt: now,
      status: subStatus,
      isOverdue: isLate,
      scoreBreakdown: { fase2: 0, fase3: 0, fase4: 0, fase5: 0 },
      totalScore: null,
      teacherFeedback: '',
      gradedAt: null,
    };
    submissions.unshift(savedSubmission);
  }

  broadcastSSE({
    type: 'submission_saved',
    payload: savedSubmission,
    timestamp: now,
  });

  res.json({
    success: true,
    data: savedSubmission,
    isLate,
    message: body.isDraft
      ? 'Draf berhasil disimpan ke server!'
      : isLate
      ? 'Jawaban berhasil dikirimkan (Tercatat Melewati Batas Waktu).'
      : 'Jawaban LKPD berhasil dikirimkan tepat waktu!',
  });
});

// Teacher Grade Submission
app.put('/api/submissions/:id/grade', (req, res) => {
  const { id } = req.params;
  const { scoreBreakdown, teacherFeedback } = req.body;

  const sub = submissions.find((s) => s.id === id);
  if (!sub) {
    res.status(404).json({ success: false, message: 'Submission tidak ditemukan' });
    return;
  }

  const f2 = Math.min(20, Math.max(0, Number(scoreBreakdown?.fase2) || 0));
  const f3 = Math.min(30, Math.max(0, Number(scoreBreakdown?.fase3) || 0));
  const f4 = Math.min(30, Math.max(0, Number(scoreBreakdown?.fase4) || 0));
  const f5 = Math.min(20, Math.max(0, Number(scoreBreakdown?.fase5) || 0));
  const total = f2 + f3 + f4 + f5;

  sub.scoreBreakdown = { fase2: f2, fase3: f3, fase4: f4, fase5: f5 };
  sub.totalScore = total;
  sub.teacherFeedback = teacherFeedback || '';
  sub.status = 'graded';
  sub.gradedAt = new Date().toISOString();

  broadcastSSE({
    type: 'submission_graded',
    payload: sub,
    timestamp: new Date().toISOString(),
  });

  res.json({
    success: true,
    data: sub,
    message: `Penilaian untuk ${sub.groupName} berhasil disimpan dengan total skor ${total}.`,
  });
});

// Delete Submission
app.delete('/api/submissions/:id', (req, res) => {
  const { id } = req.params;
  const idx = submissions.findIndex((s) => s.id === id);
  if (idx === -1) {
    res.status(404).json({ success: false, message: 'Submission tidak ditemukan' });
    return;
  }

  const [removed] = submissions.splice(idx, 1);

  broadcastSSE({
    type: 'submission_deleted',
    payload: { id },
    timestamp: new Date().toISOString(),
  });

  res.json({
    success: true,
    data: removed,
    message: `Submission ${removed.groupName} berhasil dihapus.`,
  });
});

// 4. Automated Reminders & Deadline Alerts
app.post('/api/reminders/send', (req, res) => {
  const now = new Date();
  const submittedGroupNames = submissions.map((s) => s.groupName.toLowerCase());

  // Find target groups that haven't submitted yet
  const unsubmitted = currentLKPD.targetGroups.filter(
    (tg) => !submittedGroupNames.includes(tg.name.toLowerCase())
  );

  // Also include submissions that are still in 'draft' status
  const draftSubmissions = submissions
    .filter((s) => s.status === 'draft')
    .map((s) => s.groupName);

  const allPendingNames = Array.from(new Set([...unsubmitted.map((g) => g.name), ...draftSubmissions]));

  const log: ReminderLog = {
    id: `rem-${Date.now()}`,
    sentAt: now.toISOString(),
    targetCount: allPendingNames.length,
    targetGroupNames: allPendingNames,
    message: req.body.customMessage || `Pengingat Otomatis Guru: Batas waktu pengumpulan LKPD Sel Volta (${currentLKPD.title}) segera berakhir pada ${currentLKPD.deadline}. Mohon segera selesaikan dan kirimkan jawaban LKPD Anda!`,
  };

  reminderLogs.unshift(log);

  broadcastSSE({
    type: 'reminder_sent',
    payload: log,
    timestamp: now.toISOString(),
  });

  res.json({
    success: true,
    data: log,
    message: `Notifikasi pengingat otomatis berhasil disiarkan kepada ${allPendingNames.length} kelompok yang belum selesai.`,
  });
});

app.get('/api/reminders', (req, res) => {
  res.json({ success: true, data: reminderLogs });
});

// Vite Middleware for development & Static serving in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[LKPD Server] Running on http://localhost:${PORT} with SSE real-time sync`);
  });
}

startServer();
